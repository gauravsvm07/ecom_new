<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserDetail;
use App\Models\Country;
use App\Models\Order;
use App\Models\OrderPayment;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\Cart;
use App\Models\Customer;
use App\Models\Product;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Stripe\StripeClient;
use Stripe\PaymentIntent;
use Stripe\Exception\CardException;
use Exception;
use Artisan;
use Mpdf\Mpdf;
use PDF;
use File;
use App\Mail\OrderSuccessMail;
use App\Mail\ManualOrderSuccess;
use Illuminate\Support\Facades\Mail;
use Stripe;
use App\Http\Controllers\Front\StripeController;
use Srmklive\PayPal\Services\PayPal as PayPalClient;
//use Srmklive\PayPal\Services\PayPal\ExpressCheckout;

class OrderController extends Controller
{

    public function checkout(Request $request)
    {
        if (Helper::cartCount() < 1) {
            return redirect('cart');
        }
        $data['countries'] = Country::orderBy('name', 'asc')->where('show_status', 1)->get();
        $data['carts'] = Session::get('cart', []);
        $subtotal = 0;
        $vat_subtotal = 0;
        foreach ($data['carts'] as $cart_data) {
            $subtotal = $subtotal + $cart_data->price;
            $vat_subtotal = $vat_subtotal + $cart_data->vat;
        }
        $data['cartSubTotal'] = $subtotal;
        $data['cartTax'] = $vat_subtotal;
        $data['cartTotal'] =  $data['cartSubTotal'] + $data['cartTax'];

        $manual_setting = Helper::getWebSetting('is_accept_manual_payment');
        if ($data['cartTotal'] > $manual_setting) {
            $data['is_manual_payment'] = 1;
        } else {
            $data['is_manual_payment'] = 0;
        }

        return view('front.checkout')->with($data);
    }
    public function payment(Request $request)
    {
        if (Helper::cartCount() < 1) {
            return redirect('cart');
        }
        $data['countries'] = Country::orderBy('name', 'asc')->where('show_status', 1)->get();
        $data['carts'] = Session::get('cart', []);
        $subtotal = 0;
        $vat_subtotal = 0;
        foreach ($data['carts'] as $cart_data) {
            $subtotal = $subtotal + $cart_data->price;
            $vat_subtotal = $vat_subtotal + $cart_data->vat;
        }

        $data['cartSubTotal'] = $subtotal;
        $data['cartTax'] = $vat_subtotal;
        $data['cartTotal'] =  $data['cartSubTotal'] + $data['cartTax'];

        return view('front.payment')->with($data);
    }


    public function placeOrder(Request $request)
    {
        if (Helper::cartCount() < 1) {
            return redirect('cart');
        }

        $cart_count = Helper::cartCount();

        $cartsData = Session::get('cart', []);
        if ($cartsData[0]->voucher_po == 'physical') {
            $validate = $request->validate([
                'first_name' => 'regex:/^[a-zA-Z ]+$/',
                'email' => 'required|email',
                'address' => 'required',
                'country' => 'required',
                'city' => 'required',
                'zip_code' => 'required',
                'agb' => 'accepted',
                'datenschutzrichtlinie' => 'accepted',
            ]);
        } else {
            $validate = $request->validate([
                'first_name' => 'regex:/^[a-zA-Z ]+$/',
                ///'last_name' => 'regex:/^[a-zA-Z ]+$/',
                'email' => 'required|email',
                //'agb' => 'accepted',
                //'datenschutzrichtlinie' => 'accepted',
            ]);
        }

        //dd($request);

        $customer = Customer::firstOrNew(['email' =>  $request->email]);
        $customer->first_name = $request->first_name;
        $customer->last_name = $request->last_name;
        $customer->email = $request->email;
        $customer->phone = $request->phone;
        $customer->address = $request->address;
        $customer->country = $request->country;
        $customer->city = $request->city;
        $customer->zip_code = $request->zip_code;
        $customer->status = 1;
        $customer->save();

        $customer_id = $customer->id;

        $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";
        $invoice_random_id = Helper::random_strings(7);
        $order_random_id = Helper::random_strings(7);
        if ($request->payment_via == 'Manual_Payment') {
            $order_payment_id = 'MP-' . $invoice_random_id;
        } else {
            $order_payment_id = 'AP-' . $invoice_random_id;
        }


        $carts = Session::get('cart', []);
        $subtotal = 0;
        $vat_subtotal = 0;
        foreach ($carts as $cart_data) {
            $subtotal = $subtotal + $cart_data->price;
            $vat_subtotal = $vat_subtotal + $cart_data->vat;
        }

        $cartSubTotal = $subtotal;
        $cartTax = $vat_subtotal;
        $cartTotal =  $cartSubTotal + $cartTax;

        if ($cartTotal < 1) {
            return redirect('cart')->with('msg', 'Cart is empty.');
        }

        if ($request->payment_via == 'stripe' && !isset($request->stripeToken)) {
            $data['carts'] = Session::get('cart', []);
            $subtotal = 0;
            $vat_subtotal = 0;
            foreach ($data['carts'] as $cart_data) {
                $subtotal = $subtotal + $cart_data->price;
                $vat_subtotal = $vat_subtotal + $cart_data->vat;
            }
            $data['cartSubTotal'] = $subtotal;
            $data['cartTax'] = $vat_subtotal;
            $data['cartTotal'] =  $data['cartSubTotal'] + $data['cartTax'];
            $data['request'] = $request->all();
            return view('front.stripe')->with($data);
        }

        $order = new Order();
        $order->customer_id = $customer_id;
        $order->payment_via = $request->payment_via;
        $order->vat_sales_provision = Helper::getWebSetting('vat_sales_provision');
        $order->standard_sales_provision = Helper::getWebSetting('standard_sales_provision');
        $order->amount = $cartTotal;
        $order->vat_total = $cartTax;
        $order->net_amount = $cartTotal;
        $order->invoice_id = $invoice_random_id;
        $order->order_id = $invoice_random_id;
        $order->payment_id = $order_payment_id;
        $order->currency = 'EUR';
        $order->payment_status = 1;
        $order->order_status = 1;
        $order->save();

        $uuid = Str::orderedUuid($order->id);
        $update_order = Order::where('id', $order->id)->update(['uuid' => $uuid]);

        $order_id = $order->id;
        foreach ($carts as $key => $cart) {

            $voucherItemCount = OrderItem::where(['voucher_id' => $cart->voucher_id])->count();
            $orderItem = new OrderItem();
            $orderItem->customer_id = $customer_id;
            $orderItem->partner_id = $cart->partner_id;
            $orderItem->order_id = $order_id;
            $orderItem->product_id = $cart->offer_id;
            $orderItem->voucher_code = $invoice_random_id;
            $orderItem->voucher_id = $invoice_random_id . '-' . ($key + 1);
            $orderItem->product_uid = Helper::getViewPartnerProductId($cart->partner_id,$cart->partner_uid);
            $orderItem->title = $cart->title;
            $orderItem->image = $cart->image;
            $orderItem->slug = $cart->slug;
            $orderItem->quantity = $cart->quantity;
            $orderItem->price = $cart->price;
            $orderItem->vat = $cart->vat;
            $orderItem->vat_rate = $cart->vat_rate;
            $orderItem->vat_amount = $cart->vat_amount;
            $orderItem->net_price = $cart->net_price;
            // if (count($carts) > 1) {
            //     $orderItem->voucher_id = $cart->voucher_id . '-' . ($key + 1);
            // } else {
            //     $orderItem->voucher_id = $cart->voucher_id;
            // }
            $orderItem->save();
        }

        $address = new OrderAddress();
        $address->customer_id = $customer_id;
        $address->order_id = $order_id;
        $address->first_name = $request->first_name;
        $address->last_name = $request->last_name;
        $address->email = $request->email;
        $address->phone = $request->phone;
        $address->address = $request->address;
        $address->country = $request->country;
        $address->city = $request->city;
        $address->zip_code = $request->zip_code;
        $address->save();

        $payment = new OrderPayment();
        $payment->customer_id = $customer_id;
        $payment->order_id = $order_id;
        $payment->amount = $cartTotal;
        $payment->currency = 'EUR';
        $payment->status = 1;
        $payment->save();

        $data['order'] = Order::where('id', $order_id)->first();
        $mail_data = [];

        if ($order->payment_via == 'stripe') {
            try {
                \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

                // Get the payment amount and email address from the form.
                $amount = $cartTotal * 100;
                $email = $request->email;
                ///dd($request->email);
                //dd($request->input('stripeToken'));
                // Create a new Stripe customer.
                $customer = \Stripe\Customer::create([
                    'email' => $email,
                    'source' => $request->input('stripeToken'),
                ]);

                // Create a new Stripe charge.
                $charge = \Stripe\Charge::create([
                    'customer' => $customer->id,
                    'amount' => $amount,
                    'currency' => 'usd',
                ]);

                if ($charge->status == "succeeded") {
                    Order::where('id', $order->id)->update(['raw_data' => json_encode($charge), 'payment_status' => 3,'order_status' => 4, 'transaction_id' => $charge['balance_transaction']]);


                    $mail_data['order'] = Order::where('id', $order->id)->first();
                    $mail_data['user'] = $customer;
                    $mail_data['order_items'] = OrderItem::where('order_id', $order->id)->with('product')->get();

                    $data['order'] = Order::where('uuid', $uuid)->first();
                    $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
                    $data['order_items'] = OrderItem::where('order_id', $data['order']->id)->with('product')->get();

                    $mpdf = new Mpdf();
                    $html = view('pdf.invoice', $data)->render();
                    $filePath = public_path('pdf/invoice/') . 'RE-' . $order->invoice_id . '.pdf';

                    $footerHtml = $footer_info;
                    $mpdf->SetHTMLFooter($footerHtml);
                    $mpdf->WriteHTML($html);
                    $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);



                    $attachments = [];
                    $po_setting = Helper::getWebSetting('voucher_po');
                    foreach ($mail_data['order_items'] as $key => $item) {

                        $mpdf = new Mpdf();
                        $viewData['product'] = Product::where('id', $item->product_id)->first();
                        $viewData['partner'] = UserDetail::where('user_id', $item->partner_id)->first();
                        $viewData['voucher_id'] = $order->invoice_id . '-' . ($key + 1);
                        $viewData['voucher_code'] = $order->invoice_id;
                        $viewData['net_price'] = $item->net_price;
                        $html = view('pdf.voucher', $viewData)->render();
                        // Define the file path where you want to save the PDF
                        if ($cart_count == 1) {
                            $voucher_file_name =  $order->invoice_id;
                        } else {
                            $voucher_file_name =  $order->invoice_id . '-' . ($key + 1);
                        }
                        $filePath = public_path('pdf/voucher/') . $voucher_file_name . '.pdf';
                        // Save the PDF to the server
                        $footerHtml = $footer_info;
                        $mpdf->SetHTMLFooter($footerHtml);  

                        $mpdf->WriteHTML($html);
                        $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

                        if ($po_setting != 'physical') {
                            $attachments[] = [
                                'file' => public_path('pdf/voucher/' . $voucher_file_name . '.pdf'),
                                'options' => [
                                    'mime' => 'application/pdf',
                                    'as' => $voucher_file_name . '.pdf',
                                ],
                            ];

                           
                        } else
                        {
                            Helper::fullyRedemption($item->id);
                        }
                    }

                    $attachments[count($attachments)] = [
                        'file' => public_path('pdf/invoice/' . 'RE-' . $mail_data['order']['invoice_id'] . '.pdf'),
                        'options' => [
                            'mime' => 'application/pdf',
                            'as' => 'RE-' . $mail_data['order']['invoice_id'] . '.pdf',
                        ],
                    ];

                    Mail::to($request->email)->send(new OrderSuccessMail($mail_data, $attachments));
                    session()->forget('cart');
                }

                // Display a success message to the user.
                //return 'Stripe Payment successful!';
                session()->forget('cart');
                return redirect('order-confirm/' . $data['order']->uuid)->with($data);
            } catch (\Stripe\Exception\CardException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (\Stripe\Exception\RateLimitException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (\Stripe\Exception\InvalidRequestException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (\Stripe\Exception\AuthenticationException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (\Stripe\Exception\ApiConnectionException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (\Stripe\Exception\ApiErrorException $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            } catch (Exception $e) {
                dd($e->getMessage());
                return redirect()->back()->with('errMsg', $e->getMessage());
            }
        } else if ($order->payment_via == 'paypal') {
            //$stripe_data = $this->paypal($request);
            $provider = new PayPalClient;
            $provider->setApiCredentials(config('paypal'));
            $paypalToken = $provider->getAccessToken();

            $response = $provider->createOrder([
                "intent" => "CAPTURE",
                "application_context" => [
                    "return_url" => route('paypal.success', ['order_id=' . $uuid]),
                    "cancel_url" => route('paypal.cancel', ['order_id=' . $uuid]),
                ],
                "purchase_units" => [
                    0 => [
                        "amount" => [
                            "currency_code" => "EUR",
                            "value" => $cartTotal
                        ]
                    ]
                ]
            ]);

            if (isset($response['id']) && $response['id'] != null) {

                foreach ($response['links'] as $links) {
                    if ($links['rel'] == 'approve') {
                        //dd($links['href']);

                        return redirect()->away($links['href'] . '&order_id=' . $uuid);
                    }
                }

                return redirect()
                    ->route('checkout')
                    ->with('error', 'Something went wrong.');
            } else {
                return redirect()
                    ->route('checkout')
                    ->with('error', $response['message'] ?? 'Something went wrong.');
            }
        } else if ($order->payment_via == 'Manual_Payment') {
            //dd($request->payment_via);
            $mail_data['order'] = Order::where('id', $order->id)->first();;
            $mail_data['user'] = $customer;
            $mail_data['order_items'] = OrderItem::where('order_id', $order->id)->with('product')->get();
            $data['order'] = Order::where('uuid', $uuid)->first();
            $data['order_items'] = OrderItem::where('order_id', $order->id)->with('product')->get();
            $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();

            $mpdf = new Mpdf();
            $html = view('pdf.invoice', $data)->render();
            $filePath = public_path('pdf/invoice/') . 'RE-' . $order->invoice_id . '.pdf';

            $footerHtml = $footer_info;
            $mpdf->SetHTMLFooter($footerHtml);

            $mpdf->WriteHTML($html);
            $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

            $base_url = 'http://165.232.130.162/community/';

            /*$attachments = [
                ['file' => public_path('pdf/voucher/8E0BRHT.pdf')],
                ['file' => public_path('pdf/invoice/rblmoeu.pdf')],
            ];*/
            $attachments = [];
           
            foreach ($mail_data['order_items'] as $key => $item) {

                $mpdf = new Mpdf();
                $viewData['product'] = Product::where('id', $item->product_id)->first();
                $viewData['partner'] = UserDetail::where('user_id', $item->partner_id)->first();
                $viewData['voucher_id'] = $order->invoice_id . '-' . ($key + 1);
                $viewData['voucher_code'] = $order->invoice_id;
                $viewData['net_price'] = $item->net_price;
                $html = view('pdf.voucher', $viewData)->render();
                // Define the file path where you want to save the PDF

                if ($cart_count == 1) {
                    $voucher_file_name =  $order->invoice_id;
                } else {
                    $voucher_file_name =  $order->invoice_id . '-' . ($key + 1);
                }

                $filePath = public_path('pdf/voucher/') . $voucher_file_name . '.pdf';
                // Save the PDF to the server
                $footerHtml = $footer_info;
                $mpdf->SetHTMLFooter($footerHtml);
                $mpdf->WriteHTML($html);
                $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);
            }

            $attachments[count($attachments)] = [
                'file' => public_path('pdf/invoice/' . 'RE-' . $mail_data['order']['invoice_id'] . '.pdf'),
                'options' => [
                    'mime' => 'application/pdf',
                    'as' => 'RE-' . $mail_data['order']['invoice_id'] . '.pdf',
                ],
                // Add more attachments with options as needed
            ];

            Mail::to($request->email)->send(new ManualOrderSuccess($mail_data, $attachments));
            session()->forget('cart');
            return redirect('order-confirm/' . $data['order']->uuid)->with($data);
        }
    }

    public function orderConfirm(Request $request, $uuid)
    {
        if (!$uuid) {
            return redirect('/');
        }
        $data['order'] = Order::where('uuid', $uuid)->first();
        $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
        return view('front.order-confirm')->with($data);
    }

    public function invoice(Request $request, $uuid)
    {
        if (!$uuid) {
            return redirect('/');
        }
        $data['order'] = Order::where('uuid', $uuid)->first();
        $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
        $data['order_items'] = OrderItem::where('order_id', $data['order']->id)->with('product')->get();
        //dd($data['order']);
        //$pdf = PDF::loadView('pdf.invoice', $data);
        ///return $pdf->stream('document.pdf');
        return redirect('public/pdf/invoice/RE-'.$data['order']['order_id'].'.pdf');
    }


    /**
     * success transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function successTransaction(Request $request)
    {
        $order_id = $request->query('order_id'); // Retrieve order_id from the request query parameters

        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $provider->getAccessToken();
        $response = $provider->capturePaymentOrder($request['token']);
        $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";

        //$transactionId = $response['id']; // Assuming the transaction ID is available in the response
        $order = Order::where('uuid', $order_id)->first();

        if (isset($response['status']) && $response['status'] == 'COMPLETED') {


            Order::where('id', $order->id)->update(['raw_data' => '', 'payment_status' => 3, 'transaction_id' => '']);

            $mail_data['order'] = Order::where('id', $order->id)->first();;
            $mail_data['user'] = Customer::where('id', $order->customer_id)->first();
            $mail_data['order_items'] = OrderItem::where('order_id', $order->id)->with('product')->get();
            $data['order'] = Order::where('uuid', $order_id)->first();
            $data['order_items'] = OrderItem::where('order_id', $order->id)->with('product')->get();
            $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
            $mpdf = new Mpdf();
            $html = view('pdf.invoice', $data)->render();
            $filePath = public_path('pdf/invoice/') . 'RE-' . $order->invoice_id . '.pdf';

            $footerHtml = $footer_info;
            $mpdf->SetHTMLFooter($footerHtml);
            $mpdf->WriteHTML($html);
            $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

            $po_setting = Helper::getWebSetting('voucher_po');
            $attachments = [];
            foreach ($mail_data['order_items'] as $key => $item) {

                $mpdf = new Mpdf();
                $viewData['product'] = Product::where('id', $item->product_id)->first();
                $viewData['partner'] = UserDetail::where('user_id', $item->partner_id)->first();
                $viewData['voucher_id'] = $order->invoice_id . '-' . ($key + 1);
                $viewData['voucher_code'] = $order->invoice_id;
                $viewData['net_price'] = $item->net_price;
                $html = view('pdf.voucher', $viewData)->render();
                // Define the file path where you want to save the PDF
                $cart_count = Helper::cartCount();
                if ($cart_count == 1) {
                    $voucher_file_name =  $order->invoice_id;
                } else {
                    $voucher_file_name =  $order->invoice_id . '-' . ($key + 1);
                }

                $filePath = public_path('pdf/voucher/') . $voucher_file_name . '.pdf';
                // Save the PDF to the server
                $footerHtml = $footer_info;
                $mpdf->SetHTMLFooter($footerHtml);
                $mpdf->WriteHTML($html);
                $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

                if ($po_setting != 'physical') {
                    $attachments[] = [
                        'file' => public_path('pdf/voucher/' . $voucher_file_name . '.pdf'),
                        'options' => [
                            'mime' => 'application/pdf',
                            'as' => $voucher_file_name . '.pdf',
                        ],
                    ];
                } else
                {
                    Helper::fullyRedemption($item->id);
                }
            }

            $attachments[count($attachments)] = [
                'file' => public_path('pdf/invoice/' . 'RE-' . $mail_data['order']['invoice_id'] . '.pdf'),
                'options' => [
                    'mime' => 'application/pdf',
                    'as' => 'RE-' . $mail_data['order']['invoice_id'] . '.pdf',
                ],
                // Add more attachments with options as needed
            ];

            $customer = Customer::where('id', $order->customer_id)->first();
            Mail::to($customer['email'])->send(new OrderSuccessMail($mail_data, $attachments));
            session()->forget('cart');



            // Update transaction ID and order payment status
            $transactionId = $response['id']; // Assuming the transaction ID is available in the response
            $order = Order::where('uuid', $order_id)->first();
            if ($order) {
                $order->transaction_id = $transactionId;
                $order->payment_status = 3; // Update payment status to indicate successful payment
                $order->order_status = 4; // Update payment status to indicate successful payment
                $order->save();

                session()->forget('cart');
                return redirect()->route('order.confirm', ['id' => $order_id])->with('order', $order);
                //return redirect()->route('paypal.transaction')->with('success', 'Transaction complete.');
            } else {
                return redirect()
                    ->route('paypal.transaction')
                    ->with('error', 'Order not found.');
            }
        } else {
            return redirect()
                ->route('paypal.transaction')
                ->with('error', $response['message'] ?? 'Something went wrong.');
        }
    }
    /**
     * cancel transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function cancelTransaction(Request $request)
    {
        $uuid = $request->query('order_id');
        $data['order'] = Order::where('uuid', $uuid)->first();
        $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
        return view('front.order-canceled')->with($data);

        // return redirect()
        //     ->route('paypal.transaction')
        //     ->with('error', $response['message'] ?? 'You have canceled the transaction.');
    }
}
