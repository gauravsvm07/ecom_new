<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserDetail;
use App\Models\Product;
use App\Models\Cart;
use App\Models\WebSetting;
use App\Interfaces\HotelRepositoryInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use Ramsey\Uuid\Nonstandard\UuidV6;
use App\Helpers\Helper;
use stdClass;

class CartController extends Controller
{

    public function addToCart(Request $request)
    {
        $cart = Session::get('cart', []);
        $id = $request->offer_id;
        $product = Product::where(['id' => $id, 'status' => 1])->first();

        $price_type = $product['price_type'];
        if ($price_type == 'fixed') {
            $price = $product['price'];
        } else {
            //dd($request->desired_amount);
            if($request->desired_amount != '' && $request->desired_amount < $product['minimum_price'])
            {
                $price = $product['minimum_price'];
            } else if($request->desired_amount != '' && $request->desired_amount > $product['minimum_price'])
            {
                $price = $request->desired_amount; 
            }

            else if ($request->voucher_price < $product['minimum_price']) {
                $price = $product['minimum_price'];
            } else if ($request->voucher_price > $product['maximum_price']) {
                $price = $product['minimum_price'];
            } else {
                $price = $request->voucher_price;
            }
        }



        $vat_percentage = Helper::getVoucherVat($product->id, $product->user_id);
        $vat_percentage_dec = number_format((float)$vat_percentage/100, 2, '.', '');
        $gross_amount = $price;
        $net_amount = $gross_amount/(1+$vat_percentage_dec);
        $vat_price = number_format((float)($gross_amount - $net_amount), 2, '.', '');

        // Check if the product already exists in the cart
        $existingItem = null;
        foreach ($cart as $key => $item) {
            if ($item->offer_id == $product->id) {
                $existingItem = $key;
                break;
            }
        }

        // if ($existingItem !== null) {
        //     $qun_price = number_format((float)($request->quantity ?: 1 * ($gross_amount-$vat_price)), 2, '.', '');
        //     $qun_vat_price = $vat_price;

        //     $cart[$existingItem]->quantity += $request->quantity ?: 1;
        //     $cart[$existingItem]->price += $qun_price;
        //     $cart[$existingItem]->vat += $qun_vat_price;
        //     $cart[$existingItem]->net_price += ($qun_price + $qun_vat_price);
        // } else {
        // }
            // If the product is not in the cart, add it as a new item

            $qun_price = number_format((float)($request->quantity ?: 1 * ($gross_amount-$vat_price)), 2, '.', '');
            $qun_vat_price = $vat_price;

            $item = new stdClass();
            $item->offer_id = $product->id;
            $item->partner_id = $product->user_id;
            $item->partner_uid = $product->partner_product_id;
            $item->title = $product->title;
            $item->image = $product->image;
            $item->brand_logo = $product->brand_logo;
            $item->voucher_po = $product->voucher_po;
            $item->slug = $product->slug;
            $item->price = $qun_price;
            $item->select_price = $qun_price + $qun_vat_price;
            $item->voucher_id = $product->voucher_id;
            $item->vat = $qun_vat_price;
            $item->vat_amount = $vat_price;
            $item->vat_rate = $vat_percentage;
            $item->quantity = $request->quantity ?: 1;
            $item->net_price = $qun_price + $qun_vat_price;
            $item->id = UuidV6::uuid6();
            $cart[] = $item;
       

        Session::put('cart', $cart);
        return redirect('cart')->with('msg', 'Gutschein wurde dem Warenkorb hinzugefügt');
    }
    public function updateCart(Request $request)
    {
        $offer_id = $request->offer_id;
        $cart = Session::get('cart', []);
        $filter = [];
        if (!$offer_id) {
            return response()->json(['message' => 'Voucher id is required.'], 400);
        }
        foreach ($cart as $list) {
            if ($list->offer_id != $offer_id) {
                $filter[] = $list;
            }
        }
        Session::put('cart', $filter);

        $cart = Session::get('cart', []);
        $id = $request->offer_id;
        $product = Product::where(['id' => $id, 'status' => 1])->first();

        $price_type = $product['price_type'];
        if ($price_type == 'fixed') {
            $price = $product['price'];
        } else {
            $price = $request->voucher_price;
        }

        $vat_percentage = Helper::getVoucherVat($product->id, $product->user_id);

        $vat_percentage = Helper::getVoucherVat($product->id, $product->user_id);
        $vat_percentage_dec = number_format((float)$vat_percentage/100, 2, '.', '');
        $gross_amount = $price;
        $net_amount = $gross_amount/(1+$vat_percentage_dec);
        $vat_price = number_format((float)($gross_amount - $net_amount), 2, '.', '');

        ///return $price;
        

        // Check if the product already exists in the cart
        $existingItem = null;
        foreach ($cart as $key => $item) {
            if ($item->offer_id == $product->id) {
                $existingItem = $key;
                break;
            }
        }

        $qun_price = number_format((float)(($request->quantity ?: 1) * ($gross_amount-$vat_price)), 2, '.', '');
        $qun_vat_price =  number_format((float)(($request->quantity ?: 1) * $vat_price), 2, '.', '');

        ///return response()->json(['success' => true,'price' => $price , 'vat_percentage' => $vat_percentage ,'vat' => $vat_price , 'qun_price' => $qun_price]);

        $item = new stdClass();
        $item->offer_id = $product->id;
        $item->partner_id = $product->user_id;
        $item->title = $product->title;
        $item->image = $product->image;
        $item->brand_logo = $product->brand_logo;
        $item->voucher_po = $product->voucher_po;
        $item->slug = $product->slug;
        $item->price = $qun_price;
        $item->select_price = $request->voucher_price;
        $item->voucher_id = $product->voucher_id;
        $item->vat = $qun_vat_price;
        $item->quantity = $request->quantity ?: 1;
        $item->net_price = $qun_price + $qun_vat_price;
        $item->id = UuidV6::uuid6();
        $cart[] = $item;

        Session::put('cart', $cart);
        return response()->json(['success' => true]);

    }


    public function cart(Request $request)
    {
        $data['carts'] = Session::get('cart', []);
        //dd($data['carts']);
        $subtotal = 0;
        $vat_subtotal = 0;
        foreach ($data['carts'] as $cart_data) {
            $subtotal = $subtotal + $cart_data->price;
            $vat_subtotal = $vat_subtotal + $cart_data->vat;
        }

        $data['cartSubTotal'] = $subtotal;
        $data['cartTax'] = $vat_subtotal;
        $data['cartTotal'] =  $data['cartSubTotal'] + $data['cartTax'];
        return view('front.cart')->with($data);
    }

    public function deleteCart(Request $request, $offer_id)
    {
        //dd($offer_id);
        $cart = Session::get('cart', []);
        $filter = [];
        if (!$offer_id) {
            return response()->json(['message' => 'Voucher id is required.'], 400);
        }
        foreach ($cart as $list) {
            if ($list->offer_id != $offer_id) {
                $filter[] = $list;
            }
        }
        Session::put('cart', $filter);
        return redirect('cart')->with('msg', 'Gutschein aus Warenkorb gelöscht.');
    }
}
