<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Enquiry;
use App\Models\Blog;
use App\Models\Category;
use App\Models\Product;
use App\Models\Page;
use App\Models\Partner;
use App\Models\User;
use App\Models\PageSection;
use App\Models\EmailTemplate;
use App\Mail\DynamicEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use App\Helpers\Helper;
use Exception;
use Artisan;
use Captcha;


class PageController extends Controller
{
   public function index(Request $request)
   {
      $universal_prioritation  = Helper::getWebSetting('universal_prioritation');
      if($universal_prioritation == 1)
      {
        $order_by = 'is_universal';
      } else
      {
        $order_by = 'title';
      }

      $data['products'] = Product::where('products.status', 1) // Ensure product status is active
      ->join('users', 'products.user_id', '=', 'users.id') // Join with users table
      ->where('users.status', 1) // Ensure user status is active
      ->orderBy($order_by, 'desc') // Order by your specified column
      ->select('products.*') // Select products only
      ->get();

      $data['banners'] = Banner::orderBy('id','desc')->where('type','home')->get();
      $data['deals'] = Product::orderBy('id','desc')->where(['best_deal'=>1 , 'status'=>1])->get();
      ///$data['products'] = Product::where(['status' => 1])->orderBy($order_by,'desc')->get();
      return view('front.products')->with($data);
   }

   public function getMenu()
   {
       $menu = new Menu;
       $menuList = $menu->tree();
       return view('index')->with('menulist', $menuList);
   }


   public function partners(Request $request)
   {
    $data['partners'] = User::where('status',1)->where('is_universal_partner','!=', 1)->orderBy('id','desc')->paginate(12);
    return view('front.partners')->with($data);
   }

   public function partnerSearch(Request $request)
   {
      ///$data['partners']= User::leftJoin('user_details','users.id','user_details.user_id')->where('user_details.company', 'like', '%' . $request->keyword . '%')->where('users.status', 1)->where('is_universal_partner','!=', 1)->paginate(12);
      ///$data['partners'] = User::where('name', 'like', '%' . $request->keyword . '%')->where('status',1)->paginate(10);

      $data['partners'] = User::where('status', 1)
    ->where('is_universal_partner', '!=', 1)
    ->whereHas('userDetails', function($query) use ($request) {
        $query->where('company', 'like', '%' . $request->keyword . '%');
    })
    ->paginate(12);
    return view('front.partners')->with($data);
      
   }

   public function viewVouchers(Request $request,$uuid)
   {
    $getUser = User::where('uuid',$uuid)->first();
    if(!$getUser)
    {
        dd('Invalid request');
    }
    $data['vouchers'] = Product::where('user_id',$getUser['id'])->get();
    return view('front.view-vouchers')->with($data);
   }

 
   public function blogs(Request $request)
   {
    return view('front.blogs');
   }

   public function blogDetails(Request $request,$slug)
   {
    $data['blog'] = Blog::orderBy('id','desc')->where('slug',$slug)->first();
    //dd($data['blog']);
    return view('front.blog-details')->with($data);
   }

   public function pageDetails(Request $request,$slug)
   {
    $data['page'] = Page::where('slug',$slug)->first();
    if(!$data['page'])
    {
      dd('page not found.');
    }
    //dd($data['blog']);
    return view('front.page')->with($data);
   }
   

   public function contactUs(Request $request)
   {
    $data['content'] = PageSection::orderBy('id','desc')->where('id',17)->first();
    return view('front.contact')->with($data);
   }

   public function privacyPolicy(Request $request)
   {
    $data['page'] = PageSection::orderBy('id','desc')->where('id',19)->first();
    return view('front.page')->with($data);
   }


   public function termCondition(Request $request)
   {
    $data['page'] = PageSection::orderBy('id','desc')->where('id',21)->first();
    return view('front.terms')->with($data);
   }

   public function imprint(Request $request)
   {
    $data['page'] = PageSection::orderBy('id','desc')->where('id',21)->first();
    return view('front.imprint')->with($data);
   }

   public function dataProtection(Request $request)
   {
    $data['page'] = PageSection::orderBy('id','desc')->where('id',21)->first();
    return view('front.data-protection')->with($data);
   }

   

   public function faq(Request $request)
   {
    $data['page'] = PageSection::orderBy('id','desc')->where('id',22)->first();
    return view('front.faq')->with($data);
   }

   public function aboutUs(Request $request)
   {
    $data['page'] = PageSection::where(['id' => 35, 'status' => 1])->first();
    return view('front.about')->with($data);
   }

   
   public function saveEnquiry(Request $request)
   {
       $validate = $request->validate([
           'name' => 'regex:/^[a-zA-Z ]+$/',
           'email' => 'required|email',
           'website' => 'required',
           'message' => 'required',
       ]);

       $enq = new Enquiry;
       $enq->name = $request->name;
       $enq->email = $request->email;
       $enq->website = $request->website;
       $enq->message = $request->message;
       $enq->save();

       $arr = [
           'name' => $request->name,
           'email' => $request->email,
           'message' => $request->message,
       ];

       ///Mail::to('gaurav.kumar@infoicon.in')->send(new EnquiryMail($arr));


       return redirect()->back()->with('msg', 'Thank You for Your Inquiry.');
   }



}
