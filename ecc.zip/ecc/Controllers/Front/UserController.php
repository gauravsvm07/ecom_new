<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDetail;
use App\Models\Country;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderAddress;
use App\Models\OrderPayment;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Redemption;
use App\Models\Influencer;
use App\Models\Counter;
use App\Models\EmailTemplate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use App\Helpers\Helper;
use App\Mail\ResetUserPasswordMail;
use App\Mail\CreditNoteMail;
use App\Mail\DynamicEmail;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use App\Rules\Iban;
use Exception;
use File;
use Mpdf\Mpdf;
use PDF;
use DB;


class UserController extends Controller
{


  public function login()
  {
    return view('front.login');
  }

  public function forgotPassword()
  {
    return view('front.forgot-password');
  }

  public function register(Request $request)
  {
    $influencer_id = $request->segment(2);

     ///$data['influencer'] = [];
    if($influencer_id)
    {
      $influencer = Influencer::where('influencer_id',$influencer_id)->first();
      if($influencer)
      {
        $data['influencer'] = $influencer;
      }
      ///dd($influencer_id);
    }
    $data['countries'] = Country::orderBy('name', 'asc')->where('show_status', 1)->get();
    return view('front.register')->with($data);
  }




  public function sendResetPassLink(Request $request)
  {
    $validatedData = $request->validate([
      'email' => 'required|email|max:255'
    ]);

    $countUser = User::where('email', $request->email)->where('status', 1)->count();

    if ($countUser < 1) {
      return redirect()->back()->with('msg', 'User does not exist');
    }

    if ($countUser < 1) {
      $response = ['success' => false, 'message' => 'User does not exist'];
      return response()->json($response, 200);
    }
    $token = Str::random(64);

    DB::table('password_resets')->insert([
      'email' => $request->email,
      'token' => $token,
      'created_at' => Carbon::now()
    ]);

    $arr = [
      'email' => $request->email,
      'token' => $token,
    ];

    Mail::to($request->email)->send(new ResetUserPasswordMail($arr));

    return back()->with('msg', 'Link zum Zurücksetzen des Passworts erfolgreich gesendet.');
  }


  public function resetPassword(Request $request)
  {
    if (empty($request->pswtoken)) {
      return redirect('/');
    }
    return view('front.reset-password');
  }


  public function updateUserEmailPassword(Request $request)
  {
    $validatedData = $request->validate([
      'password' => 'required|string|min:6|confirmed',
      'password_confirmation' => 'required'
    ]);

    $updatePassword = DB::table('password_resets')
      ->where([
        'token' => $request->pswtoken
      ])
      ->first();

    if (!$updatePassword) {
      return back()->with('msg', 'Invalid token!');
    }

    $user = User::where('email', $updatePassword->email)
      ->update(['password' => bcrypt($request->password)]);
    ///dd($updatePassword->email);
    DB::table('password_resets')->where(['email' => $updatePassword->email])->delete();

    return redirect('login')->with('msg', 'Ihr Passwort wurde erfolgreich zurückgesetzt!');
  }


  public function myaccount()
  {
    $data['orders'] = [];
    return view('user.myaccount')->with($data);
  }

  public function orderDetails($order_id)
  {
    $data['items'] = OrderItem::where(['order_id' => $order_id, 'user_id' => Auth::user()->id])->orderBy('id', 'desc')->get();
    $data['address'] = OrderAddress::where(['order_id' => $order_id, 'user_id' => Auth::user()->id])->orderBy('id', 'desc')->first();
    return view('user.order-details')->with($data);
  }

  public function myProfile()
  {
    $user_id = Auth::user()->id;
    $data['countries'] = Country::orderBy('name', 'asc')->get();
    $data['user'] = User::where('id', $user_id)->first();
    $data['user_detail'] = UserDetail::where('user_id', $user_id)->first();
    return view('user.my-profile')->with($data);
  }

  public function changePassword()
  {
    return view('user.change-password');
  }

  public function logout(Request $request)
  {
    Auth::logout();
    return redirect('/');
  }

  public function userAuth(Request $request, $type)
  {
    if ($type != "login" && $type != "register") {
      return abort(404);
    }


    if ($type == "login") {
      $this->validate($request, [
        'email' => 'required',
        'password' => 'required'
      ]);

      $credentials = $request->only('email', 'password');
      $user = User::where(['email' => $request->email, 'status' => 1])->first();

      if (!$user) {
        return redirect()->back()->with(['msg' => 'Ungültige E-Mail-Adresse oder ungültiges Passwort.']);
      }

      if (!Hash::check($request->password, $user->password)) {
        return redirect()->back()->with(['msg' => 'Ungültige E-Mail-Adresse oder ungültiges Passwort.']);
      }

      Auth::attempt($credentials);
      return redirect('/');
    }


    if ($type == "register") {
      $this->validate($request, [
        'email' => 'required|string|email|unique:users',
        'password' => 'required|string|regex:/[a-z]/|regex:/[A-Z]/|regex:/[0-9]/|regex:/[@$!%*?&#]/|min:6',
        'name' => 'required',
        'phone' => 'required',
        'company' => 'required',
        'street' => 'required',
        'zipcode' => 'required',
        'country' => 'required',
        'bank_account' => 'required',
        'video_type' => 'required',
        'iban' => ['required', new Iban],
        'swift' => ['required', 'regex:/^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/'],
        'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:1024',
        'about' => 'required',
        'agb' => 'accepted',
        'datenschutzrichtlinie' => 'accepted',
    ], [
        // Custom error messages
        'email.required' => 'Bitte geben Sie Ihre E-Mail-Adresse ein.',
        'email.email' => 'Bei der E-Mail muss es sich um eine gültige E-Mail-Adresse handeln.',
        'email.unique' => 'Diese E-Mail-Adresse ist bereits vergeben.',
    
        'password.required' => 'Bitte geben Sie Ihr Passwort ein.',
        'password.min' => 'Das Passwort muss aus mindestens 6 Zeichen bestehen und einen Kleinbuchstaben, einen Großbuchstaben, eine Ziffer und ein Sonderzeichen (@, $, !, %, *, ?, &) enthalten.',
        'password.regex' => 'Das Passwort muss mindestens einen Kleinbuchstaben, einen Großbuchstaben, eine Ziffer und ein Sonderzeichen (@, $, !, %, *, ?, &) enthalten.',
    
        'name.required' => 'Bitte geben Sie Ihren Namen ein.',
        'phone.required' => 'Bitte geben Sie Ihre Telefonnummer ein.',
        'company.required' => 'Bitte geben Sie Ihren Firmennamen ein.',
        'street.required' => 'Bitte geben Sie Ihre Straße ein.',
        'zipcode.required' => 'Bitte geben Sie Ihre Postleitzahl ein.',
        'country.required' => 'Bitte wählen Sie Ihr Land aus.',
        'bank_account.required' => 'Bitte geben Sie Ihre Bankkontodaten ein.',
    
        'iban.required' => 'Bitte geben Sie Ihre IBAN ein.',
        'swift.required' => 'Bitte geben Sie Ihren SWIFT-Code ein.',
        'swift.regex' => 'Das SWIFT-Codeformat ist ungültig.',
    
        'image.required' => 'Bitte laden Sie ein Bild hoch.',
        'image.image' => 'Die Datei muss ein Bild sein (JPEG, PNG, JPG, GIF).',
        'image.mimes' => 'Das Bild muss eine Datei des folgenden Typs sein: jpeg, png, jpg, gif.',
        'image.max' => 'Das Bild darf nicht größer als 1 MB sein.',
    
        'about.required' => 'Bitte geben Sie eine Beschreibung ein.',
        'agb.accepted' => 'Sie müssen die Allgemeinen Geschäftsbedingungen (AGB) akzeptieren.',
        'datenschutzrichtlinie.accepted' => 'Sie müssen die Datenschutzerklärung akzeptieren.',
    ]);

      $uniqueid = (int) Counter::where('counter_id','partner')->first()->seq_value;

      $user = new User();
      $user->user_type = 2;
      $user->influencer_id = $request->influencer_id;
      $user->name = $request->name;
      $user->phone = $request->phone;
      $user->email = $request->email;
      $user->is_universal_partner = 0;
      

      if ($request->hasFile('image')) {
        $name = $request->image->getClientOriginalName();
        $filename =  date('ymdgis') . $name;
        $request->image->move(public_path() . '/storage/user/', $filename);
        $user->image = '/storage/user/' . $filename;
      }

      $user->password = Hash::make($request->password);
      $user->uuid =  Str::uuid($request->email);
      $user->partner_id =  'P'.str_pad(($uniqueid+1), 6, 0, STR_PAD_LEFT);


      $status_setting = Helper::getWebSetting('is_partner_released');
      if ($status_setting == 'yes') {
        $user->status = 0;
      } else {
        $user->status = 1;
      }

      $user->save();

      $details  = new UserDetail();
      $details->user_id = $user->id;
      $details->company = $request->company;
      $details->street = $request->street;
      $details->zipcode = $request->zipcode;
      $details->country = $request->country;
      $details->standard_sales_provision = Helper::getWebSetting('standard_sales_provision');

      if ($request->hasFile('video')) {
        $name = $request->video->getClientOriginalName();
        $filename =  date('ymdgis') . $name;
  
        $ext = pathinfo(public_path() . '/storage/user/' . $filename, PATHINFO_EXTENSION);
  
        if ($ext == 'png' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JPEG' || $ext == 'gif') {
          $request->video->move(public_path() . '/storage/user/', $filename);
          $details->video = '/storage/user/' . $filename;
          $video_image_type = 'image';
          $details->video_image_type = $video_image_type;
        } else if ($ext == 'mp4' || $ext == 'mov' || $ext == 'avi' || $ext == 'wmv') {
          $request->video->move(public_path() . '/storage/user/', $filename);
          $details->video = '/storage/user/' . $filename;
          $video_image_type = 'video';
          $details->video_image_type = $video_image_type;
        }
      }

      
      $details->youtube_code = $request->youtube_code;
      $details->vat_number = $request->vat_number;
      $details->bank_account = $request->bank_account;
      $details->iban = $request->iban;
      $details->swift = $request->swift;
      $details->about = $request->about;
      $details->comment = $request->comment;
      $details->save();

      $template_id = 1;
      $template = EmailTemplate::find($template_id);
      $data = ['name' => $request->name, 'partner_id' => '12345'];
      Mail::to($request->email)->send(new DynamicEmail($template, $data));

      $updateCounter = Counter::where("counter_id", 'partner')->update(["seq_value" => $user->id]);


      ///Auth::attempt($credentials);
      return redirect()->back()->with(['msg' => 'Your account has been created.']);
    }

    return redirect('/');
  }


  public function offerList(Request $request)
  {
    $user_id = Auth::user()->id;
    $data['products'] = Product::orderBy('id', 'desc')->where('user_id', $user_id)->paginate(15);
    return view('user.offer-list')->with($data);
  }

  public function addOffer(Request $request)
  {
    $data['categories'] = Category::where('status', 1)->orderby('id', 'desc')->get();
    $data['countries'] = Country::where('show_status', 1)->orderby('name', 'asc')->get();
    $data['product_categories'] = [];
    return view('user.add-offer')->with($data);
  }


  public function saveOffer(Request $request)
  {
    $validated = $request->validate([
      'title' => 'required|max:255',
      'vat' => 'required|numeric|between:0,100',
      'price_type' => 'required',
      'descriptions' => 'required',
      'voucher_type' => 'required',
      'category' => 'required|array',
  ]);
  
  // Apply conditional validation for 'image' if 'product_id' is not present
  if (!$request->product_id) {
      $validated = $request->validate([
          'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:1024',
      ]);
  }

    $lat = '';
    $lng = '';
    $api_key =  env('GOOGLE_API_KEY');
    $zip_code = $request->zip_code;
    $url = "https://maps.googleapis.com/maps/api/geocode/json?address=".$zip_code."&key=".$api_key;

    $response = Http::get($url);
    $data = $response->json();

    if($data['status'] == 'OK')
    {
      if(isset($data['results'][0]['geometry']['location']))
      {
        $lat = $data['results'][0]['geometry']['location']['lat'];
        $lng = $data['results'][0]['geometry']['location']['lng'];
      }
    }

    $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";
    $user_id = Auth::user()->id;
    $getPartner = User::where('id',$user_id)->first();
    $partner_id = $getPartner->partner_id;

    if (!$request->product_id) {
      $product = new Product();
      $msg = "Gutschein erfolgreich hinzugefügt.";
      $product->voucher_id = Helper::random_strings(7);
      $product->voucher_sales_provision = Helper::getPartnerSalesProvision($user_id);
    } else {
      $product = Product::findOrFail($request->product_id);
      $msg = "Gutschein erfolgreich aktualisiert.";
    }

    $validity_period = Helper::getWebSetting('voucher_validity_period');

    try {

      $setting_universal_email  = Helper::getWebSetting('universal_partner');
      $input_partner_email = Auth::user()->email;

      $voucher_id = Helper::random_strings(7);
      $product->user_id = $user_id;
      $product->partner_id = $partner_id;
      $product->category_id = $request->category_id;
      $product->title = $request->title;
      $product->country = $request->country;
      $product->price_type = $request->price_type;
      $product->price = $request->price;
      if ($request->price == '') {
        $product->minimum_price = $request->minimum_price;
        $product->maximum_price = $request->maximum_price;
      } else {
        $product->minimum_price = $request->price;
        $product->maximum_price = 0;
      }
      $product->vat = $request->vat;
      $product->affiliate_url = $request->affiliate_url;
      $product->descriptions = $request->descriptions;
      $product->additional_info = $request->additional_info;

      
      $product->latitude = $lat;
      $product->longitude = $lng;


      if ($request->hasFile('image')) {
        $name = $request->image->getClientOriginalName();
        $filename =  date('ymdgis') . $name;
        $request->image->move(public_path() . '/storage/product/', $filename);
        $product->image = '/storage/product/' . $filename;
      }

      if (!$request->product_id) {
        $product->slug = Str::slug($request->title, '-') . '-' . rand(0000, 9999);
        $product->voucher_id = $voucher_id;
        $product->offer_code = $voucher_id;
        $product->partner_product_id = Helper::getPartnerProductId($user_id);
      }

      $product->voucher_type = $request->voucher_type;
      $product->voucher_po = Helper::getWebSetting('voucher_po');
      if($request->voucher_validity_type != '')
      {
        $product->voucher_validity_type = $request->voucher_validity_type;
        $product->voucher_validity = $request->voucher_validity;
        $product->validity_message = $request->validity_message;
      } else
      {
        $product->voucher_validity_type = Helper::getWebSetting('voucher_validity_type');
        $product->voucher_validity = Helper::getWebSetting('voucher_validity_period');
      }

      if (!$request->product_id) {
      $product->termination_date = Carbon::now()->addMonths($validity_period);
      $product->offer_expire_at = Carbon::now()->addMonths($validity_period);
      }

      if($setting_universal_email == $input_partner_email)
      {
          $product->is_universal = 1;
      } else
      {
          $product->is_universal = 0; 
      }

      $product->zip_code = $request->zip_code;
      $product->status = $request->status;
      $product->updated_at = now();
      $product->save();

      $mpdf = new Mpdf();
      $viewData['product'] = $product;
      $viewData['partner'] = UserDetail::where('user_id', $product->user_id)->first();
      $viewData['voucher_id'] = $voucher_id;
      $viewData['voucher_code'] = $voucher_id;
      $viewData['net_price'] = $product->price;
      $html = view('pdf.voucher', $viewData)->render();
      // Define the file path where you want to save the PDF
      $filePath = public_path('pdf/voucher/') . $product->voucher_id . '.pdf';
      // Save the PDF to the server

      $footerHtml = $footer_info;
      $mpdf->SetHTMLFooter($footerHtml);
      $mpdf->WriteHTML($html);
      $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

      ///dd($product->id);
      if ($request->product_id) {
        $delete_category = ProductCategory::where('product_id', $request->product_id)->delete();
      }
      $category_data = [];
      $category = new ProductCategory();
      foreach ($request->category as $category) {
        $category_data[] = ['product_id' => $product->id, 'category_id' => $category, 'created_at' => date("Y-m-d H:i:s")];
      }
      ProductCategory::insert($category_data);
      return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
    } catch (Exception $e) {
      return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
    }
  }

  public function editOffer($id)
  {
    $user_id = Auth::user()->id;
    $nid = (int)$id;


    $product = Product::where(['id' => $nid])->first();
    $countries = Country::where('show_status', 1)->orderby('name', 'asc')->get();
    $categories = Category::where('status', 1)->orderby('id', 'desc')->get();
    $product_categories = ProductCategory::where('product_id', $id)->get()->pluck('category_id')->toArray();
    return view('user.add-offer', compact('product', 'categories', 'countries', 'product_categories'));
  }


  public function deleteOffer($id)
  {
    $user_id = Auth::user()->id;
    $product = Product::findOrFail($id);
 
     $chekOrder = OrderItem::where('product_id',$id)->count();

     if($chekOrder > 0)
     {
      $update =  Product::where('id',$id)->update(['status' => 0]);
      return response()->json(['msg' => 'Voucher Status updated']);
     }

    if (\File::exists(public_path($product->image))) {
      \File::delete(public_path($product->image));
    }

    if (\File::exists(public_path($product->video))) {
      \File::delete(public_path($product->video));
    }

    $delData = Redemption::where(['product_id' => $id, 'partner_id' => $user_id])->delete();
    $delData = OrderItem::where(['product_id' => $id, 'partner_id' => $user_id])->delete();
    $delData = Product::where(['id' => $id, 'user_id' => $user_id])->delete();
    return response()->json(['msg' => 'deleted']);
  }

  public function voucherRedemption(Request $request)
  {
    $data['categories'] = Category::where('status', 1)->orderby('id', 'desc')->get();
    return view('user.voucher-redemption')->with($data);
  }

  public function checkUniversalVoucher($voucher_id)
  {
    $product_id = OrderItem::where(['voucher_id' => $voucher_id])->first()->product_id;
    $product = Product::where('id',$product_id)->first();
    return $product['is_universal'] ?? 0;
  }

  public function previewRedemption(Request $request)
  {

    $this->validate($request, [
      'voucher_id' => 'required',
    ]);

    $user_id = Auth::user()->id;

    $checkProduct = OrderItem::where(['voucher_id' => $request->voucher_id])->first();
    if(!$checkProduct)
    {
      return redirect()->back()->with('msg', 'Bitte geben Sie eine gültige Gutschein-ID ein');
    }

    $universal_partner  = Helper::getWebSetting('universal_partner');
    $login_email = Auth::user()->email;

    $isUvoucher = $this->checkUniversalVoucher($request->voucher_id);
    //dd($isUvoucher);

    if($universal_partner == $login_email)
    {
      $data['voucher_item'] = OrderItem::where(['voucher_id' => $request->voucher_id])->first();
    } else if($isUvoucher == 1)
    {
      $data['voucher_item'] = OrderItem::where(['voucher_id' => $request->voucher_id])->first();
    } else
    {
      $data['voucher_item'] = OrderItem::where(['voucher_id' => $request->voucher_id, 'partner_id' => $user_id])->first();
    }

    
    //dd($data['voucher_item']);

    if (!$data['voucher_item']) {
      return redirect()->back()->with('msg', 'Bitte geben Sie eine gültige Gutschein-ID ein');
    }

    $order_pay_status = Order::where('id',$data['voucher_item']['order_id'])->first()->payment_status;
    $order_status = Order::where('id',$data['voucher_item']['order_id'])->first()->order_status;
    $payment_via = Order::where('id',$data['voucher_item']['order_id'])->first()->payment_via;

    if($order_pay_status != 3)
    {
      return redirect()->back()->with('msg', 'Bitte geben Sie eine gültige ID des bezahlten Gutscheins ein');
    }

    if($order_status == 3)
    {
      return redirect()->back()->with('msg', 'Ihre Bestellung wurde storniert');
    }

    if($order_status != 4 && $payment_via == 'Manual_Payment')
    {
      return redirect()->back()->with('msg', 'Die Bestellung wurde nicht abgeschlossen');
    }

    $data['redemption_balance'] = Redemption::where(['order_item_id' => $data['voucher_item']['id']])->orderBy('id', 'desc')->first()->balance_amount ?? '0.001';
    $data['balance_vat_amount'] = Redemption::where(['order_item_id' => $data['voucher_item']['id']])->orderBy('id', 'desc')->first()->balance_vat_amount ?? '0.001';
    ///$data['balance_vat_amount'] = Redemption::where(['order_item_id' => $data['voucher_item']['id']])->orderBy('id', 'desc')->sum('balance_vat_amount') ?? '0.001';
    $data['balance_net_amount'] = Redemption::where(['order_item_id' => $data['voucher_item']['id']])->orderBy('id', 'desc')->sum('balance_net_amount') ?? '0.001';
    $data['last_balance_amount'] = Redemption::where(['order_item_id' => $data['voucher_item']['id']])->orderBy('id', 'desc')->first()->balance_net_amount ?? '0.001';

    $data['voucher'] = Product::where(['id' => $data['voucher_item']['product_id']])->first();
    


    //$data['order'] = Order::where(['id' => $data['voucher_item']['order_id'],''])->first();
    $data['order'] = Order::where(['id' => $data['voucher_item']['order_id']])->first();
    //dd($data['order']['order_id']);
    return view('user.preview-redemption')->with($data);
  }


  public function applyRedemption(Request $request)
  {
    $user_id = Auth::user()->id;

    $universal_partner  = Helper::getWebSetting('universal_partner');
    $login_email = Auth::user()->email;
    $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";

    $isUvoucher = $this->checkUniversalVoucher($request->voucher_id);

    if($universal_partner == $login_email)
    {
      $voucherItem = OrderItem::where(['id' => $request->item_id])->first();
      $partner_id = $user_id;
    } else if($isUvoucher == 1)
    {
      $voucherItem = OrderItem::where(['id' => $request->item_id])->first();
      $partner_id = $user_id;
    } else
    {
      $voucherItem = OrderItem::where(['id' => $request->item_id, 'partner_id' => $user_id])->first();
      $partner_id = $voucherItem['partner_id'];
    }

   
  
    if (!$voucherItem) {
      return redirect()->back()->with('msg', 'Bitte geben Sie eine gültige Gutschein-ID ein');
    }

    $redemptionAmountSum = Redemption::where(['voucher_id' => $request->voucher_id])->sum('amount');
    //$voucherItemPrice = $voucherItem['price'];

    if ($voucherItem['net_price'] < ($redemptionAmountSum + $request->amount)) {
      return redirect()->back()->with('msg', 'Bitte geben Sie einen gültigen oder niedrigeren Betrag ein.');
    }

    ///$voucherItemCount = OrderItem::where(['voucher_id' => $request->voucher_id])->count();
    $redemptionCount = Redemption::where(['voucher_id' => $request->voucher_id])->count();
    $balance_amount = $voucherItem['net_price'] - ($redemptionAmountSum + $request->amount);

    $oItem = OrderItem::where('id',$voucherItem['id'])->first();
    //$partner_id = $oItem['partner_id'];
    $product_id = $oItem['product_id'];

    ///$standard_sales_provision = UserDetail::where('user_id', $partner_id)->first()->standard_sales_provision;
    //$standard_sales_provision = Helper::getRedemStandardVat($partner_id);
    $standard_sales_provision = Helper::getWebSetting('vat_sales_provision');
    // $vat_sales_provision = Product::where('id', $product_id)->first()->vat ?? 0;

    $vat_sales_provision = Helper::getOrderCNVat($voucherItem['id']); 

    ///$voucher_vat_sales_provision = Helper::getCNsalesProvision($product_id);
    $voucher_vat_sales_provision = Helper::getCNProvisionRate($voucherItem['order_id']);

    $redem_amount = $request->amount;
    $vat_amount =  Helper::CnVat($redem_amount,$vat_sales_provision);
    //dd($vat_amount);
    $net_amount =  $vat_amount;

    ///$standard_redem_amount =  Helper::CnVat($redem_amount,$standard_sales_provision);

    $standard_vat_amont = ($voucher_vat_sales_provision / 100) * $vat_amount; 

    $standard_redem = ($standard_sales_provision / 100) * $standard_vat_amont; 

    $standard_redem_amount = $standard_redem + $standard_vat_amont;
   ///dd($standard_redem_amount);

    $gross_total = $redem_amount - $standard_redem_amount;
    $vat_total = $net_amount - $standard_vat_amont;
    
    //$bal_vat_percentage = Helper::getVoucherVat($voucherItem['product_id'], $voucherItem['partner_id']);
    $bal_vat_percentage = Helper::getVoucherItemVat($voucherItem['id'],$voucherItem['product_id'], $voucherItem['partner_id']);
   
 
    $vat_percentage_dec = number_format((float)$bal_vat_percentage/100, 2, '.', '');
 
    $balance_net_amount = $balance_amount/(1+$vat_percentage_dec);

     $balance_vat_amount = number_format((float)($balance_amount - $balance_net_amount), 2, '.', '');

    //$balance_vat_amount =  ($redem_amount * $bal_vat_percentage)/100;
  

    $getProduct = Product::where(['id'=> $product_id])->first();
    $voucher_po = $getProduct['voucher_po'];

    ///$order = OrderItem::findOrFail($voucherItem['id']);
    $redemption = new Redemption();
    $redemption->order_id = $voucherItem['order_id'];
    $redemption->redemption_userid = $user_id;
    $redemption->order_item_id = $voucherItem['id'];
    $redemption->voucher_id = $request->voucher_id;
    $redemption->product_id = $getProduct['id'];
    $redemption->voucher_type = $getProduct['voucher_type'];
    $redemption->voucher_desc = $getProduct['title'];
    $redemption->partner_id = $voucherItem['partner_id'];
    $redemption->customer_id = $voucherItem['customer_id'];
    //$redemption->view_product_id = 'P'.Helper::getViewPartnerId($partner_id).'-'.Helper::getViewProductId($getProduct['id']);
    $redemption->view_product_id = Helper::getViewPartnerProductId($partner_id,$getProduct['partner_product_id']) ?? '';
    ///$redemption->view_partner_id = Helper::getViewPartnerId($partner_id);
    $redemption->view_partner_id = $partner_id ?? '';
    $redemption->redemption_id = 'R-' . $request->voucher_id . '-' . ($redemptionCount + 1);
    $redemption->credit_note_id = 'CN-' . $request->voucher_id . '-' . ($redemptionCount + 1);
    $redemption->voucher_sales_provision_rate = $voucher_vat_sales_provision;
    $redemption->standard_sales_rate = $standard_sales_provision;
    $redemption->vat_sales_rate = $vat_sales_provision;

    $redemption->vat_amount = $vat_amount;
    $redemption->standard_amount = $standard_vat_amont;
    $redemption->standard_redem_amount = $standard_redem_amount;
    $redemption->amount = $request->amount;
    $redemption->net_amount = $net_amount;

    $redemption->gross_total = $gross_total;
    $redemption->vat_total = $vat_total;
   
    $redemption->balance_amount = number_format((float)($balance_amount), 2, '.', '');
    $redemption->balance_vat_amount = number_format((float)($balance_vat_amount), 2, '.', '');
    $redemption->balance_net_amount = number_format((float)($balance_net_amount), 2, '.', '');
    $redemption->save();
    ///dd($balance_vat_amount);
    if ($redemption) {
      $mail_data['order'] = Order::where('id', $voucherItem['order_id'])->first();
      $mail_data['customer'] = Customer::where('id',$mail_data['order']['customer_id'])->first();
      $mail_data['order_items'] = OrderItem::where('order_id', $voucherItem['order_id'])->with('product')->get();
      $mail_data['cn_items'] = Redemption::where('id', $redemption->id)->get();
      $mail_data['user'] = User::where('id',$user_id)->first();
      $data['partner'] = User::where('id',$user_id)->first();
      $data['partner_details'] = UserDetail::where('user_id',$user_id)->first();
      $data['order'] = Order::where('id', $voucherItem['order_id'])->first();
      $data['order_items'] = OrderItem::where('order_id', $voucherItem['order_id'])->with('product')->get();
      $data['cn_items'] = Redemption::where('id', $redemption->id)->get();
      $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
      $data['credit_note_id'] = 'CN-' . $request->voucher_id . '-' . ($redemptionCount + 1);
      $data['credit_date'] = date('d M, Y');
      $data['standard_sales_provision'] = $standard_sales_provision;
      $data['vat_sales_provision'] = $vat_sales_provision;
      $data['standard_amount'] = $standard_vat_amont;
      $data['vat_amount'] = $vat_amount;
      $data['net_amount'] = $net_amount;
      $data['voucher_po'] = $voucher_po;
      

      $mpdf = new Mpdf();
      $html = view('pdf.credit-note', $data)->render();
      $filePath = public_path('pdf/invoice/') . 'CN-' . $request->voucher_id . '-' . ($redemptionCount + 1) . '.pdf';

      $footerHtml = $footer_info;
      $mpdf->SetHTMLFooter($footerHtml);
      $mpdf->WriteHTML($html);
      $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

      $attachments[] = [
        'file' => public_path('pdf/invoice/' . 'CN-' . $request->voucher_id . '-' . ($redemptionCount + 1) . '.pdf'),
        'options' => [
          'mime' => 'application/pdf',
          'as' => 'CN-' . $request->voucher_id . '-' . ($redemptionCount + 1) . '.pdf',
        ],
        // Add more attachments with options as needed
      ];

      $universal_partner  = Helper::getWebSetting('universal_partner');
      $login_email = Auth::user()->email;
  
      if($universal_partner == $login_email)
      {
        $recever_email = $universal_partner;
        $cc_email = $mail_data['user']['email'];
        
        Mail::to($recever_email)
        ->cc($cc_email)
        ->send(new CreditNoteMail($mail_data, $attachments));
      }  else if($isUvoucher == 1)
      { 
        Mail::to($login_email)->send(new CreditNoteMail($mail_data, $attachments));
      }else
      {
        $recever_email = $mail_data['user']['email'];
        Mail::to($recever_email)->send(new CreditNoteMail($mail_data, $attachments));
      }

      
    }

    return redirect()->back()->with('msg', 'Gutschein erfolgreich eingelöst');
  }


  public function updateUserPassword(Request $request)
  {
    $validatedData = $request->validate([
      'current_password' => 'required',
      'password' => [
          'required',
          'string',
          'min:6',              // Minimum length of 6 characters
          'regex:/[a-z]/',      // At least one lowercase letter
          'regex:/[A-Z]/',      // At least one uppercase letter
          'regex:/[0-9]/',      // At least one digit
          'regex:/[@$!%*?&#]/', // At least one special character
      ],
      'password_confirmation' => 'required|same:password',
  ], [
      // Custom error messages for password validation
      'password.required' => 'Bitte geben Sie Ihr neues Passwort ein.',
      'password.min' => 'Das Passwort muss aus mindestens 6 Zeichen bestehen und einen Kleinbuchstaben, einen Großbuchstaben, eine Ziffer und ein Sonderzeichen (@, $, !, %, *, ?, &) enthalten.',
      'password.regex' => 'Das Passwort muss mindestens einen Kleinbuchstaben, einen Großbuchstaben, eine Ziffer und ein Sonderzeichen (@, $, !, %, *, ?, &) enthalten.',
      'password_confirmation.required' => 'Bitte bestätigen Sie Ihr neues Passwort.',
      'password_confirmation.same' => 'Die Passwortbestätigung stimmt nicht überein.',
  ]);
    $user_password = Auth::User()->password;

    if (Hash::check($request->current_password, $user_password)) {
      $user_id = Auth::user()->id;
      $obj_user = User::find($user_id);
      $obj_user->password = Hash::make($request->password);
      $obj_user->save();
      return redirect()->back()->with('msg', 'Passwort erfolgreich geändert.');
    } else {
      return redirect()->back()->with('msg', 'Bitte geben Sie ein gültiges aktuelles Passwort ein.');
    }
  }


  public function updateProfile(Request $request)
  {
    $this->validate($request, [
      'email' => 'required',
      'name' => 'required',
      'phone' => 'required',
      'company' => 'required',
      'street' => 'required',
      'zipcode' => 'required',
      'country' => 'required',
      //'vat_number' => 'required',
      'bank_account' => 'required',
      // 'iban' => 'required',
      // 'swift' => 'required',
      'iban' => ['required', new Iban],
      'swift' => ['required', 'regex:/^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/'],
      ///'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
      'about' => 'required',
      ///'comment' => 'required',
    ]);

    $user_id = Auth::user()->id;
    $user = User::firstOrNew(['id' =>  $user_id]);
    $user->user_type = 2;
    $user->name = $request->name;
    $user->phone = $request->phone;
    $user->email = $request->email;


    if ($request->hasFile('image')) {
      $name = $request->image->getClientOriginalName();
      $filename =  date('ymdgis') . $name;
      $request->image->move(public_path() . '/storage/user/', $filename);
      $user->image = '/storage/user/' . $filename;
    }

    $user->uuid =  Str::uuid($request->email);
    $user->status = $request->status;
    $user->updated_at = now();
    $user->save();

    $details = UserDetail::firstOrNew(['user_id' =>  $user->id]);
    ///dd($details);
    $details->user_id = $user->id;
    $details->company = $request->company;
    $details->street = $request->street;
    $details->zipcode = $request->zipcode;
    $details->country = $request->country;

    if ($request->hasFile('video')) {
      $name = $request->video->getClientOriginalName();
      $filename =  date('ymdgis') . $name;

      $ext = pathinfo(public_path() . '/storage/user/' . $filename, PATHINFO_EXTENSION);

      if ($ext == 'png' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JPEG' || $ext == 'gif') {
        $request->video->move(public_path() . '/storage/user/', $filename);
        $details->video = '/storage/user/' . $filename;
        $video_image_type = 'image';
        $details->video_image_type = $video_image_type;
      } else if ($ext == 'mp4' || $ext == 'mov' || $ext == 'avi' || $ext == 'wmv') {
        $request->video->move(public_path() . '/storage/user/', $filename);
        $details->video = '/storage/user/' . $filename;
        $video_image_type = 'video';
        $details->video_image_type = $video_image_type;
      }
    }

    $details->vat_number = $request->vat_number;
    $details->bank_account = $request->bank_account;
    $details->iban = $request->iban;
    $details->swift = $request->swift;
    $details->youtube_code = $request->youtube_code;
    $details->about = $request->about;
    $details->comment = $request->comment;
    $details->save();


    return redirect()->back()->with('msg', 'Profil erfolgreich aktualisiert.');
  }


  public function deleteKey($id)
  {
    $user_id = Auth::user()->id;
    $user = UserDetail::where('user_id',$user_id)->first();
    if (\File::exists(public_path($user->video))) {
      \File::delete(public_path($user->video));
    }

    if($user)
     {
      $update =  UserDetail::where('user_id',$user_id)->update(['video' => NULL , 'video_image_type' => NULL]);
     }
     return redirect()->back()->with('msg', 'Profil erfolgreich aktualisiert.');
  }



}
