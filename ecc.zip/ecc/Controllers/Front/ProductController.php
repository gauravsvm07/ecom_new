<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Enquiry;
use App\Models\Blog;
use App\Models\Category;
use App\Models\Product;
use App\Models\Download;
use App\Models\Page;
use App\Models\Testimonial;
use App\Models\Partner;
use App\Models\Menu;
use App\Models\PageSection;
use App\Models\User;
use App\Models\UserDetail;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use App\Helpers\Helper;
use Exception;
use Artisan;
use Mail;
use Captcha;


class ProductController extends Controller
{

   public function products(Request $request)
   {
      $data['banners'] = Banner::orderBy('id','desc')->where('type','home')->get();
      $universal_prioritation  = Helper::getWebSetting('universal_prioritation');
      if($universal_prioritation == 1)
      {
        $order_by = 'is_universal';
      } else
      {
        $order_by = 'title';
      }
      ///$data['products'] = Product::where(['status' => 1])->orderBy($order_by,'desc')->get();

      $data['products'] = Product::where('products.status', 1) // Ensure product status is active
      ->join('users', 'products.user_id', '=', 'users.id') // Join with users table
      ->where('users.status', 1) // Ensure user status is active
      ->orderBy($order_by, 'desc') // Order by your specified column
      ->select('products.*') // Select products only
      ->get();
      return view('front.products')->with($data);
   }

   public function productDetail(Request $request, $slug)
   {
      $data['product'] = Product::where(['slug' => $slug])->first();
      ///dd($data['product']);
      if ($data['product']) {
         $user_id = $data['product']['user_id'];
         $data['voucherUser'] = User::where('id', $user_id)->first();
         $data['voucherUdetail'] = UserDetail::where('user_id', $user_id)->first();
      } else {
         dd('Invalid url');
      }
      $wishlist = Session::get('wishlist', []);

      if (count($wishlist) > 0) {
         foreach ($wishlist as $list) {
            if ($list->offer_id == $data['product']->id) {
               $is_wishlist = 1;
               break;
            } else {
               $is_wishlist = 0;
            }
         }
      } else {
         $is_wishlist = 0;
      }
      $data['is_wishlist'] = $is_wishlist;
      return view('front.product-detail')->with($data);
   }

   public function oldsearch(Request $request)
   {
      
      $products = Product::where('title', 'like', '%' . $request->keyword . '%')->where(['status'=>1 , ''])->get();
      if(count($products) > 0)
      {
         $universal_prioritation  = Helper::getWebSetting('universal_prioritation');
         if($universal_prioritation == 1)
         {
           $order_by = 'is_universal';
         } else
         {
           $order_by = 'title';
         }
         $data['products'] = Product::where('title', 'like', '%' . $request->keyword . '%')->where('status', 1)->orderBy($order_by,'desc')->get();
         return view('front.products')->with($data);
      } else
      {
         $data['partners'] = User::where('name', 'like', '%' . $request->keyword . '%')->where('status',1)->paginate(10);
         return view('front.partners')->with($data);
      }
      
   }

   public function search(Request $request)
{
   $data['banners'] = Banner::orderBy('id','desc')->where('type','home')->get();
    // Search products by title
    $products = Product::where('title', 'like', '%' . $request->keyword . '%')
                        ->where('status', 1)  // Corrected 'where' condition
                        ->get();

    // If products are found
    if(count($products) > 0)
    {
        $universal_prioritation = Helper::getWebSetting('universal_prioritation');
        
        // Choose the order by column based on the universal prioritization setting
        $order_by = $universal_prioritation == 1 ? 'is_universal' : 'title';
        
        // Retrieve products with the chosen order
        $data['products'] = Product::where('title', 'like', '%' . $request->keyword . '%')
                                   ->where('status', 1)
                                   ->orderBy($order_by, 'desc')
                                   ->get();
        
        return view('front.products')->with($data);
    }
    else
    {
        // If no products found, search for partners
        $data['partners'] = User::where('name', 'like', '%' . $request->keyword . '%')
                                ->where('status', 1)
                                ->paginate(10);
        
        return view('front.partners')->with($data);
    }
}


   public function filterProducts(Request $request)
   {
      $categoryIds = $request->input('categories');
      $countryIds = $request->input('countries');
      $productTypeIds = $request->input('productTypes');
      $min_price = $request->input('min_price');
      $max_price = $request->input('max_price');
      //$maxPrice = $request->input('maxPrice');
      $maxPrice = $request->input('price');
      $title = $request->input('title');

      $radius = $request->input('radius');
      $currentLatitude = '28.6162944';
      $currentLongitude = '77.3750784';
      $zip_code = $request->input('zip_code');

      $universal_prioritation  = Helper::getWebSetting('universal_prioritation');
      if($universal_prioritation == 1)
      {
        $order_by = 'is_universal';
      } else
      {
        $order_by = 'title';
      }

      $url = "https://www.googleapis.com/geolocation/v1/geolocate?key=".env('GOOGLE_API_KEY');
      $response = Http::post($url, [
         'considerIp' => "true",
      ]);

       $res = $response->body();
       $json = $response->json();
       if($json)
       {
         $currentLatitude = $json['location']['lat'];
         $currentLongitude = $json['location']['lng'];
       }
       

      //$haversine = $this->getDistance($latitude, $longitude);


      // Get stores within the specified radius
      // $storesWithinRadius = Product::all()->filter(function ($product) use ($currentLatitude, $currentLongitude, $radius) {
      //    // Store coordinates
      //    $productLatitude = $product->latitude;
      //    $productLongitude = $product->longitude;

      //    // Calculate distance using Haversine formula
      //    $distance = $this->calculateDistance($currentLatitude, $currentLongitude, $productLatitude, $productLongitude);

      //    // Check if the distance is within the radius
      //    return $distance <= $radius;
      // });

      // dd($storesWithinRadius);

      $query = Product::query();

      if (!empty($categoryIds)) {
         $query->join('product_categories', 'products.id', '=', 'product_categories.product_id')
            ->whereIn('product_categories.category_id', $categoryIds)
            ->select('products.*','products.id as id')
            ->distinct();
         //    $query->whereHas('categories', function ($query) use ($categoryIds) {
         //        $query->whereIn('id', $categoryIds);
         //    });
      }

      if (!empty($countryIds)) {
         $query->whereIn('country', $countryIds);
      }

      if (!empty($productTypeIds)) {
         $query->whereIn('voucher_type', $productTypeIds);
      }

      // $query->select('*')
      // ->selectRaw(
      //     '( 6371 * acos( cos( radians(?) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(?) ) + sin( radians(?) ) * sin( radians( latitude ) ) ) ) AS distance',
      //     [$currentLatitude, $currentLongitude, $currentLatitude]
      // );
      //->having('distance', '<', $maxDistance);

      if (!empty($max_price)) {
         ///$query->where('minimum_price', '<=', $min_price);
         $query->whereBetween('minimum_price', [$min_price, $max_price]);
      }

      // if (!empty($minPrice)) {
      //    $query->where('price', '>=', $minPrice);
      // }

      // if (!empty($maxPrice)) {
      //    $query->where('price', '<=', $maxPrice);
      // }



      if (!empty($title)) {
         $query->where('title', 'like', '%' . $title . '%');
      }

      if (!empty($zip_code)) {
         $query->where('zip_code', '=',  $zip_code);
      }
      // Apply radius search
      // Calculate distance using Haversine formula and filter by radius
      // $query->selectRaw(
      //    '*, (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance',
      //    [$currentLatitude, $currentLongitude, $currentLatitude]
      // )
      //    ->having('distance', '<=', $radius)
      //    ->orderBy('distance');

      $data['products'] = $query->orderBy($order_by,'desc')->get();

      // ->filter(function ($product) use ($currentLatitude, $currentLongitude, $radius) {
      //    // Store coordinates
      //    $productLatitude = $product->latitude;
      //    $productLongitude = $product->longitude;

      //    // Calculate distance using Haversine formula
      //    $distance = $this->calculateDistance($currentLatitude, $currentLongitude, $productLatitude, $productLongitude);

      //    // Check if the distance is within the radius
      //    return $distance <= $radius;
      // });

      return view('front.get-products')->with($data);
      ///return response()->json(['products' => $products]);
   }
   private function calculateDistance($lat1, $lon1, $lat2, $lon2)
   {
      $earthRadius = 6371; // Earth radius in kilometers

      // Convert latitude and longitude from degrees to radians
      $latFrom = deg2rad($lat1);
      $lonFrom = deg2rad($lon1);
      $latTo = deg2rad($lat2);
      $lonTo = deg2rad($lon2);

      // Calculate the distance using Haversine formula
      $latDelta = $latTo - $latFrom;
      $lonDelta = $lonTo - $lonFrom;
      $distance = 2 * $earthRadius * asin(sqrt(pow(sin($latDelta / 2), 2) + cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));

      return $distance;
   }

   public function getDistance($latitude, $longitude)
   {
      $distance = "(6371 * acos(cos(radians($latitude)) 
                        * cos(radians(latitude)) 
                        * cos(radians(longitude) 
                        - radians($longitude)) 
                        + sin(radians($latitude)) 
                        * sin(radians(latitude))))";

      return $distance;
   }
}
