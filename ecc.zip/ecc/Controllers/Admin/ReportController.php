<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Order;
use Mpdf\Mpdf;
use PDF;
use Exception;
use File;
use DB;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $data['reports'] = Order::orderBy('id', 'desc')->paginate(15);
        return view('admin.report.index')->with($data);
    }

    public function create(Request $request ,$type)
    {
         //DB::enableQueryLog();
         $date_from = date('Y-m-d 00:00:00', strtotime($request->date_from)); // Start of the day
         $date_to = date('Y-m-d 23:59:59', strtotime($request->date_to)); // End of the day
         $reports = Order::orderBy('id', 'desc')
             ->whereBetween('created_at', [$date_from, $date_to])
             ->get();
         ///dd($reports);
         $html = view('pdf.report', compact('reports'))->render();
         $mpdf = new Mpdf();
         $mpdf->WriteHTML($html);
         return $mpdf->Output();
        //dd(DB::getQueryLog());
         ///dd($reports);
        ///return view('admin.report.report-form');
    }


}
