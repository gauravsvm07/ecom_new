<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Response;
use App\Models\Influencer;
use App\Helpers\Helper;
use Exception;
use File;

class InfluencerController extends Controller
{
    public function index(Request $request)
    {
        $data['influencers'] = Influencer::orderBy('id','desc')->paginate(15);
        return view('admin.influencer.index')->with($data);
    }


    public function export(Request $request)
    {

        $influencers = Influencer::orderBy('id', 'desc')->get();


        if ($influencers->isNotEmpty()) {
            // Set the headers for CSV download
            $headers = [
                'Content-type'        => 'text/csv',
                'Content-Disposition' => 'attachment; filename="influencers.csv"',
                'Pragma'              => 'no-cache',
                'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
                'Expires'             => '0',
            ];

            // Create a callback function to generate the CSV
            $callback = function () use ($influencers) {
                $output = fopen('php://output', 'w');

                // Save the column headers
                $columns = ['Influencer ID','Influencer Link', 'Name', 'Email', 'Phone', 'Address', 'Country', 'State', 'City', 'Facebook Link', 'Instagram Link', 'Youtube Link', 'X Link (twitter)', 'Status'];
                fputcsv($output, $columns);

                // Output each row of the data
                foreach ($influencers as $influencer) {

                    $status = $influencer->status;
                    if($status == 1)
                    {
                        $influencer_status = 'Active';
                    } else
                    {
                        $influencer_status = 'Inactive';
                    }

                    $influencer_link = url('register/'.$influencer->influencer_id);
                   
                    
                    $row = [
                        $influencer->influencer_id ?? '',
                        $influencer_link ?? '',
                        $influencer->name ?? '',
                        $influencer->email ?? '',
                        $influencer->phone ?? '',
                        $influencer->address ?? '',
                        $influencer->country ?? '',
                        $influencer->state ?? '',
                        $influencer->city ?? '',
                        $influencer->fb_link ?? '',
                        $influencer->instaa_link ?? '',
                        $influencer->youtube_link ?? '',
                        $influencer->twitter_link ?? '',
                        $influencer_status ?? '',
                    ];
                    fputcsv($output, $row);
                }

                fclose($output);
            };

            return Response::stream($callback, 200, $headers);
        } else {
            return response()->json(['message' => 'No records found.'], 404);
        }
    }



    public function create(Request $request)
    {
        return view('admin.influencer.influencer-form');
    }


    public function save(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required',
            'phone' => 'required',
            'status' => 'required'
        ]);

        if (!$request->influencer_id) {
            $influencer = new Influencer();
            $msg = "Influencer added successfully.";
        } else {
            $influencer = Influencer::findOrFail($request->influencer_id);
            $msg = "Influencer updated successfully.";
        }
       
        try {
            $influencer->influencer_id = Helper::getInfluencerId();
            $influencer->name = $request->name;
            $influencer->email = $request->email;
            $influencer->phone = $request->phone;
            $influencer->address = $request->address;
            $influencer->country = $request->country;
            $influencer->state = $request->state;
            $influencer->city = $request->city;
            $influencer->fb_link = $request->fb_link;
            $influencer->instaa_link = $request->instaa_link;
            $influencer->twitter_link = $request->twitter_link;
            $influencer->youtube_link = $request->youtube_link;
            $influencer->status = $request->status;
            $influencer->save();
            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
        return redirect()->back()->with(['message' => 'Invalid Action']);

        $influencer = Influencer::findOrFail($id);

        if ($type == "edit") {
            return view('admin.influencer.influencer-form', compact('influencer'));
        }
        if ($type == "delete") {
            $delData = Influencer::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $influencer->status = $influencer->status == 1 ? 0 : 1;
            $influencer->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
