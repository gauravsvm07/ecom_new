<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\EmailTemplate;
use Exception;
use File;

class EmailTemplateController extends Controller
{
    public function index(Request $request)
    {
        $data['templates'] = EmailTemplate::orderBy('id', 'desc')->paginate(15);
        return view('admin.email-template.index')->with($data);
    }

   

    public function create(Request $request)
    {
        return view('admin.email-template.template-form');
    }


    public function save(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'subject' => 'required|max:255',
            'body' => 'required',
            'status' => 'required',
        ]);

        if (!$request->template_id) {
            $template = new EmailTemplate();
            $msg = "Email Template Added Successfully.";
        } else {
            $template = EmailTemplate::findOrFail($request->template_id);
            $msg = "Email Template updated Successfully.";
        }

        try {
            $template->name = $request->name;
            $template->subject = $request->subject;
            $template->body = $request->body;
            $template->status = $request->status;
            $template->save();
            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $template = EmailTemplate::findOrFail($id);

        if ($type == "edit") {
            return view('admin.email-template.template-form', compact('template'));
        }
        if ($type == "delete") {
            $delData = EmailTemplate::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $template->status = $template->status == 1 ? 0 : 1;
            $template->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
