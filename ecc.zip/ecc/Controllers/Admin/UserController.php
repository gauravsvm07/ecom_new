<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Response;
use App\Models\User;
use App\Models\Category;
use App\Models\UserDetail;
use App\Models\Device;
use App\Models\UserVerify;
use App\Models\Country;
use App\Models\Product;
use App\Models\EmailTemplate;
use Illuminate\Support\Facades\Http;
use App\Helpers\Helper;
use App\Mail\DynamicEmail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Mail;
use Exception;
use File;
use Hash;

class UserController extends Controller
{
    public function index()
    {
        $data['users'] = User::select('users.*', 'users.id as uid')->orderBy('id', 'desc')->get();

        return view('admin.user.index')->with($data);
    }


    public function export(Request $request)
    {

        $users = User::select('users.*','user_details.*', 'users.created_at as created_date' , 'users.updated_at as updated_date')
        ->leftJoin('user_details', 'user_details.user_id', '=', 'users.id')
        ->orderBy('users.id', 'desc')
        ->get();


        if ($users->isNotEmpty()) {
            // Set the headers for CSV download
            $headers = [
                'Content-type'        => 'text/csv',
                'Content-Disposition' => 'attachment; filename="partners.csv"',
                'Pragma'              => 'no-cache',
                'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
                'Expires'             => '0',
            ];

            // Create a callback function to generate the CSV
            $callback = function () use ($users) {
                $output = fopen('php://output', 'w');

                // Save the column headers
                $columns = ['Partner ID','Created Date', 'Updated Date', 'Company', 'Contact Person ', 'Email Id ', 'Phone', 'Address', 'VAT Number', 'Partner Sales Provision(%)', 'Bank account owner ', 'IBAN', 'SWIFT', 'Image', 'Video', 'Story', 'Internal comment ', 'Status'];
                fputcsv($output, $columns);

                // Output each row of the data
                $base_url = URL::to('/');
                foreach ($users as $user) {

                    $status = $user->status;
                    if($status == 1)
                    {
                        $users_status = 'Active';
                    } else
                    {
                        $users_status = 'Inactive';
                    }

                    $video_image_type = Helper::getFileType($user->video);

                    if($video_image_type == 'video')
                    {
                        $video_file = $base_url.$user->video;
                    } else
                    {
                        $video_file = $user->youtube_code;
                    }

                    if($video_image_type == 'image')
                    {
                        $image_file = $user->video;
                    } else
                    {
                        $image_file = '';
                    }
                    
                    $row = [
                        $user->partner_id ?? '',
                        $user->created_date ?? '',
                        $user->updated_date ?? '',
                        $user->company ?? '',
                        $user->name ?? '',
                        $user->email ?? '',
                        $user->phone ?? '',
                        $user->address ?? '',
                        $user->vat_number ?? '',
                        $user->standard_sales_provision ?? '',
                        $user->bank_account ?? '',
                        $user->iban ?? '',
                        $user->swift ?? '',
                        $base_url.$user->image ?? '',
                        ///$image_file ?? '',
                        $video_file ?? '',
                        $user->about ?? '',
                        $user->comment ?? '',
                        $users_status ?? '',
                    ];
                    fputcsv($output, $row);
                }

                fclose($output);
            };

            return Response::stream($callback, 200, $headers);
        } else {
            return response()->json(['message' => 'No records found.'], 404);
        }
    }




    public function create(Request $request)
    {
        $data['categories'] = Category::orderBy('id', 'desc')->get();
        $data['countries'] = Country::orderBy('name', 'asc')->where('show_status', 1)->get();
        return view('admin.user.user-form')->with($data);
    }


    public function save(Request $request)
    {

        if (!$request->user_id) {
            $this->validate($request, [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
            ]);
        } else {
            $this->validate($request, [
                'name' => 'required',
            ]);
        }

        $validated = $request->validate([
            'email' => 'required',
            'name' => 'required',
            'phone' => 'required',
            'company' => 'required',
            'street' => 'required',
        'zipcode' => 'required',
        'country' => 'required',
            'bank_account' => 'required',
            'iban' => 'required',
            'swift' => 'required',
            //'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'about' => 'required',
            ///'comment' => 'required',
        ]);

        if (!$request->user_id) {
            $user = new User();
            $msg = "User Added Successfully.";
        } else {
            $user = User::findOrFail($request->user_id);
            $partner_id = 'P'.str_pad(($request->user_id), 6, 0, STR_PAD_LEFT);
            $user->partner_id = $partner_id;
            $msg = "User updated Successfully.";
        }
        try {

            if ($request->user_id != '') {
                $old_status = User::where('email',$request->email)->first()->status;
                $new_status = $request->status;
                if($old_status == 0 && $new_status == 1)
                {
                    $template_id = 2;
                    $template = EmailTemplate::find($template_id);
                    $data = ['name' => $request->name, 'partner_id' => '12345'];
                    Mail::to($request->email)->send(new DynamicEmail($template, $data));
                }
               
            } else
            {
                $user->is_universal_partner = 0;
            }

            $user->user_type = 2;
            $user->name = $request->name;
            $user->phone = $request->phone;
            $user->email = $request->email;
            //$user->password = Hash::make($request->email);

            if ($request->hasFile('image')) {
                $name = $request->image->getClientOriginalName();
                $filename =  date('ymdgis') . $name;
                $request->image->move(public_path() . '/storage/user/', $filename);
                $user->image = '/storage/user/' . $filename;
            }

            $user->uuid =  Str::uuid($request->email);
            $user->status = $request->status;
            $user->updated_at = now();
            $user->save();

            $details = UserDetail::firstOrNew(['user_id' =>  $user->id]);
            $details->user_id = $user->id;
            $details->company = $request->company;
            $details->street = $request->street;
            $details->zipcode = $request->zipcode;
            $details->country = $request->country;

           

            if ($request->hasFile('video')) {
                $name = $request->video->getClientOriginalName();
                $filename =  date('ymdgis') . $name;
          
                $ext = pathinfo(public_path() . '/storage/user/' . $filename, PATHINFO_EXTENSION);
          
                if ($ext == 'png' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JPEG' || $ext == 'gif') {
                  $request->video->move(public_path() . '/storage/user/', $filename);
                  $details->video = '/storage/user/' . $filename;
                  $video_image_type = 'image';
                  $details->video_image_type = $video_image_type;
                } else if ($ext == 'mp4' || $ext == 'mov' || $ext == 'avi' || $ext == 'wmv') {
                  $request->video->move(public_path() . '/storage/user/', $filename);
                  $details->video = '/storage/user/' . $filename;
                  $video_image_type = 'video';
                  $details->video_image_type = $video_image_type;
                }
              }
            $details->vat_number = $request->vat_number;
            $details->standard_sales_provision = $request->standard_sales_provision;
            $details->bank_account = $request->bank_account;
            $details->iban = $request->iban;
            $details->swift = $request->swift;
            $details->about = $request->about;
            $details->comment = $request->comment;
            $details->youtube_code = $request->youtube_code;
            


            if ($request->user_id) {
                if ($request->vat_number !== $user->vat_number) {
                    $response = Http::get('https://anyapi.io/api/v1/vat/validate', [
                        'vat_number' => $request->vat_number,
                        'apiKey' => env('VAT_API_KEY')
                    ]);

                    $vat_data = $response->json();
                    ///dd($vat_data);
                    $details->vat_verify = $vat_data ?? '';
                }
            }

            $details->save();

           


            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $user = User::findOrFail($id);

        if ($type == "edit") {
            $data['countries'] = Country::orderBy('name', 'asc')->where('show_status', 1)->get();
            $data['user'] = $user;
            $data['user_detail'] = UserDetail::where('user_id', $data['user']->id)->first();

            return view('admin.user.user-form')->with($data);
        }
        if ($type == "delete") {
            if (\File::exists(public_path($user->image))) {
                \File::delete(public_path($user->image));
            }
            $delUserDetail = UserDetail::where('user_id', $id)->delete();
            $delProducts = Product::where('user_id', $id)->delete();
            $delUserDevice = Device::where('user_id', $id)->delete();
            $delUserVerify = UserVerify::where('user_id', $id)->delete();
            $delData = User::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $user->status = $user->status == 1 ? 0 : 1;
            $user->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
