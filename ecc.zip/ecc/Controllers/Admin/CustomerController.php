<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Customer;
use App\Models\Category;
use App\Models\CustomerDetail;
use App\Models\Device;
use App\Models\CustomerVerify;
use App\Models\Booking;
use Illuminate\Support\Facades\Http;
use Exception;
use File;
use Hash;

class CustomerController extends Controller
{
    public function index()
    {
        $data['customers'] = Customer::orderBy('id', 'desc')->paginate(15);
        return view('admin.customer.index')->with($data);
    }


    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $customer = Customer::findOrFail($id);

        if ($type == "edit") {
            $data['customer'] = $customer;
            return view('admin.customer.customer-form')->with($data);
        }

        if ($type == "delete") {
            if (\File::exists(public_path($customer->image))) {
                \File::delete(public_path($customer->image));
            }
            $delData = Customer::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $customer->status = $customer->status == 1 ? 0 : 1;
            $customer->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
