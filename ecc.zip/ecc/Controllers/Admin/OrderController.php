<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\OrderAddress;
use App\Models\Notification;
use App\Models\UserDetail;
use App\Models\Admin;
use App\Models\Customer;
use App\Models\OrderStatus;
use App\Models\Redemption;
use App\Models\OrderDoc;
use App\Models\ManualOrder;
use App\Models\WebSetting;
use App\Mail\OrderCancelMail;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use Hash;
use Mpdf\Mpdf;
use PDF;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $data['orders'] = Order::orderBy('id', 'desc')->get();
        return view('admin.order.index')->with($data);
    }


    public function invoiceExport()
    {
        ///dd('test');
        // Define the headers for the CSV download response
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="orders_export.csv"',
        ];
    
        // Return a StreamedResponse to stream the CSV content
        return new StreamedResponse(function () {
            // Open a file pointer connected to the output stream
            $file = fopen('php://output', 'w');
    
            // Define the CSV headers
            $csvHeader = [
                'Invoice ID',
                'Invoice Date',
                'Order ID',
                'Order Status',
                'Payment ID',
                'Payment Date',
                'Payment via',
                'Payment Status',
                'Customer Name',
                'Customer Email',
                'Customer Phone',
                'Customer Address',
                'Customer Country',
                'Customer City',
                'Customer ZIP Code',
                'Product ID',
                'Product Title',
                'Voucher Type',
                'Related Partner ID',
                'Related Company',
                'Quantity',
                'Net Price',
                'VAT Rate (%)',
                'VAT Amount',
                'Gross Price'
            ];
    
            // Output the header row
            fputcsv($file, $csvHeader);
    
            // Fetch orders with their items and customers
            $orders = Order::with(['items', 'customer'])->get();
    
            // Loop through orders, items, and customer details
            foreach ($orders as $order) {
                $order_status = OrderStatus::where('id', $order->order_status)->first()->name;
                
                foreach ($order->items as $item) {

                    $partner_product_id = Product::where('id',$item->product_id)->first()->partner_product_id ?? '';
                    // Prepare data for the normal order
                    $invoice_id = 'RE-' . $order->invoice_id;
                    $pre_pay = ($order->payment_via == 'Manual_Payment') ? "MP" : "AP";
                    $payment_id = $pre_pay . '-' . $order->invoice_id;
                    $payment_status = ($order->payment_status == 3) ? 'Success' : 'Pending';
                    $customer_name = $order->order_address->first_name . ' ' . $order->order_address->last_name;
                    $product_id = Helper::getViewPartnerProductId($item->partner_id, $partner_product_id) ?? '-';
                    $item_price = $item->price;

                    if ($order->cancel_status != 1) {
                        $invoice_date = $order->created_at->format('Y-m-d') ?? '-';
                        $net_price = $item->net_price;
                    } else
                    {
                        $invoice_date = $order->cancel_date;
                        $net_price = $item->net_price;
                    }
                   
    
                    // Row for the normal order
                    $normal_row = [
                        $invoice_id,
                        $order->created_at->format('Y-m-d H:i:s') ?? '-',
                        $order->order_id ?? '-',
                        $order_status ?? '-',
                        $payment_id ?? '-',
                        $order->created_at->format('Y-m-d H:i:s') ?? '-',
                        $order->payment_via ?? '-',
                        $payment_status ?? '-',
                        $customer_name ?? '-',
                        $order->order_address->email ?? '-',
                        $order->order_address->phone ?? '-',
                        $order->order_address->address ?? '-',
                        $order->order_address->country->name ?? '-',
                        $order->order_address->city ?? '-',
                        $order->order_address->zip_code ?? '-',
                        $product_id ?? '-',
                        $item->product->title ?? '-',
                        $item->product->voucher_type ?? '-',
                        'P' . str_pad($item->partner_id, 6, 0, STR_PAD_LEFT) ?? '',
                        $item->partner_detail->company ?? '-',
                        $item->quantity ?? '-',
                        $item_price ?? '-',
                        $item->vat_rate ?? '-',
                        $item->vat ?? '-',
                        $net_price ?? '-'
                    ];
    
                    // Write the normal order row
                    fputcsv($file, $normal_row);
    
                    // If the order is canceled, also add a second row for the canceled order
                    if ($order->cancel_status == 1) {
                        // Handle canceled order data
                        $cancel_id = 'RE-' . $order->invoice_id . '-Storno';
                        $cancel_price = '-' . $item->price; // Negative price for cancellation
    
                        // Row for the canceled order
                        $cancel_row = [
                            $cancel_id,
                            $order->cancel_date,
                            $order->order_id ?? '-',
                            $order_status ?? '-',
                            $payment_id ?? '-',
                            $order->created_at->format('Y-m-d') ?? '-',
                            $order->payment_via ?? '-',
                            $payment_status ?? '-',
                            $customer_name ?? '-',
                            $order->order_address->email ?? '-',
                            $order->order_address->phone ?? '-',
                            $order->order_address->address ?? '-',
                            $order->order_address->country->name ?? '-',
                            $order->order_address->city ?? '-',
                            $order->order_address->zip_code ?? '-',
                            $product_id ?? '-',
                            $item->product->title ?? '-',
                            $item->product->voucher_type ?? '-',
                            'P' . str_pad($item->partner_id, 5, 0, STR_PAD_LEFT) ?? '',
                            $item->partner_detail->company ?? '-',
                            $item->quantity ?? '-',
                            $cancel_price ?? '-',
                            $item->vat_rate ?? '-',
                            '-'.$item->vat ?? '-',
                            '-'.$item->net_price ?? '-'
                        ];
    
                        // Write the canceled order row
                        fputcsv($file, $cancel_row);
                    }
                }
            }
    
            // Close the file pointer
            fclose($file);
        }, 200, $headers);
    }
    
   
    public function old_invoiceExport(Request $request)
    {

        $orders = Order::select('orders.*','customers.*', 'orders.created_at as created_date' , 'orders.updated_at as updated_date')
        //->leftJoin('countries', 'countries.id', '=', 'customers.country')
        //->leftJoin('users', 'users.id', '=', 'orders.user_id')
        //->leftJoin('user_details', 'user_details.user_id', '=', 'orders.user_id')
        ->leftJoin('customers', 'customers.id', '=', 'orders.customer_id')
        ->orderBy('orders.id', 'desc')
        ->get();

       

        if ($orders->isNotEmpty()) {
            // Set the headers for CSV download
            $headers = [
                'Content-type'        => 'text/csv',
                'Content-Disposition' => 'attachment; filename="vouchers.csv"',
                'Pragma'              => 'no-cache',
                'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
                'Expires'             => '0',
            ];

            // Create a callback function to generate the CSV
           
            $callback = function () use ($orders) {
                $output = fopen('php://output', 'w');
               
                // Save the column headers
                $columns = ['Invoice ID', 'Invoice Date', 'Order ID', 'Order Status', 'Payment ID', 'Payment Date', 'Payment via', 'Payment Status', 'Customer Name', 'Customer Email', 'Customer Phone', 'Customer Adress', 'Customer Country', 'Customer City', 'Customer ZIP Code', 'Order Items'];
                fputcsv($output, $columns);
               
                // Output each row of the data
                foreach ($orders as $order) {

                   $invoice_id = 'RE-'.$order->invoice_id;
                   $order_status = OrderStatus::where('id', $order->order_status)->first->name ?? '';
                   if($order->payment_via == 'Manual_Payment')
                   {
                    $pre_pay = "MP";
                   } else
                   {
                    $pre_pay = "AP";
                   }
                   $payment_id = $pre_pay.'-'.$order->invoice_id;

                    if($order->payment_status == 3)
                   {
                    $payment_status = 'Success';
                   } else
                   {
                    $payment_status = 'Pending';
                   }

                   $customer_name = $order->first_name. ' '. $order->last_name;

                    $row = [
                        $invoice_id ?? '',
                        $order->created_date ?? '',
                        $order->order_id ?? '',
                        $order_status ?? '',
                        $payment_id ?? '',
                        $order->created_date ?? '',
                        $order->payment_via ?? '',
                        $payment_status ?? '',
                        $customer_name ?? '',
                        $order->email ?? '',
                        $order->phone ?? '',
                        $order->address ?? '',
                        '-',
                        $order->city ?? '',
                        $order->zip_code ?? '',
                        '-',
                       
                    ];
                    fputcsv($output, $row);
                }

                fclose($output);
            };

            return Response::stream($callback, 200, $headers);
        } else {
            return response()->json(['message' => 'No records found.'], 404);
        }
    }

    public function view($order_id)
    {
        $data['order'] = Order::where(['id' => $order_id])->orderBy('id', 'desc')->first();
        $data['items'] = OrderItem::where(['order_id' => $order_id])->orderBy('id', 'desc')->get();
        $data['redemptions'] = Redemption::where(['order_id' => $order_id])->orderBy('id', 'desc')->get();
        $data['docs'] = OrderDoc::where(['order_id' => $order_id])->orderBy('id', 'desc')->get();
        $data['manual_orders'] = ManualOrder::where(['order_id' => $data['order']['order_id']])->orderBy('id', 'desc')->get();
        ///dd($data['manual_orders']);
        $data['address'] = OrderAddress::where(['order_id' => $order_id])->orderBy('id', 'desc')->first();
        return view('admin.order.view')->with($data);
    }

    public function uploadDoc(Request $request)
    {
        $order_id = $request->order_id;
        $descriptions = $request->descriptions;

        if ($request->hasFile('file_name')) {
            $files = $request->file('file_name');

            foreach ($files as $file) {
                $order = new OrderDoc();
                $order->order_id = $order_id;
                $order->descriptions = $descriptions;

                $name = $file->getClientOriginalName();
                $filename = date('ymdgis') . Helper::cleanString($name);
                $file->move(public_path('storage/order/'), $filename);
                $order->file_name = '/storage/order/' . $filename;

                $order->save();
            }
        } else {
            // Handle the case where no files were uploaded, if necessary
        }

        return redirect()->back()->with(["msg" => 'Doc updated', 'msg_type' => 'success']);
    }


    public function changeOrderStatus(Request $request)
    {
       
        $order_id = $request->order_id;
        $status_id = $request->status_id;
        $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";
        $getOrder = Order::where('id', $order_id)->first();

        if($status_id == 3 && $getOrder['order_status'] == 1)
        {
            exit;
        }

        if($status_id == 1 && $getOrder['order_status'] == 3)
        {
            exit;
        }


        if($status_id == 4 && $getOrder['order_status'] == 1)
        {
            exit;
        }

        if($status_id == 1 && $getOrder['order_status'] == 4)
        {
            exit;
        }

        $order_update = Order::where('id', $order_id)->update(['order_status' => $status_id, 'cancel_status' => 1, 'cancel_date' => date('Y-m-d H:i:s')]);
        $order_update = OrderItem::where('order_id', $order_id)->update(['status' => $status_id]);
        $getUser = User::where('id', $getOrder->user_id)->first();
        $getStatus = OrderStatus::where('id', $status_id)->first();


      

        if ($status_id == 3) {
            //dd('test22');
            $mail_data['order'] = Order::where('id', $order_id)->first();
            $mail_data['user'] = Customer::where('id',$mail_data['order']['customer_id'])->first();
            $mail_data['order_items'] = OrderItem::where('order_id', $order_id)->with('product')->get();
            $data['order'] = Order::where('id', $order_id)->first();
            $data['order_items'] = OrderItem::where('order_id', $order_id)->with('product')->get();
            $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();

            // $filePath = public_path('pdf/invoice/') . $mail_data['order']['invoice_id'] . '.pdf';

            // return $filePath;

            ///dd($mail_data['order']);

            $mpdf = new Mpdf();
            $html = view('pdf.cancel-invoice', $data)->render();
            $filePath = public_path('pdf/invoice/') . 'RE-'.$mail_data['order']['invoice_id'] . '-Storno.pdf';
            $footerHtml = $footer_info;
            $mpdf->SetHTMLFooter($footerHtml);
            $mpdf->WriteHTML($html);
            $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

            if($mail_data['order']['payment_via'] == 'Manual_Payment')
            {
            $attachments[] = [
                'file' => public_path('pdf/invoice/' . 'RE-'.$mail_data['order']['invoice_id'] . '-Storno.pdf'),
                'options' => [
                    'mime' => 'application/pdf',
                    'as' => 'RE-'.$mail_data['order']['invoice_id'] . '-Storno.pdf',
                ],
                // Add more attachments with options as needed
            ];
           
            Mail::to($mail_data['user']['email'])->send(new OrderCancelMail($mail_data, $attachments));
         }
        }

        $arr = [
            'user' => $getUser,
            'order' => $getOrder,
            'status' => $getStatus,
        ];
        ///Mail::to($getUser->email)->cc(['support@cbdlogistics.swiss'])->locale($localteLang)->send(new OrderUpdateMail($arr));
        return Response()->json(['msg' => 'success', 'status_id' => $status_id]);
    }

    public function autoCancel(Request $request)
    {
        $automatic_cancellation_days = WebSetting::where(['id' => 1])->first()->automatic_cancellation_days;
        $orders = Order::where(['payment_via' => 'Manual_Payment', 'order_status' => 1])->get();
        $footer_info = "<p style='color: #808080;'>" . Helper::getWebSetting('voucher_footer_info') . "</p>";
    
        if (count($orders) > 0) {
            foreach ($orders as $order) {
                $targetDate = Carbon::create($order->created_at);
                $targetDate->addDays($automatic_cancellation_days);
                $currentDate = Carbon::now();
    
                if ($currentDate->greaterThan($targetDate)) {
                    $order_id = $order->id;
                    $order_uid = $order->customer_id;
                    $status_id = 3;
    
                    // Update order and order items status
                    Order::where(['id' => $order_id, 'customer_id' => $order_uid])
                        ->update(['order_status' => $status_id, 'cancel_status' => 1, 'cancel_date' => date('Y-m-d')]);
                    
                    OrderItem::where(['order_id' => $order_id, 'customer_id' => $order_uid])
                        ->update(['status' => $status_id]);
    
                    // Prepare data for the email and PDF
                    $mail_data['order'] = Order::where(['id' => $order_id, 'customer_id' => $order_uid])->first();
                    $mail_data['user'] = Customer::where('id', $mail_data['order']['customer_id'])->first();
                    $mail_data['order_items'] = OrderItem::where(['order_id' => $order_id, 'customer_id' => $order_uid])->with('product')->get();
                    $data['order'] = $mail_data['order'];
                    $data['order_items'] = $mail_data['order_items'];
                    $data['order_detail'] = OrderAddress::where('order_id', $order_id)->first();
    
                    // Generate the PDF for this order
                    $mpdf = new Mpdf();
                    $html = view('pdf.cancel-invoice', $data)->render();
                    $filePath = public_path('pdf/invoice/') . 'RE-'.$mail_data['order']['invoice_id'] . '-Storno.pdf';
                    $footerHtml = $footer_info;
                    $mpdf->SetHTMLFooter($footerHtml);
                    $mpdf->WriteHTML($html);
                    $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);
    
                    // Reset attachments array to prevent accumulating attachments from previous orders
                    $attachments = []; // Reset attachments for each iteration
    
                    if($mail_data['order']['payment_via'] == 'Manual_Payment')
                    {
                    // Attach the generated PDF for the current order
                    $attachments[] = [
                        'file' => $filePath,
                        'options' => [
                            'mime' => 'application/pdf',
                            'as' => 'RE-' . $mail_data['order']['invoice_id'] . '-Storno.pdf',
                        ],
                    ];
    
                    // Send the cancellation email with the PDF attached
                    Mail::to($mail_data['user']['email'])->send(new OrderCancelMail($mail_data, $attachments));
                  }
                }
            }
        }
    
        return response()->json(['msg' => 'Manual Orders have been cancelled']);
    }
    
    public function autoCancel_old(Request $request)
    {
        $automatic_cancellation_days = WebSetting::where(['id' => 1])->first()->automatic_cancellation_days;
        $orders = Order::where(['payment_via' => 'Manual_Payment','order_status'=>1])->get();
        $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";
        if(count($orders) > 0) 
        {
        foreach ($orders as $order) {
            $targetDate = Carbon::create($order->created_at);
            $targetDate->addDays($automatic_cancellation_days);
            $currentDate = Carbon::now();

            if ($currentDate->greaterThan($targetDate)) {
                $order_id = $order->id;
                $order_uid = $order->customer_id;
                $status_id = 3;
                $order_update = Order::where(['id' => $order_id , 'customer_id' => $order_uid])->update(['order_status' => $status_id, 'cancel_status' => 1, 'cancel_date' => date('Y-m-d H:i:s')]);
                $order_update = OrderItem::where(['order_id' => $order_id , 'customer_id' => $order_uid])->update(['status' => $status_id]);
                $getOrder = Order::where(['id' => $order_id , 'customer_id' => $order_uid])->first();
                $getUser = User::where('id', $getOrder->user_id)->first();
                $getStatus = OrderStatus::where('id', $status_id)->first();

                $mail_data['order'] = Order::where(['id' => $order_id , 'customer_id' => $order_uid])->first();
                $mail_data['user'] = Customer::where('id', $mail_data['order']['customer_id'])->first();
                $mail_data['order_items'] = OrderItem::where(['order_id' => $order_id , 'customer_id' => $order_uid])->with('product')->get();
                $data['order'] = Order::where(['id' => $order_id , 'customer_id' => $order_uid])->first();
                $data['order_items'] = OrderItem::where(['order_id' => $order_id , 'customer_id' => $order_uid])->with('product')->get();
                $data['order_detail'] = OrderAddress::where('order_id', $order_id)->first();

                $mpdf = new Mpdf();
                $html = view('pdf.invoice', $data)->render();
                $filePath = public_path('pdf/invoice/') . 'RE-' . $mail_data['order']['invoice_id'] . '-Storno.pdf';
                $footerHtml = $footer_info;
                $mpdf->SetHTMLFooter($footerHtml);
                $mpdf->WriteHTML($html);
                $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

                $attachments[] = [
                    'file' => public_path('pdf/invoice/' . 'RE-' . $mail_data['order']['invoice_id'] . '-Storno.pdf'),
                    'options' => [
                        'mime' => 'application/pdf',
                        'as' => 'RE-' . $mail_data['order']['invoice_id'] . '-Storno.pdf',
                    ],
                    // Add more attachments with options as needed
                ];

                Mail::to($mail_data['user']['email'])->send(new OrderCancelMail($mail_data, $attachments));
            }
        }
        }


        return Response()->json(['msg' => 'Manual Orders have been cancelled']);
    }


    public function changeOrderPayStatus(Request $request)
    {
        $order_id = $request->order_id;
        $status_id = $request->status_id;
        $order_update = Order::where('id', $order_id)->update(['payment_status' => $status_id]);
        ///$order_update = OrderItem::where('order_id', $order_id)->update(['status' => $status_id]);
        $getOrder = Order::where('id', $order_id)->first();
        $getUser = User::where('id', $getOrder->user_id)->first();
        $getStatus = OrderStatus::where('id', $status_id)->first();

        $arr = [
            'user' => $getUser,
            'order' => $getOrder,
            'status' => $getStatus,
        ];
        if ($request->status_id == 3) {
            $order_items = OrderItem::where('order_id', $order_id)->get();
            foreach ($order_items as $key => $item) {
                Helper::fullyRedemption($item->id);
            }
        }
        return Response()->json(['msg' => 'success', 'status_id' => $status_id]);
    }
}
