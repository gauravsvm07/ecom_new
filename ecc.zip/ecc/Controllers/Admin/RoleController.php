<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Role;
use App\Models\Permission;
use Exception;
use File;

class RoleController extends Controller
{
    public function index(Request $request)
    {
        $data['roles'] = Role::orderBy('id', 'desc')->paginate(15);
        return view('admin.role.index')->with($data);
    }

   
    public function create(Request $request)
    {
        $roles = Role::orderby('id', 'desc')->get();
        return view('admin.role.role-form', compact('roles'));
    }


    public function save(Request $request)
    {
        //
        $validated = $request->validate([
            'name' => 'required|max:255',
            'status' => 'required',
        ]);

        if (!$request->role_id) {
            $role = new Role();
            $msg = "Role Added Successfully.";
        } else {
            $role = Role::findOrFail($request->role_id);
            $msg = "Role updated Successfully.";
        }

        try {
            // $category->parent_id = $request->parent_id;
            $role->name = $request->name;
            $role->status = $request->status;
            $role->slug = Str::slug($request->name, '-');
            $role->save();
            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $role = Role::findOrFail($id);

        if ($type == "edit") {
            return view('admin.role.role-form', compact('role',));
        }
        if ($type == "delete") {
            $delData = Role::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $role->status = $role->status == 1 ? 0 : 1;
            $role->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }

    public function getPermissions($id) {
        // Fetch the role
        $role = Role::findOrFail($id);
    
        // Fetch all permissions and check if assigned to the role
        $permissions = Permission::where('status',1)->get()->map(function($permission) use ($role) {
            return [
                'id' => $permission->id,
                'name' => $permission->name,
                'assigned' => $role->permissions->contains($permission->id)
            ];
        });
    
        return response()->json(['permissions' => $permissions]);
    }
    
    public function savePermissions(Request $request, $id) {
        // Fetch the role
        $role = Role::findOrFail($id);
    
        // Update permissions
        $role->permissions()->sync($request->permissions);
    
        return response()->json(['message' => 'Permissions updated successfully!']);
    }
    
}
