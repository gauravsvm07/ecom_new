<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Response;
use App\Models\Admin;
use App\Models\Role;
use Illuminate\Support\Facades\Http;
use App\Helpers\Helper;
use App\Mail\DynamicEmail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use Exception;
use File;


class AdminController extends Controller
{
    public function index()
    {
        $data['admins'] = Admin::orderBy('id', 'desc')->paginate(15);

        return view('admin.admin.index')->with($data);
    }


   



    public function create(Request $request)
    {
        $data['roles'] = Role::orderBy('id', 'desc')->get();
        return view('admin.admin.admin-form')->with($data);
    }


    public function save(Request $request)
    {

        if (!$request->admin_id) {
            $this->validate($request, [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
            ]);
        } else {
            $this->validate($request, [
                'name' => 'required',
            ]);
        }

        $validated = $request->validate([
            'email' => 'required|string|email|unique:users,email', // Ensures valid email format and uniqueness in the 'users' table
            'name' => 'required|string|max:255',                   // Name is required and should be a string with a maximum length
            'password' => [
                'required',
                'string',
                'min:6',              // Minimum length of 6 characters
                'regex:/[a-z]/',      // At least one lowercase letter
                'regex:/[A-Z]/',      // At least one uppercase letter
                'regex:/[0-9]/',      // At least one digit
                'regex:/[@$!%*?&#]/', // At least one special character
            ],
            'role_id' => 'required|integer|exists:roles,id',       // Ensures the role ID is a valid integer and exists in the 'roles' table
        ], [
            // Custom error messages
            'email.required' => 'Please provide an email address.',
            'email.email' => 'The email must be a valid email address.',
            'email.unique' => 'This email address is already registered.',
            
            'name.required' => 'Please provide your name.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name must not exceed 255 characters.',
            
            'password.required' => 'Please enter a password.',
            'password.min' => 'Your password must be at least 6 characters long.',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one number, and one special character (@, $, !, %, *, ?, &).',
            
            'role_id.required' => 'Please select a role.',
            'role_id.integer' => 'The role ID must be a valid integer.',
            'role_id.exists' => 'The selected role does not exist.',
        ]);
        

        if (!$request->admin_id) {
            $admin = new Admin();
            $msg = "Admin Added Successfully.";
        } else {
            $admin = Admin::findOrFail($request->admin_id);
            $msg = "Admin updated Successfully.";
        }
        try {

            $admin->role_id = $request->role_id;
            $admin->name = $request->name;
            $admin->phone = $request->phone;
            $admin->email = $request->email;
            $admin->view_password = $request->password;
            $admin->password = Hash::make($request->password);
            $admin->uuid =  Str::uuid($request->email);
            $admin->status = $request->status;
            $admin->updated_at = now();
            $admin->save();

            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $admin = Admin::findOrFail($id);

        if ($type == "edit") {
            $data['roles'] = Role::orderBy('name', 'asc')->where('status', 1)->get();
            $data['admin'] = $admin;

            return view('admin.admin.admin-form')->with($data);
        }
        if ($type == "delete") {
            if (\File::exists(public_path($admin->image))) {
                \File::delete(public_path($admin->image));
            }
            $delData = Admin::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $admin->status = $admin->status == 1 ? 0 : 1;
            $admin->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
