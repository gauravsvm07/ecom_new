<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Order;
use App\Models\Admin;
use App\Models\Setting;
use App\Models\Product;
use App\Models\Enquiry;
use App\Models\WebSetting;
use App\Models\Redemption;
use App\Models\OrderItem;
use App\Imports\OrderImport;
use App\Helpers\Helper;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Symfony\Component\HttpFoundation\StreamedResponse;

use Hash;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $data['user_count'] = User::count();
        $data['order_count'] = Order::count();
        $data['product_count'] = Product::count();
        $data['enquiry_count'] = Enquiry::count();
        $data['users'] = User::where('status', 1)->orderBy('id', 'desc')->take('12')->get();
        $data['subscribers'] = [];
        return view('admin.dashboard.dashboard')->with($data);
    }


    public function redemptionExport()
    {
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="redemptions_export.csv"',
        ];
    
        return new StreamedResponse(function () {
            $file = fopen('php://output', 'w');
    
            // Define the CSV headers
            $csvHeader = [
                'Voucher ID',
                'Voucher Date',
                'Voucher Expiration Date',
                'Voucher Type',
                'Product ID',
                'Product Title',
                'Related Partner ID',
                'Related Company',
                'Quantity',
                'Net Price',
                'VAT Rate (%)',
                'VAT Amount',
                'Gross Price',
                'Sales Provision Rate',
                'Sales Provision Net Amount',
                'Sales Provision Vat Rate',
                'Sales Provision Vat Amount',
                'Sales Provision Gross Amount',
                'Customer Name',
                'Customer Email',
                'Customer Phone',
                'Customer Address',
                'Customer Country',
                'Customer City',
                'Customer ZIP Code',
                'Redemption ID',
                'Redemption Date',
                'Redemption Partner ID',
                'Redemption Company',
            ];
    
            // Write the header row to the CSV file
            fputcsv($file, $csvHeader);
    
            // Fetch order items with necessary relations
            $orderItems = OrderItem::with(['order.customer', 'order.order_address', 'partner_detail'])
                ->get();
    
            foreach ($orderItems as $oitem) {
                $customer = $oitem->order->customer;
                $orderAddress = $oitem->order->order_address;
                $product = Product::where('id',$oitem->product_id)->first();
                $partnerDetail = $oitem->partner_detail;
                $partner_product_id = Product::where('id',$oitem->product_id)->first()->partner_product_id ?? '';
                $product_id = Helper::getViewPartnerProductId($oitem->partner_id, $partner_product_id) ?? '-';
    
                // Main order item row
                $row = [
                    $oitem->voucher_id ?? '-',
                     $product->created_at ?? '-',
                    $product->offer_expire_at ?? '-',
                    $product->voucher_type ?? '-',
                    $product_id ?? '-',
                    $product->title ?? '-',
                    'P' . str_pad($oitem->partner_id, 6, 0, STR_PAD_LEFT) ?? '-',
                    $partnerDetail->company ?? '-',

                    $oitem->quantity ?? '-',

                    $oitem->price ?? '-',
                    $oitem->vat_rate ?? '-',
                    $oitem->vat_amount ?? '-',
                    $oitem->net_price ?? '-',

                    '-', 
                    '-', 
                    '-', 
                    '-', 
                    '-', 

                    $customer->first_name ?? '-',
                    $orderAddress->email ?? '-',
                    $orderAddress->phone ?? '-',
                    $orderAddress->address ?? '-',
                    $orderAddress->country->name ?? '-',
                    $orderAddress->city ?? '-',
                    $orderAddress->zip_code ?? '-',
                    '-', // Placeholder for Redemption ID
                    '-', // Placeholder for Redemption Date
                    '-', // Placeholder for Redemption Partner ID
                    '-', // Placeholder for Redemption Company
                ];
    
                // Write the order item row to the CSV file
                fputcsv($file, $row);
    
                // Fetch associated redemptions for the order item
                $redemptions = Redemption::with(['product', 'partner_detail', 'item'])
                    ->where('order_item_id', $oitem->id)
                    ->get();
    
                foreach ($redemptions as $redemption) {
                    $redemption_user = User::leftJoin('user_details', 'user_details.user_id', 'users.id')
                        ->where('users.id', $redemption->redemption_userid)
                        ->first();

                        $partnerData = User::where('id',$redemption->redemption_userid)->first();
                        


    
                    // Redemption row data
                    $redemption_row = [
                        $redemption->redemption_id ?? '-',
                        '-', // Placeholder for Voucher Date
                        '-', // Placeholder for Voucher Expiration Date
                        '-', // Placeholder for Voucher Type
                        '-', // Placeholder for Product ID
                        '-', // Placeholder for Product Title
                        '-', // Placeholder for Related Partner ID
                        '-', // Placeholder for Related Company
                        '-', // Placeholder for Quantity
                        '-'.number_format($redemption->net_amount, 2, ',', '.'),
                        number_format($redemption->vat_sales_rate ?? 0, 2, ',', '.'),
                        '-'.number_format(($redemption->amount - $redemption->net_amount) , 2, ',', '.'),
                        '-'.number_format($redemption->amount, 2, ',', '.'),
                        number_format($redemption->voucher_sales_provision_rate, 2, ',', '.'), 
                        number_format($redemption->standard_amount, 2, ',', '.'), 
                        number_format($redemption->standard_sales_rate ?? 0, 2, ',', '.'), 
                        number_format(($redemption->standard_redem_amount - $redemption->standard_amount) , 2, ',', '.'), 
                        number_format($redemption->standard_redem_amount, 2, ',', '.'), 
                        
                        '-', // Placeholder for Customer Name
                        '-', // Placeholder for Customer Email
                        '-', // Placeholder for Customer Phone
                        '-', // Placeholder for Customer Address
                        '-', // Placeholder for Customer Country
                        '-', // Placeholder for Customer City
                        '-', // Placeholder for Customer ZIP Code
                        $redemption->redemption_id ?? '-',
                        $redemption->created_at ?? '-',
                        $partnerData->partner_id,
                        $redemption_user->company ?? '-',
                    ];
    
                    // Write the redemption row to the CSV file
                    fputcsv($file, $redemption_row);
                }
            }
    
            // Close the file pointer
            fclose($file);
        }, 200, $headers);
    }
    


    public function cnExport()
    {

        // $redemptions = Redemption::with(['product'])->get();
        // dd($redemptions);
        // Define the headers for the CSV download response
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="cn_export.csv"',
        ];

        // Return a StreamedResponse to stream the CSV content
        return new StreamedResponse(function () {
            // Open a file pointer connected to the output stream
            $file = fopen('php://output', 'w');

            // Define the CSV headers
            $csvHeader = [
                'Credit Note ID',
                'Credit Note Date',
                'Related Partner ID',
                'Related Partner',
                'Related Partner Adress',
                'Related Partner VAT Number',
                'Related Partner Bank account owner',
                'Related Partner IBAN',
                'Related Partner SWIFT',
                'Voucher ID',
                'Voucher Tpye',
                'Related Product ID',
                'Related Product Title',
                'Redemption Net amount',
                'VAT Rate',
                'Redemption VAT Amount',
                'Redemption Gross amount',
                'Sales Provision Rate (from the voucher level)',
                'Sales Provision Amont (net)',
                'VAT Rate for Sales Provision',
                'VAT Amount for Sales Provision',
                'Sales Provision Amount (gross)',
            ];

            // Output the header row
            fputcsv($file, $csvHeader);

            // Fetch orders with their items and customers
            $redemptions = Redemption::with(['product','partner','partner_detail','item'])->get();

          

            // Loop through orders, items, and customer details
            foreach ($redemptions as $redemption) {
               
                    $customer_name = $redemption->customer->first_name ?? '';
                    //$view_product_id
                    $partner_product_id = Product::where('id',$redemption->product_id)->first()->partner_product_id ?? '';
                    $product_id = Helper::getViewPartnerProductId($redemption->product->user_id,$partner_product_id) ?? '';

                
                    // Prepare a row for each item
                    $row = [
                        $redemption->credit_note_id ?? '-',
                        $redemption->created_at ?? '-',
                        $redemption->partner->partner_id ?? '-',
                        $redemption->partner_detail->company ?? '-',
                        $redemption->partner_detail->address ?? '-',
                        $redemption->partner_detail->vat_number ?? '-',
                        $redemption->partner_detail->bank_account ?? '-',
                        $redemption->partner_detail->iban ?? '-',
                        $redemption->partner_detail->swift ?? '-',
                        $redemption->voucher_id ?? '-',
                        $redemption->product->voucher_type ?? '-',
                        $product_id ?? '-',
                        $redemption->product->title ?? '-',
                        number_format($redemption->net_amount, 2, ',', '.') ?? '-',
                        number_format($redemption->vat_sales_rate ?? 0, 2, ',', '.') ?? '',
                        number_format(($redemption->amount - $redemption->net_amount) , 2, ',', '.') ?? '-',
                        number_format($redemption->amount, 2, ',', '.') ?? '-',
                        $redemption->voucher_sales_provision_rate ?? '-',
                        '-'.number_format($redemption->standard_amount, 2, ',', '.') ?? '',
                        number_format($redemption->standard_sales_rate ?? 0, 2, ',', '.') ?? '',
                        '-'.number_format(($redemption->standard_redem_amount - $redemption->standard_amount) , 2, ',', '.') ?? '',
                        '-'.number_format($redemption->standard_redem_amount, 2, ',', '.') ?? '',
                    ];

                    // Write the row to the CSV file
                    fputcsv($file, $row);
            }

            // Close the file pointer
            fclose($file);
        }, 200, $headers);
    }


    public function updateGeneralSetting(Request $request)
    {
        $data['setting'] = request()->all();
        $updateSettings = Setting::pluck('setting_key')->toArray();
        foreach ($data['setting'] as $key => $value) {
            if (in_array($key, $updateSettings)) {
                Setting::where('setting_key', $key)->update(['setting_value' => $value]);
            } else {
                $settings = new Setting;
                $settings->setting_key    = $key;
                $settings->setting_value  = $value;
                $settings->save();
            }
        }
        return redirect()->back()->with('msg', 'Setting saved successfully');
    }

    public function setting()
    {
        // if(Auth::guard('admin')->user()->role_id != 1)
        // {
        //     dd('permission denied');
        // }
        $user_id = Auth::guard('admin')->id();
        $data['admin'] = Admin::where('id', $user_id)->first();

        $setting = Setting::get();
        $globalSetting = [];
        foreach ($setting as $key => $value) {
            $globalSetting[$value->setting_key] = $value->setting_value;
        }
        $data['globalSetting'] = $globalSetting;
        return view('admin.setting.setting')->with($data);
    }

    public function updateProfile(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
        ]);

        $userId = Auth::guard('admin')->id();
        $user = Admin::find($userId);
        $user->uuid = Str::uuid($request->email);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->about = $request->about;
        $user->address = $request->address;
        $user->save();
        return redirect()->back()->with('msg', 'Profile updated successfully');
    }


    public function saveProfileImage(Request $request)
    {
        $userId = Auth::guard('admin')->id();
        $actionType = 'update';
        $uploadedFile = $request->file('file');
        $filename = rand(1111, 9999) . '_' . 'image.' . $uploadedFile->getClientOriginalExtension();
        $path = public_path('uploads/admin/');
        $upload_success = $uploadedFile->move($path, $filename);

        $user = Admin::find($userId);
        $user->image = $filename;
        $user->save();

        return response()->json(['success' => 'Profile image updated successfully.', 'actionType' => $actionType]);
    }

    public function webSetting(Request $request)
    {
        $data['setting'] = WebSetting::where('id', 1)->first();
        return view('admin.setting.web-setting')->with($data);
    }

    public function webSettingUpdate(Request $request)
    {
        $setting_id = 1;
        $setting = WebSetting::find($setting_id);
        $setting->is_partner_released = $request->is_partner_released;
        $setting->standard_sales_provision = $request->standard_sales_provision;
        $setting->vat_sales_provision = $request->vat_sales_provision;
        $setting->is_accept_manual_payment = $request->is_accept_manual_payment;
        $setting->automatic_cancellation_days = $request->automatic_cancellation_days;
        $setting->voucher_validity_period = $request->voucher_validity_period;
        $setting->voucher_validity_type = $request->voucher_validity_type;
        $setting->voucher_validity_type = $request->voucher_validity_type;
        $setting->voucher_po = $request->voucher_po;
        $setting->universal_partner = $request->universal_partner;
        $setting->universal_prioritation = $request->universal_prioritation;
        $setting->invoice_general_info = $request->invoice_general_info;
        $setting->credit_note_general_info = $request->credit_note_general_info;
        $setting->voucher_footer_info = $request->voucher_footer_info;
        $setting->cancel_order_general_info = $request->cancel_order_general_info;
        $setting->payment_invoice_message = $request->payment_invoice_message;
        $setting->cn_invoice_message = $request->cn_invoice_message;
        $setting->save();

        $universal_user_id = User::where('email', $request->universal_partner)->first()->id;
        ///dd($universal_user_id);

        $products = Product::all();
        foreach ($products as $product) {
            $product->voucher_po = $request->voucher_po;
            if ($universal_user_id == $product->user_id) {
                $product->is_universal = 1;
            } else {
                $product->is_universal = 0;
            }
            $product->save();
        }

        $users = User::all();
        foreach ($users as $user) {
            if ($request->universal_partner == $user->email) {
                $user->is_universal_partner = 1;
            } else {
                $user->is_universal_partner = 0;
            }
            $user->save();
        }

        return redirect()->back()->with('msg', 'Setting updated successfully');
    }


    public function orderCsv(Request $request)
    {
        $data['data'] = [];
        return view('admin.setting.order-csv')->with($data);
    }


    public function uploadOrderCsv(Request $request)
    {
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt',
        ]);
        
        $file = $request->file('csv_file');

        // Import the CSV file
        Excel::import(new OrderImport, $file);

        return redirect()->back()->with('msg', 'Order statuses updated successfully.');
    }


    public function saveProfileCoverImage(Request $request)
    {
        $userId = Auth::guard('admin')->id();
        $actionType = 'update';
        $uploadedFile = $request->file('file');
        $filename = rand(1111, 9999) . '_' . 'image.' . $uploadedFile->getClientOriginalExtension();
        $path = public_path('uploads/admin/');
        $upload_success = $uploadedFile->move($path, $filename);

        $user = Admin::find($userId);
        $user->cover_image = $filename;
        $user->save();

        return response()->json(['success' => 'Cover image updated successfully.', 'actionType' => $actionType]);
    }


    public function updatePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_password' => 'required',
            'password' => [
                'required',
                'string',
                'min:6',              // Minimum length of 6 characters
                'regex:/[a-z]/',      // At least one lowercase letter
                'regex:/[A-Z]/',      // At least one uppercase letter
                'regex:/[0-9]/',      // At least one digit
                'regex:/[@$!%*?&#]/', // At least one special character
            ],
            'password_confirmation' => 'required|same:password',
        ], [
            // Custom error messages for password validation
            'password.required' => 'Please enter a new password.',
            'password.min' => 'Your new password must be at least 6 characters long.',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one number, and one special character (@, $, !, %, *, ?, &).',
            'password_confirmation.required' => 'Please confirm your new password.',
            'password_confirmation.same' => 'Password confirmation does not match.',
        ]);

        $admin_id =  Auth::guard('admin')->id();
        $admin = Admin::find($admin_id);
        $admin_password = $admin->password;

        if ($validator->passes()) {

            if (Hash::check($request->current_password, $admin_password)) {
                $admin->password = Hash::make($request->password);
                $admin->save();

                return response()->json(['success' => 'Password changed successfully.']);
            } else {
                return response()->json(['success' => 'Please enter valid Current Password.']);
            }
        }

        return response()->json(['error' => $validator->errors()->all()]);
    }

    public function adminLogout(Request $request)
    {
        Auth::guard('admin')->logout();
        return redirect('admin');
    }
}
