<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\Category;
use App\Models\Country;
use App\Models\UserDetail;
use App\Helpers\Helper;
use App\Models\User;
use App\Models\Redemption;
use App\Models\OrderItem;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Exception;
use File;
use Mpdf\Mpdf;
use PDF;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        if(isset($_GET['pid']))
        {
            $user_id = $_GET['pid'];
            $data['products'] = Product::where('user_id',$user_id)->orderBy('id', 'desc')->get();
        } else
        {
            $data['products'] = Product::orderBy('id', 'desc')->get();
        }
        return view('admin.product.index')->with($data);
    }

    public function export(Request $request)
    {

        $products = Product::orderBy('products.id', 'desc')->get();


        if ($products->isNotEmpty()) {
            // Set the headers for CSV download
            $headers = [
                'Content-type'        => 'text/csv',
                'Content-Disposition' => 'attachment; filename="vouchers.csv"',
                'Pragma'              => 'no-cache',
                'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
                'Expires'             => '0',
            ];

            // Create a callback function to generate the CSV
            $callback = function () use ($products) {
                $output = fopen('php://output', 'w');

                // Save the column headers
                $columns = ['Voucher Id','Created Date', 'Updated Date', 'Title', 'Partner ID', 'Company', 'Country', 'Affiliate Link', 'Affiliate Status ', 'Price Type', 'Net Price ', 'Vat', 'Voucher Sales Provisions (%) ', 'Description', 'Voucher Type', 'Voucher Validity Type', 'Voucher Validity (Month)', 'Why you changing validity setting', 'Zip Code', 'Status', 'Latitude', 'Longitude', 'Image', 'Video'];
                fputcsv($output, $columns);

                // Output each row of the data
                foreach ($products as $product) {

                   $voucher_id = Helper::getViewPartnerProductId($product->user_id,$product->partner_product_id) ?? '';
                   $user_detail = UserDetail::where('user_id',$product->user_id)->first();

                    $status = $product->status;
                    if($status == 1)
                    {
                        $product_status = 'Active';
                    } else
                    {
                        $product_status = 'Inactive';
                    }

                    $affiliate = $product->affiliate_status;
                    if($affiliate == 1)
                    {
                        $affiliate_status = 'Active';
                    } else
                    {
                        $affiliate_status = 'Inactive';
                    }

                   $price_type = $product->price_type;

                   if($price_type == 'fixed')
                    {
                        $voucher_price = $product->price;
                    } else
                    {
                        $voucher_price = $product->minimum_price.'-'.$product->maximum_price;
                    }

                    $video_image_type = $product->video_image_type;

                    if($user_detail->video_image_type == 'video')
                    {
                        $video_file = $user_detail->video;
                    } else
                    {
                        $video_file = $user_detail->youtube_code;
                    }

                    if($video_image_type == 'image')
                    {
                        $image_file = $user_detail->video;
                    } else
                    {
                        $image_file = '';
                    }

                    if($product->voucher_validity_type == 1)
                    {
                        $voucher_validity_type = "Purchase Date";
                    } else if ($product->status)
                    {
                        $voucher_validity_type = "First of January";
                    } else
                    {
                        $voucher_validity_type = "";
                    }
                    

                  $partner_product_id =  'P'.str_pad(($product->user_id + 1), 5, 0, STR_PAD_LEFT);

                    $row = [
                        $voucher_id ?? '',
                        $product->created_at ?? '',
                        $product->updated_at ?? '',
                        $product->title ?? '',
                        $partner_product_id ?? '',
                        $product->partner_detail->company ?? '',
                        $product->get_country->name ?? '',
                        $product->affiliate_url ?? '',
                        $affiliate_status ?? '',
                        $product->price_type ?? '',
                        $voucher_price ?? '',
                        $product->vat ?? '',
                        $product->voucher_sales_provision ?? '',
                        $product->descriptions ?? '',
                        $product->voucher_type ?? '',
                        $voucher_validity_type ?? '',
                        $product->voucher_validity ?? '',
                        $product->validity_message ?? '',
                        $product->zip_code ?? '',
                        $product_status ?? '',
                        $product->longitude ?? '',
                        $product->latitude ?? '',
                        $product->image ?? '',
                        $video_file ?? '',
                    ];
                    fputcsv($output, $row);
                }

                fclose($output);
            };

            return Response::stream($callback, 200, $headers);
        } else {
            return response()->json(['message' => 'No records found.'], 404);
        }
    }

    public function create(Request $request)
    {
        $data['categories'] = Category::where('status', 1)->orderby('id', 'desc')->get();
        $data['countries'] = Country::where('show_status', 1)->orderby('name', 'asc')->get();
        $data['users'] = User::where('status', 1)->orderby('id', 'desc')->get();
        $data['product_categories'] = [];
        return view('admin.product.product-form')->with($data);
    }


    public function save(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required',
            'title' => 'required|max:255',
            'vat' => 'required|numeric',
            'status' => 'required'
        ]);

        if (!$request->product_id) {
            $product = new Product();
            $msg = "Product Added Successfully.";
            $product->voucher_id = Helper::random_strings(7);
        } else {
            $product = Product::findOrFail($request->product_id);
            $msg = "Product updated Successfully.";
        }
        try {

            $setting_universal_email  = Helper::getWebSetting('universal_partner');
            $input_partner_email = User::where('id',$request->user_id)->first()->email;
            $getPartner = User::where('id',$request->user_id)->first();
            $partner_id = $getPartner->partner_id;

            $lat = '';
            $lng = '';
            $api_key = env('GOOGLE_API_KEY');
            $zip_code = $request->zip_code;
            $url = "https://maps.googleapis.com/maps/api/geocode/json?address=".$zip_code."&key=".$api_key;
        
            $response = Http::get($url);
            $data = $response->json();
        
            if($data['status'] == 'OK')
            {
              if(isset($data['results'][0]['geometry']['location']))
              {
                $lat = $data['results'][0]['geometry']['location']['lat'];
                $lng = $data['results'][0]['geometry']['location']['lng'];
              }
            }

            $voucher_id = Helper::random_strings(7);
            $product->category_id = $request->category_id;
            $product->title = $request->title;
            $product->country = $request->country;

            $product->price_type = $request->price_type;
            $product->price = $request->price;
            
            if($request->price == '')
            {
                $product->minimum_price = $request->minimum_price;
                $product->maximum_price = $request->maximum_price;
            } else
            {
                $product->minimum_price = $request->price;
                $product->maximum_price = 0;
            }

            $product->vat = $request->vat;
            $product->voucher_sales_provision = $request->voucher_sales_provision;
            $product->descriptions = $request->descriptions;
            $product->additional_info = $request->additional_info;

            if (!$request->product_id) {
                $product->slug = Str::slug($request->title, '-') . '-' . rand(0000, 9999);
                $product->voucher_id = $voucher_id;
                $product->offer_code = $voucher_id;
            }

            $product->affiliate_url = $request->affiliate_url;
            $product->affiliate_status = $request->affiliate_status;
            $product->user_id = $request->user_id;
            $product->partner_id = $partner_id;
            
            $product->voucher_type = $request->voucher_type;
            ///$product->voucher_po = $request->voucher_po;
            
            $product->voucher_validity = $request->voucher_validity;
            $product->voucher_validity_type = $request->voucher_validity_type;
            ///$product->termination_date = $request->termination_date;
            if($setting_universal_email == $input_partner_email)
            {
                $product->is_universal = 1;
            } else
            {
                $product->is_universal = 0; 
            }
            $product->status = $request->status;
            $product->meta_title = $request->meta_title;
            $product->meta_keyword = $request->meta_keyword;
            $product->meta_description = $request->meta_description;
            $product->zip_code = $request->zip_code;
            $product->latitude = $lat;
            $product->longitude = $lng;
            $product->updated_at = now();
            $product->save();

            ///dd($product->id);
            if ($request->product_id) {
                $delete_category = ProductCategory::where('product_id', $request->product_id)->delete();
            }
            $category_data = [];
            $category = new ProductCategory();
            foreach ($request->category as $category) {
                $category_data[] = ['product_id' => $product->id, 'category_id' => $category, 'created_at' => date("Y-m-d H:i:s")];
            }
            ProductCategory::insert($category_data);

            //dd($product->id);
            ///$data['product'] = Product::where('id', $product->id)->first();

            $mpdf = new Mpdf();
            $viewData['product'] = $product;
            $viewData['partner'] = UserDetail::where('user_id', $product->user_id)->first();
            $viewData['voucher_id'] = $voucher_id;
            $viewData['voucher_code'] = $voucher_id;
            $viewData['net_price'] = $product->price;
            $html = view('pdf.voucher', $viewData)->render();
            // Define the file path where you want to save the PDF
            $filePath = public_path('pdf/voucher/') . $product->voucher_id . '.pdf';
            // Save the PDF to the server
            $mpdf->WriteHTML($html);
            $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status', 'productpdf']))
            return redirect()->back()->with(['message' => 'Invalid Action']);
        $product_categories = [];
        $product = Product::with('user.userDetails')->findOrFail($id);
        //$categories = Category::orderBy('id', 'desc')->get();
        $countries = Country::where('show_status', 1)->orderby('name', 'asc')->get();
        $categories = Category::where('status', 1)->orderby('id', 'desc')->get();
        if ($type == "edit") {
            $product_categories = ProductCategory::where('product_id', $id)->get()->pluck('category_id')->toArray();
            $users = User::where('status', 1)->orderby('id', 'desc')->get();
            ///$product_categories = ProductCategory::where('product_id', $id)->orderby('id', 'asc')->get();
            return view('admin.product.product-form', compact('product', 'categories', 'users', 'countries', 'product_categories'));
        }
        if ($type == "productpdf") {
            //dd($product);

            $viewData['product'] = $product;
            //dd($viewData['product']);
            $pdf = PDF::loadView('pdf.voucher', $viewData);
            return $pdf->stream('document.pdf');
            //return view('pdf.voucher', $viewData)->render();
        }
        if ($type == "delete") {
            $delData = Redemption::where(['product_id' => $id])->delete();
            $delData = OrderItem::where(['product_id' => $id])->delete();
            $delData = Product::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $product->status = $product->status == 1 ? 0 : 1;
            $product->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
