<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Permission;
use Exception;
use File;

class PermissionController extends Controller
{
    public function index(Request $request)
    {
        $data['permissions'] = Permission::orderBy('id', 'desc')->paginate(15);
        //$data['categories'] = Category::where('parent_id', null)->orderby('id', 'desc')->paginate(15);

        return view('admin.permission.index')->with($data);
    }

    public function create(Request $request)
    {
        $permissions = Permission::orderby('id', 'desc')->get();
        return view('admin.permission.permission-form', compact('permissions'));
    }


    public function save(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'status' => 'required',
        ]);

        if (!$request->permission_id) {
            $permission = new Permission();
            $msg = "Permission Added Successfully.";
        } else {
            $permission = Permission::findOrFail($request->permission_id);
            $msg = "Permission updated Successfully.";
        }

        try {
            // $category->parent_id = $request->parent_id;
            $permission->name = $request->name;
            $permission->status = $request->status;
            $permission->slug = Str::slug($request->name, '-');
            $permission->save();
            return redirect()->back()->with(["msg" => $msg, 'msg_type' => 'success']);
        } catch (Exception $e) {
            return redirect()->back()->with(["msg" => $e->getMessage(), 'msg_type' => 'danger']);
        }
    }

    public function action($type, $id)
    {
        if (!in_array($type, ['edit', 'delete', 'status']))
            return redirect()->back()->with(['message' => 'Invalid Action']);

        $permission = Permission::findOrFail($id);

        if ($type == "edit") {
            return view('admin.permission.permission-form', compact('permission'));
        }
        if ($type == "delete") {
            $delData = Permission::where('id', $id)->delete();
            return response()->json(['msg' => 'deleted']);
        }
        if ($type == "status") {
            $permission->status = $permission->status == 1 ? 0 : 1;
            $permission->save();
            return redirect()->back()->with(['message' => 'Status changed successfully.']);
        }
        return abort(404);
    }
}
