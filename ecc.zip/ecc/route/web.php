<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\CheckUserLog;
use App\Http\Controllers\Front\PageController;
use App\Http\Controllers\Front\ProductController;
use App\Http\Controllers\Front\UserController;
use App\Http\Controllers\Front\CartController;
use App\Http\Controllers\Front\WishlistController;
use App\Http\Controllers\Front\OrderController;
use App\Http\Controllers\Front\NewsletterController;
use App\Http\Controllers\Front\StripeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [PageController::class, 'index']);
Route::get('offers', [ProductController::class, 'products']);
Route::get('offer/search', [ProductController::class, 'search']);
Route::get('offer/{slug}', [ProductController::class, 'productDetail']);
Route::get('filter-products', [ProductController::class, 'filterProducts']);

Route::get('privacy-policy', [PageController::class, 'privacyPolicy']);
Route::get('terms-condition', [PageController::class, 'termCondition']);
Route::get('imprint', [PageController::class, 'imprint']);
Route::get('data-protection', [PageController::class, 'dataProtection']);

Route::get('faq', [PageController::class, 'faq']);
Route::get('about-us', [PageController::class, 'aboutUs']);

Route::get('partners', [PageController::class, 'partners']);
Route::get('partner-search', [PageController::class, 'partnerSearch']);
Route::get('view-vouchers/{slug}', [PageController::class, 'viewVouchers']);

Route::get('contact-us', [PageController::class, 'contactUs']);
Route::post('save-enquiry', [PageController::class, 'saveEnquiry'])->name('save-enquiry');
Route::get('blogs', [PageController::class, 'blogs']);
Route::get('blog/{slug}', [PageController::class, 'blogDetails']);
Route::get('page/{slug}', [PageController::class, 'pageDetails']);
Route::get('login', [UserController::class, 'login']);
Route::get('forgot-password', [UserController::class, 'forgotPassword']);
Route::post('send-reset-pass-link', [UserController::class, 'sendResetPassLink']);
Route::post('reset-password-email', [UserController::class, 'resetPasswordEmail']);
Route::post('update-user-email-password', [UserController::class, 'updateUserEmailPassword']);
Route::get('save-newsletter', [NewsletterController::class, 'saveNewsletter']);
Route::get('register', [UserController::class, 'register']);
Route::get('register/{influencer_id}', [UserController::class, 'register']);
Route::post('user-auth/{type}', [UserController::class, 'userAuth']);

Route::any('add-cart', [CartController::class, 'addToCart']);
Route::any('update-cart', [CartController::class, 'updateCart']);
Route::any('delete-cart/{id}', [CartController::class, 'deleteCart']);
Route::get('cart', [CartController::class, 'cart']);

Route::any('add-wishlist', [WishlistController::class, 'addToWishlist']);
Route::any('delete-wishlist/{id}', [WishlistController::class, 'deleteWishlist']);
Route::get('wishlist', [WishlistController::class, 'wishlist']);

Route::any('checkout', [OrderController::class, 'checkout']);
Route::post('place-order', [OrderController::class, 'placeOrder']);
Route::get('order-confirm/{id}', [OrderController::class, 'orderConfirm'])->name('order.confirm');
Route::get('invoice/{id}', [OrderController::class, 'invoice']);

Route::get('paypal-cancel', [OrderController::class, 'cancelTransaction'])->name('paypal.cancel');
Route::get('paypal-success', [OrderController::class, 'successTransaction'])->name('paypal.success');
Route::get('paypal-transaction', [OrderController::class, 'paypalTransaction'])->name('paypal.transaction');


//Route::get('stripe', [StripeController::class, 'stripePage'])->name('stripe');
//Route::post('stripe-pay', [StripeController::class, 'stripePay'])->name('stripe-pay');
Route::get('success-stripe-payment', [StripeController::class, 'successStripePayment'])->name('success-stripe-payment');


Route::get('user/reset-password', [UserController::class, 'resetPassword']);
Route::group(['prefix' => 'user'], function () {

    Route::middleware([CheckUserLog::class])->group(function () {
        Route::get('myaccount', [UserController::class, 'myaccount']);

        Route::get('offer-list', [UserController::class, 'offerList']);
        Route::get('add-offer', [UserController::class, 'addOffer']);
        Route::post('save-offer', [UserController::class, 'saveOffer']);
        Route::get('edit-offer/{id}', [UserController::class, 'editOffer']);
        Route::get('delete-offer/{id}', [UserController::class, 'deleteOffer']);
        Route::get('order-details/{id}', [UserController::class, 'orderDetails']);

        Route::get('voucher-redemption', [UserController::class, 'voucherRedemption']);
        Route::get('preview-redemption', [UserController::class, 'previewRedemption']);
        Route::post('apply-redemption', [UserController::class, 'applyRedemption']);

        Route::get('my-profile', [UserController::class, 'myProfile']);
        Route::post('update-profile', [UserController::class, 'updateProfile']);
        Route::get('change-password', [UserController::class, 'changePassword']);
      
        Route::post('update-user-password', [UserController::class, 'updateUserPassword']);
        Route::get('account-verify', [UserController::class, 'accountVerify']);
        Route::get('user-verify', [UserController::class, 'userVerify']);
        Route::get('logout', [UserController::class, 'logout']);
    });
});
