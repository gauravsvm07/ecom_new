<?php

namespace App\Helpers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Admin;
use App\Models\Cart;
use App\Models\PageSection;
use App\Models\Page;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\Setting;
use App\Models\UserDetail;
use App\Models\Menu;
use App\Models\Banner;
use App\Models\Blog;
use App\Models\Category;
use App\Models\Product;
use App\Models\Country;
use App\Models\Order;
use App\Models\Customer;
use App\Models\OrderStatus;
use App\Models\Influencer;
use App\Models\Redemption;
use App\Models\OrderAddress;
use App\Models\OrderItem;
use App\Models\WebSetting;
use App\Models\Permission;
use App\Models\RolePermission;
use Illuminate\Support\Facades\Http;
use App\Mail\CreditNoteMail;
use Mpdf\Mpdf;
use PDF;
use Mail;


class Helper
{

  public static function random_strings($length_of_string)
  {
    $str_result = 'abcdefghijklmnopqrstuvwxyz';
    return substr(str_shuffle($str_result), 0, $length_of_string);
  }
  public static function getMaxPrice()
  {
    $product_price = Product::max('maximum_price');

    return $product_price;
  }
  public static function getMinPrice()
  {
    return Product::min('price')->get();
  }
  public static function checkTest()
  {
    return 'hello';
  }


  public static function getPageSection($id)
  {
    $section = PageSection::where(['id' => $id, 'status' => 1])->first();
    if ($section) {
      return $section;
    } else {
      return '';
    }
  }

  

  public static function getSettingData($key)
  {
    $setting = Setting::where(['setting_key' => $key])->first();
    return $setting->setting_value;
  }

  public static function getGeneralSetting($key)
  {
    $setting = Setting::where(['setting_key' => $key])->first();
    return $setting->setting_value;
  }

  public static function getLogo()
  {
    return Admin::where(['id' => 2])->first()->image;
  }

  public static function getInnerBanner($type)
  {
    return Banner::where(['type' => $type])->first();
  }

  public static function getPageData($id)
  {
    $page = Page::where(['id' => $id, 'status' => 1])->first();
    if($page) 
    {
      return $page->descriptions;
    } else
    {
      return '';
    }
    
  }

  public static function getPageSectionData($id)
  {
    $page = PageSection::where(['id' => $id, 'status' => 1])->first();
    return $page;
  }


  public static function getBlogData()
  {
    $blogs = Blog::where(['status' => 1])->orderBy('id', 'desc')->take(3)->get();
    return $blogs;
  }
  public static function checkUniversalVoucher($voucher_id)
  {
    $product_id = OrderItem::where(['voucher_id' => $voucher_id])->first()->product_id;
    $product = Product::where('id',$product_id)->first();
    return $product['is_universal'] ?? 0;
  }

  public static function fullyRedemption($item_id)
  {

    $user_id = Auth::user()->id;
    $orderItem = OrderItem::where('id',$item_id)->first();
    $redemptionAmountSum = Redemption::where(['voucher_id' => $orderItem['voucher_id']])->sum('amount');
    $footer_info =  "<p style='color: #808080;'>".Helper::getWebSetting('voucher_footer_info')."</p>";
   
    $redemptionCount = Redemption::where(['voucher_id' => $orderItem['voucher_id']])->count();
    $balance_amount = 0;

    $oItem = OrderItem::where('id',$item_id)->first();
    $partner_id = $oItem['partner_id'];
    $product_id = $oItem['product_id'];
    $isUvoucher = Self::checkUniversalVoucher($product_id);

    ///$standard_sales_provision = UserDetail::where('user_id', $partner_id)->first()->standard_sales_provision;
    $standard_sales_provision = Helper::getRedemStandardVat($partner_id);
    $vat_sales_provision = Product::where('id', $product_id)->first()->vat ?? 0;
    $voucher_vat_sales_provision = Helper::getCNsalesProvision($product_id);
    $redem_amount = $orderItem['price'];
    $vat_amount = ($redem_amount * $vat_sales_provision)/100;
    $net_amount = $redem_amount;

    $standard_redem_amount =  ($redem_amount * $standard_sales_provision)/100;
    $standard_vat_amont =  ($net_amount * $standard_sales_provision)/100;

    $gross_total = $redem_amount - $standard_redem_amount;
    $vat_total = $net_amount - $standard_vat_amont;

  

    $getProduct = Product::where(['id'=> $product_id])->first();
    $voucher_po = $getProduct['voucher_po'];

    $redemption = new Redemption();
    $redemption->order_id = $orderItem['order_id'];
    $redemption->redemption_userid = $user_id;
    $redemption->order_item_id = $orderItem['id'];
    $redemption->voucher_id = $orderItem['voucher_code'];
    $redemption->product_id = $getProduct['id'];
    $redemption->voucher_type = $getProduct['voucher_type'];
    $redemption->voucher_desc = $getProduct['title'];
    $redemption->partner_id = $partner_id;
    $redemption->view_product_id = 'P'.Helper::getViewPartnerId($partner_id).'-'.Helper::getViewProductId($getProduct['id']);
    $redemption->view_partner_id = Helper::getViewPartnerId($partner_id);
    $redemption->redemption_id = 'R-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1);
    $redemption->credit_note_id = 'CN-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1);
    $redemption->standard_sales_rate = $vat_sales_provision;
    $redemption->vat_sales_rate = $vat_sales_provision;
    $redemption->voucher_sales_provision_rate = $voucher_vat_sales_provision ?? '';

    $redemption->vat_amount = $vat_amount;
    $redemption->standard_amount = $standard_vat_amont;
    $redemption->standard_redem_amount = $standard_redem_amount;
    $redemption->amount = round($net_amount + $vat_amount);
    $redemption->net_amount = $net_amount;

    $redemption->gross_total = $gross_total;
    $redemption->vat_total = $vat_total;

    $redemption->balance_amount = $balance_amount;
    $redemption->save();

    if ($redemption) {
      $mail_data['order'] = Order::where('id', $orderItem['order_id'])->first();
      $mail_data['customer'] = Customer::where('id',$mail_data['order']['customer_id'])->first();
      $mail_data['order_items'] = OrderItem::where('order_id', $orderItem['order_id'])->with('product')->get();
      $mail_data['cn_items'] = Redemption::where('id', $redemption->id)->get();
      $mail_data['user'] = User::where('id',$partner_id)->first();
      $data['partner'] = User::where('id',$redemption->partner_id)->first();
      $data['partner_details'] = UserDetail::where('user_id',$redemption->partner_id)->first();
      $data['order'] = Order::where('id', $orderItem['order_id'])->first();
      $data['order_items'] = OrderItem::where('order_id', $orderItem['order_id'])->with('product')->get();
      $data['cn_items'] = Redemption::where('id', $redemption->id)->get();
      $data['order_detail'] = OrderAddress::where('order_id', $data['order']->id)->first();
      $data['credit_note_id'] = 'CN-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1);
      $data['credit_date'] = date('d M, Y');
      $data['standard_sales_provision'] = $standard_sales_provision;
      $data['vat_sales_provision'] = $vat_sales_provision;
      $data['standard_amount'] = $standard_vat_amont;
      $data['vat_amount'] = $vat_amount;
      $data['net_amount'] = $net_amount;
      $data['voucher_po'] = $voucher_po;
      

      $mpdf = new Mpdf();
      $html = view('pdf.credit-note', $data)->render();
      $filePath = public_path('pdf/invoice/') . 'CN-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1) . '.pdf';
      $footerHtml = $footer_info;
      $mpdf->SetHTMLFooter($footerHtml);
      $mpdf->WriteHTML($html);
      $mpdf->Output($filePath, \Mpdf\Output\Destination::FILE);

      $attachments[] = [
        'file' => public_path('pdf/invoice/' . 'CN-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1) . '.pdf'),
        'options' => [
          'mime' => 'application/pdf',
          'as' => 'CN-' . $orderItem['voucher_code'] . '-' . ($redemptionCount + 1) . '.pdf',
        ],
        // Add more attachments with options as needed
      ];

      $universal_partner  = Helper::getWebSetting('universal_partner');
      $login_email = Auth::user()->email;
  
      if($universal_partner == $login_email)
      {
        $recever_email = $universal_partner;
        $cc_email = $mail_data['user']['email'];
        
        Mail::to($recever_email)
        ->cc($cc_email)
        ->send(new CreditNoteMail($mail_data, $attachments));
      }  else if($isUvoucher == 1)
      { 
        Mail::to($login_email)->send(new CreditNoteMail($mail_data, $attachments));
      }else
      {
        $recever_email = $mail_data['user']['email'];
        Mail::to($recever_email)->send(new CreditNoteMail($mail_data, $attachments));
      }

      
    }

    if($redemption)
    {
      return 1;
    } else
    {
      return 0;
    }
  }


  public static function getFooterMenu()
  {
    $menus = Menu::where(['status' => 1, 'type' => 'footer'])->orderBy('sort_order', 'desc')->get();
    return $menus;
  }

  public static function getWebSetting($field)
  {
    $data = WebSetting::where(['id' => 1])->first()->$field;
    return $data;
  }

  public static function getAllPermission()
  {
    $data = Permission::all();
    return $data ?? [];
  }


  
  public static function getPartnerDetail($user_id)
  {
    $data = UserDetail::where('user_id',$user_id)->first();
    return $data ?? [];
  }

  public static function getVatInclusive($price)
  {
    $data = WebSetting::where(['id' => 1])->first()->vat_sales_provision;
    $vat = ($data * $price) /100;
    $net_price = $price + $vat;
    return $net_price;
  }

  public static function getVoucherVat($voucher_id,$partner_id)
  {
    $voucher_vat = Product::where(['id' => $voucher_id])->first()->vat;
    //$partner_vat = UserDetail::where(['user_id' => $partner_id])->first()->standard_sales_provision;
    $setting_vat = WebSetting::where(['id' => 1])->first()->vat_sales_provision;

    if($voucher_vat != '')
    {
      $vat = $voucher_vat;
    } else
    {
      $vat = $setting_vat;
    }
 
    return $vat;
  }

  public static function getVoucherItemVat($item_id,$voucher_id,$partner_id)
  {
    $voucher_vat = OrderItem::where(['id' => $item_id])->first()->vat_rate;

    ///$voucher_vat = Product::where(['id' => $voucher_id])->first()->vat;
    $setting_vat = WebSetting::where(['id' => 1])->first()->vat_sales_provision;

    if($voucher_vat != '')
    {
      $vat = $voucher_vat;
    } else
    {
      $vat = $setting_vat;
    }
   
    return $vat;
  }



  

  public static function getVoucherLevelVat($voucher_id)
  {
    $voucher_vat = Product::where(['id' => $voucher_id])->first()->vat; 
    return $voucher_vat ?? 0;
  }


  public static function getFileType($filename)
  {
      // Define the extensions for images and videos
      $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'];
      $videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'webm', 'm4v'];

      // Extract the file extension
      $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

      // Check if the extension matches an image or video type
      if (in_array($extension, $imageExtensions)) {
          return 'image';
      } elseif (in_array($extension, $videoExtensions)) {
          return 'video';
      } else {
          return 'unknown';
      }
  }


  public static function getStandardVat($partner_id)
  {
    $partner_vat = UserDetail::where(['user_id' => $partner_id])->first()->standard_sales_provision;
    $setting_vat = WebSetting::where(['id' => 1])->first()->standard_sales_provision;

    if($partner_vat != '')
    {
      $vat = $partner_vat;
    } else
    {
      $vat = $setting_vat;
    }
 
    return $vat;
  }

  public static function getRedemStandardVat($partner_id)
  {
    ///$setting_vat = WebSetting::where(['id' => 1])->first()->standard_sales_provision;
    $setting_vat = WebSetting::where(['id' => 1])->first()->vat_sales_provision;
    return $setting_vat;
  }

  public static function getCNVat($voucher_id)
  {
    $vat = Product::where(['id' => $voucher_id])->first()->vat;
    return $vat;
  }

  public static function getOrderCNVat($order_item_id)
  {
    $vat = OrderItem::where(['id' => $order_item_id])->first()->vat_rate;
    return $vat;
  }

  public static function getCNsalesProvision($voucher_id)
  {
    $vat = Product::where(['id' => $voucher_id])->first()->voucher_sales_provision;
    return $vat;
  }

  public static function getCNItemsalesProvision($order_item_id)
  {
    $vat_rate = OrderItem::where(['id' => $order_item_id])->first()->vat_rate;
    return $vat_rate;
  }

  public static function getCNProvisionRate($order_id)
  {
    $vat_rate = Order::where(['id' => $order_id])->first()->standard_sales_provision;
    return $vat_rate;
  }

  public static function getRedemVat($partner_id)
  {
    ///$setting_vat = WebSetting::where(['id' => 1])->first()->standard_sales_provision;
    $setting_vat = WebSetting::where(['id' => 1])->first()->vat_sales_provision;
    return $setting_vat;
  }

  public static function getPartnerId()
  {
    $last_partner_id = User::orderBy('id','desc')->first()->id ?? 1;
    return 'P'.str_pad(($last_partner_id + 1), 5, 0, STR_PAD_LEFT);
  }

  public static function getViewPartnerId($partner_id)
  {
    return str_pad(($partner_id + 1), 5, 0, STR_PAD_LEFT);
  }

  public static function getViewProductId($product_id)
  {
    return str_pad(($product_id + 1), 3, 0, STR_PAD_LEFT);
  }

  public static function getPartnerProductId($user_id)
  {
    $last_product_id = User::where('id',$user_id)->orderBy('id','desc')->first()->last_product_id;

    ///dd($last_product_id);
    if($last_product_id)
    {
      $lp_id = (int) $last_product_id;
      $pid = $lp_id + 1;
    } else
    {
      $pid = 0;
    }
    User::where('id', $user_id)->update(['last_product_id' => $pid]);

    return str_pad(($pid + 1), 3, 0, STR_PAD_LEFT);
  }

  public static function getViewPartnerProductId($partner_id,$product_id)
  {
    return 'P'.str_pad(($partner_id), 6, 0, STR_PAD_LEFT).'-'.$product_id;
    //return 'P'.str_pad(($product_id), 5, 0, STR_PAD_LEFT).'-'.str_pad(($partner_id), 3, 0, STR_PAD_LEFT);
  }

  public static function getOrderPartnerProductId($partner_id,$product_id)
  {
    return 'P'.str_pad(($product_id), 5, 0, STR_PAD_LEFT).'-'.str_pad(($partner_id), 3, 0, STR_PAD_LEFT);
  }

  public static function getInfluencerId()
  {
    $last_influencer_id = Influencer::orderBy('id','desc')->first()->id ?? 1;
    return 'INFL'.str_pad(($last_influencer_id + 1), 3, 0, STR_PAD_LEFT);
  }


  public static function getPartnerSalesProvision($user_id)
  {
    $standard_sales_provision = UserDetail::orderBy('user_id','desc')->first()->standard_sales_provision ?? 5;
    return $standard_sales_provision;
  }


  public static function CnVat($amount,$vat)
  {
    $divisor = $vat/100;
    $result = $amount / ($divisor + 1);
    return $result;
  }


  public static function cartCount()
  {
    $carts = Session::get('cart', []);
    return count($carts);
  }


  public function getMenu()
  {
    $menu = new Menu;
    $menuList = $menu->tree();
    return $menuList;
  }

  function cleanString($string)
  {
    $string = str_replace(' ', '_', $string); // Replaces all spaces with hyphens.
    return str_replace(array('\'', '"', ',', ';', '<', '>', '(', ')'), ' ', $string);
    ///return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes
    ///return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
  }


  public static function getSidebarCategory()
  {
    $data = Category::where('status', 1)->orderby('id', 'desc')->get();
    return $data;
  }

  public static function getSidebarCountry()
  {
    $data = Country::where('show_status', 1)->orderby('name', 'asc')->get();
    return $data;
  }

  public static function getOfferCategoryCount($id)
  {
    $data = Category::where(['status' => 1])->count();
    return $data;
  }

  public static function getOfferCountryCount()
  {
    $data = Country::where(['show_status' => 1])->count();
    return $data;
  }

  public static function getOrderStatus()
  {
    $status = OrderStatus::where('status', 1)->orderBy('name', 'asc')->get();
    return $status;
  }


  public static function eur_number_format($number, $dec_point='.', $thousands_sep=','){
    if($dec_point==$thousands_sep){
        trigger_error('2 parameters for ' . __METHOD__ . '() have the same value, that is "' . $dec_point . '" for $dec_point and $thousands_sep', E_USER_WARNING);
        // It corresponds "PHP Warning:  Wrong parameter count for number_format()", which occurs when you use $dec_point without $thousands_sep to number_format().
    }
    $decimals = strlen(substr(strrchr($number, "."), 1));

    return number_format($number, $decimals, $dec_point, $thousands_sep);
}



public static function checkHasRole($module_id)
{
   $role_id = Auth::guard('admin')->user()->role_id;
  $permission = RolePermission::where(['role_id' => $role_id , 'permission_id' => $module_id])->first();
  if($permission)
  {
    return true;
  } else 
  {
    return false;
  }
}





}
