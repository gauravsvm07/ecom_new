@extends('layouts.admin_layout')
@section('content')
@section('title', 'Add Voucher')


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">@if(isset($product)) Edit @else Add @endif Voucher</h4>

                        </div><!-- end card header -->

                        <div class="card-body">
                            @if (session('msg'))
                            <div class="alert alert-{{ session('msg_type') }}" role="alert">
                                {{ session('msg') }}
                            </div>
                            @endif

                            <form method="post" action="{{url('admin/product/save')}}" enctype="multipart/form-data">
                                @csrf

                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs mb-3" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" data-bs-toggle="tab" href="#product" role="tab" aria-selected="false" tabindex="-1">
                                            Product
                                        </a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" data-bs-toggle="tab" href="#meta" role="tab" aria-selected="true">
                                            Meta
                                        </a>
                                    </li>

                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content  text-muted">

                                    <div class="tab-pane active" id="product" role="tabpanel">

                                    
                            @if(isset($product) && $product->offer_code != '')
                            <div class="row gy-4">
                            <div class="col-xxl-12 col-md-12">
                                 <h3>Voucher ID: {{App\Helpers\Helper::getViewPartnerProductId($product->user_id,$product->partner_product_id)}}</h3>
                            </div>
                            </div>
                            @endif

                                        <div class="row gy-4">

                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="title" class="form-label">Title</label>
                                                    <input type="text" class="form-control" name="title" value="{{ isset($product)?$product->title:old('title') }}">
                                                </div>
                                                @error('title')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="user_id" class="form-label">Partner</label>
                                                    <select name="user_id" class="form-control">
                                                        @foreach($users as $user)
                                                        <option value="{{$user->id}}" @if(isset($product) && $product->user_id == $user->id) {{"selected"}} @endif>{{$user->userDetails->company}}</option>
                                                        @endforeach
                                                    </select>

                                                    @error('user_id')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>

                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="additional_info" class="form-label">Additional information</label>
                                                    <input type="text" class="form-control" name="additional_info" value="{{ isset($product)?$product->additional_info:old('additional_info') }}">
                                                </div>
                                                @error('additional_info')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>

                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="category_id" class="form-label">Category: </label><br>
                                                    @foreach($categories as $category)
                                                    <input type="checkbox" name="category[]" id="{{$category->id}}" value="{{$category->id}}" @if(isset($product)) {{ in_array($category->id, $product_categories) ? 'checked' : '' }} @endif> <label for="{{$category->id}}">{{$category->title}} </label>
                                                    @endforeach
                                                </div>
                                                @error('category_id')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Country</label>
                                                    <select name="country" id="country" class="form-control">
                                                        <option value="" @if(isset($product) && $product->country == '') {{"selected"}} @endif>--Select--</option>
                                                        @foreach($countries as $country)
                                                        <option value="{{$country->id}}" @if(isset($product) && $product->country == $country->id) {{"selected"}} @endif>{{$country->emoji}} {{$country->name}}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('country')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror
                                                </div>
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="affiliate_url" class="form-label">Affiliate Link</label>
                                                    <input type="url" class="form-control" name="affiliate_url" value="{{ isset($product)?$product->affiliate_url:old('affiliate_url') }}">
                                                </div>
                                                @error('affiliate_url')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>

                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Affiliate Status</label>
                                                    <select name="affiliate_status" class="form-control">
                                                        <option value="" @if(isset($product) && $product->affiliate_status == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="1" @if(isset($product) && $product->affiliate_status == 1) {{"selected"}} @endif>Active</option>
                                                        <option value="0" @if(isset($product) && $product->affiliate_status == 0) {{"selected"}} @endif>Inactive</option>
                                                    </select>

                                                    @error('affiliate_status')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>

                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Price Type</label>
                                                    <select name="price_type" class="form-control" id="price_type">
                                                        <option value="" @if(isset($product) && $product->price_type == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="fixed" @if(isset($product) && $product->price_type == 'fixed') {{"selected"}} @endif>Fixed</option>
                                                        <option value="price_range" @if(isset($product) && $product->price_type == 'price_range') {{"selected"}} @endif>Price Range</option>
                                                    </select>

                                                    @error('price_type')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>



                                            <div class="col-xxl-6 col-md-6" style="display: @if(isset($product) && $product->price_type=='fixed') block @else none @endif;" id="net_price">
                                                <div>
                                                    <label for="price" class="form-label">Net Price</label>
                                                    <input type="text" class="form-control" name="price" value="{{ isset($product)?$product->price:old('price') }}">
                                                </div>
                                                @error('price')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-6 col-md-6" style="display: @if(isset($product) && $product->price_type=='price_range') block @else none @endif;" id="minimum_price">
                                                <div>
                                                    <label for="minimum_price" class="form-label">Minimum Price</label>
                                                    <input type="text" class="form-control" name="minimum_price" value="{{ isset($product)?$product->minimum_price:old('minimum_price') }}">
                                                </div>
                                                @error('minimum_price')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-6 col-md-6" style="display: @if(isset($product) && $product->price_type=='price_range') block @else none @endif;" id="maximum_price" >
                                                <div>
                                                    <label for="maximum_price" class="form-label">Maximum Price</label>
                                                    <input type="text" class="form-control" name="maximum_price" value="{{ isset($product)?$product->maximum_price:old('maximum_price') }}">
                                                </div>
                                                @error('maximum_price')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="sell_price" class="form-label">Vat</label>
                                                    <input type="text" class="form-control" name="vat" value="{{ isset($product)?$product->vat:old('vat') }}">
                                                </div>
                                                @error('vat')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="sell_price" class="form-label">Voucher Sales Provisions (%)</label>
                                                    <input type="text" class="form-control" name="voucher_sales_provision" value="{{ isset($product)?$product->voucher_sales_provision:old('voucher_sales_provision') }}">
                                                </div>
                                                @error('voucher_sales_provision')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>


                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="descriptions" class="form-label">Description</label>
                                                    <textarea class="form-control" name="descriptions"> {{ isset($product)?$product->descriptions:old('descriptions') }}</textarea>
                                                </div>
                                                @error('descriptions')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>



                                            <div class="col-xxl-3 col-md-3">
                                                <div>
                                                    <label for="name" class="form-label">Voucher Type</label>
                                                    <select name="voucher_type" class="form-control">
                                                        <option value="" @if(isset($product) && $product->voucher_type == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="single_purpose" @if(isset($product) && $product->voucher_type == 'single_purpose') {{"selected"}} @endif>Single Purpose</option>
                                                        <option value="multiple_purpose" @if(isset($product) && $product->voucher_type == 'multiple_purpose') {{"selected"}} @endif>Multiple Purpose</option>
                                                    </select>
                                                    @error('voucher_type')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror
                                                </div>
                                            </div>



                                            {{----
                                            <div class="col-xxl-3 col-md-3">
                                                <div>
                                                    <label for="name" class="form-label">Voucher (Physical/Online)</label>
                                                    <select name="voucher_po" class="form-control">
                                                        <option value="" @if(isset($product) && $product->voucher_po == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="physical" @if(isset($product) && $product->voucher_po == 'physical') {{"selected"}} @endif>Physical</option>
                                                        <option value="online" @if(isset($product) && $product->voucher_po == 'online') {{"selected"}} @endif>Online</option>
                                                    </select>
                                                    @error('voucher_po')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                           
                                            <div class="col-xxl-2 col-md-2">
                                                <div class="">
                                                    <label for="termination_date" class="form-label">Termination date</label>
                                                    <input type="date" class="form-control" name="termination_date" value="{{ isset($product)?date('Y-m-d', strtotime($product->termination_date)):old('termination_date') }}">
                                                </div>
                                                @error('termination_date')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>
                                            ---}}

                                             
                                            <div class="col-xxl-3 col-md-3">
                                                <div>
                                                    <label for="name" class="form-label">Voucher Validity Type</label>
                                                    <select name="voucher_validity_type" class="form-control">
                                                        <option value="" @if(isset($product) && $product->voucher_validity_type == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="1" @if(isset($product) && $product->voucher_validity_type == '1') {{"selected"}} @endif>Purchase Date</option>
                                                        <option value="2" @if(isset($product) && $product->voucher_validity_type == '2') {{"selected"}} @endif>First of January</option>
                                                    </select>
                                                    @error('voucher_validity_type')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror
                                                </div>
                                            </div>


                                            <div class="col-xxl-2 col-md-2">
                                                <div class="">
                                                    <label for="voucher_validity" class="form-label">Voucher Validity (Month)</label>
                                                    <input type="text" class="form-control" name="voucher_validity" value="{{ isset($product)?$product->voucher_validity:old('voucher_validity') }}">
                                                </div>
                                                @error('voucher_validity')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>

                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="validity_message" class="form-label">Why you changing validity setting</label>
                                                    <textarea class="form-control" name="validity_message"> {{ isset($product)?$product->validity_message:old('validity_message') }}</textarea>
                                                </div>
                                                @error('validity_message')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>




                                            <div class="col-xxl-2 col-md-2">
                                                <div>
                                                    <label for="zip_code" class="form-label">Zip Code</label>
                                                    <input type="text" class="form-control" name="zip_code" value="{{ isset($product)?$product->zip_code:old('zip_code') }}">
                                                </div>
                                                @error('zip_code')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>




                                            <div class="col-xxl-2 col-md-2">
                                                <div>
                                                    <label for="name" class="form-label">Status</label>
                                                    <select name="status" class="form-control">
                                                        <option value="" @if(isset($product) && $product->status == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="1" @if(isset($product) && $product->status == 1) {{"selected"}} @endif selected="">Active</option>
                                                        <option value="0" @if(isset($product) && $product->status == 0) {{"selected"}} @endif>Inactive</option>
                                                    </select>

                                                    @error('status')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>


                                        </div>
                                        <div class="row">
                                            <div class="col-xxl-2 col-md-2">
                                                <div>
                                                    <label for="deal_bg" class="form-label">Latitude</label>
                                                    <input type="text" class="form-control" id="latitude" name="latitude" value="{{ isset($product)?$product->latitude:old('latitude') }}">
                                                </div>
                                                @error('latitude')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="col-md-2">
                                                <div>
                                                    <label for="deal_bg" class="form-label">Longitude</label>
                                                    <input type="text" class="form-control" id="longitude" name="longitude" value="{{ isset($product)?$product->longitude:old('longitude') }}">
                                                </div>
                                                @error('longitude')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="col-md-2">
                                                <label style="display: block;">&nbsp;</label>
                                                <button type="button" class="btn btn-primary" onclick="getLocation()">Get current Location</button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane show" id="meta" role="tabpanel">
                                        <div class="row gy-4">


                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="meta_title" class="form-label">Meta Title</label>
                                                    <input type="text" class="form-control" name="meta_title" value="{{ isset($product)?$product->meta_title:old('meta_title') }}">
                                                </div>
                                                @error('meta_title')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>

                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="meta_keyword" class="form-label">Meta Keyword</label>
                                                    <textarea class="form-control" name="meta_keyword"> {{ isset($product)?$product->meta_keyword:old('meta_keyword') }}</textarea>
                                                </div>
                                                @error('meta_keyword')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>

                                            <div class="col-xxl-12 col-md-12">
                                                <div>
                                                    <label for="meta_description" class="form-label">Meta Description</label>
                                                    <textarea class="form-control" name="meta_description"> {{ isset($product)?$product->meta_description:old('meta_description') }}</textarea>
                                                </div>
                                                @error('meta_description')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror
                                            </div>




                                            <!--end col-->

                                            <!--end col-->
                                        </div>
                                    </div>


                                </div>
                                <br>
                                <div class="row gy-4">
                                    <div class="col-xxl-4 col-md-4">
                                        <input type="hidden" name="product_id" value="{{ isset($product)?$product->id:old('product_id') }}">
                                        <input type="submit" class="btn btn-info" value="submit">
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->




        </div> <!-- container-fluid -->
    </div><!-- End Page-content -->

    @include('includes.admin.footer')
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->

<script>
    $(function() {
        $('#net_price').hide();
        $('#minimum_price').hide();
        $('#maximum_price').hide();
        //$('#price_type').change(function() {
            $(document).ready(function(){
            if ($('#price_type').val() == 'fixed') {
                // $('#net_price').show();
                // $('#minimum_price').hide();
                // $('#maximum_price').hide();

                $("#net_price").css("display", "block");
                $("#minimum_price").css("display", "none");
                $("#maximum_price").css("display", "none");
            } else if ($('#price_type').val() == 'price_range') {
                // $('#net_price').hide();
                // $('#minimum_price').show();
                // $('#maximum_price').show();
                $("#net_price").css("display", "none");
                $("#minimum_price").css("display", "block");
                $("#maximum_price").css("display", "block");
            } else {
                //$('#net_price').hide();
                //$('#minimum_price').hide();
                //$('#maximum_price').hide();
            }
        });
    });
</script>



<script>
    const lat = document.getElementById("latitude");
    const long = document.getElementById("longitude");

    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
        } else {
            x.innerHTML = "Geolocation is not supported by this browser.";
        }
    }

    function showPosition(position) {
        lat.value = position.coords.latitude;
        long.value = position.coords.longitude;
    }
</script>
@stop