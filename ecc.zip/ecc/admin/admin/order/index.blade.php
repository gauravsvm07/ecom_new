@extends('layouts.admin_layout')
@section('content')
@section('title', 'Order List')

<style>
  .live-preview svg {
    width: 15px;
  }
</style>


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

  <div class="page-content">
    <div class="container-fluid">

      <!-- start page title -->

      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">
                            <a href="{{url('admin/order-csv')}}" class="btn btn-info">Upload Order </a>
                            </h4>
              <div class="flex-shrink-0">
              <a href="{{url('admin/order/auto-cancel')}}" target="_blank" class="btn btn-info">Auto cancel order</a>
              </div>
            </div><!-- end card header -->

            <div class="card-body">

              <div class="live-preview">

                @if (session('msg'))
                <div class="alert alert-success" role="alert">
                  {{ session('msg') }}
                </div>
                @endif


                <div class="table-responsive pb-4">
                <table class="table align-middle table-nowrap mb-0" id="getDataTable">
                    <thead class="table-light">
                      <tr>
                        <th>#</th>
                        <th>Order Id</th>
                        <th>Amount </th>
                        <th>Payment Id</th>
                        <th>Payment Via</th>
                        <th>Payment Status</th>
                        <th>Date/Time</th>
                        <th>Order Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>


                      @foreach($orders as $key=>$order)
                      <tr>
                        <td>{{ $key+1 }}</td>
                        <td>{{ $order->order_id ?? '-' }}</td>
                        <td>€{{ $order->amount ?? '-' }}</td>
                        <td>{{ $order->payment_id ?? '-' }}</td>
                        <td>{{ $order->payment_via ?? '-' }}</td>
                        @if($order->payment_via == 'Manual_Payment')
                        <td> <select class="form-control changePayStatus1" order-id="{{$order->id}}" disabled>
                            <option value="1" {{ $order->payment_status == 1 ? 'selected' : '' }}>Pending</option>
                            <option value="3" {{ $order->payment_status == 3 ? 'selected' : '' }}>Success</option>
                          </select>

                          <a class="btn btn-primary btn-sm waves-effect waves-light uploadBtn" data-toggle="modal" href="javascript:void(0)" row_id="{{$order->id}}">
                            <i class="fa fa-file"></i> Upload Docs
                          </a>

                        </td>
                        @else
                        <td>@if($order->payment_status == 3) Success @else Pending @endif </td>
                        @endif

                        <td>{{ date('d-M-Y h:i:s A', strtotime($order->created_at))}}</td>

                        <td>
                          <form>
                            @php
                            $order_status = App\Helpers\Helper::getOrderStatus();
                            @endphp
                            <select class="form-control changeStatus" order-id="{{$order->id}}">
                              @foreach($order_status as $order_row)
                              <option value="{{$order_row->id}}" {{ $order->order_status == $order_row->id ? 'selected' : '' }}>{{$order_row->name}}</option>
                              @endforeach
                            </select>
                          </form>
                        </td>
                        <td>
                          <a href="{{url('admin/order/view/'.$order->id)}}" class="btn btn-info btn-sm">View </a> &nbsp;
                          <a href="{{url('invoice/'.$order->uuid)}}" target="_blank" class="btn btn-success btn-sm">Invoice </a> &nbsp;
                        </td>
                        @endforeach
                      </tr>

                    </tbody>

                  </table>

                 {{-- {{$orders->links()}} --}}
                  <!-- end table -->
                </div>
                <!-- end table responsive -->
              </div>

            </div><!-- end card-body -->
          </div><!-- end card -->
        </div><!-- end col -->
      </div>
      <!--end row-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->

  @include('includes.admin.footer')
</div>
<!-- end main content-->


<!-- The Modal -->


<!-- END layout-wrapper -->

@include('includes/admin/delete-model')

<div class="modal fade" id="upload_modal" aria-hidden="true" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">

      <div class="modal-body">
        <div class="form-content p-2">
          <h4 class="modal-title">Upload Doc</h4>
          <form method="post" action="{{url('admin/order/upload-doc/')}}" enctype="multipart/form-data">
            @csrf
            <div class="row gy-4">

              <div class="col-xxl-12 col-md-12">
                <div>
                  <label for="file_name" class="form-label">File</label>
                  <input type="file" class="form-control" name="file_name[]" multiple>
                </div>
                @error('file_name')
                <span class="text-danger">{{$message}}</span>
                @enderror
              </div>

              <div class="col-xxl-12 col-md-12">
                <div>
                  <label for="descriptions" class="form-label">Description</label>
                  <textarea class="form-control" name="descriptions"></textarea>
                </div>
                @error('description')
                <span class="text-danger">{{$message}}</span>
                @enderror
              </div>

              <div class="col-xxl-3 col-md-6">
                <div>
                  <input type="hidden" class="get_row_id" name="order_id">
                  <input type="submit" class="btn btn-success" value="Submit">
                </div>
              </div>

            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


<script>
  $(document).ready(function() {
    $('.uploadBtn').on('click', function() {
      var row_id = $(this).attr('row_id');
      $('.get_row_id').val(row_id);
      $('#upload_modal').modal('show');
    });


    $(document).on('change', '.changeStatus', function() {
      ///alert('test');
      var id = $(this).attr("order-id");
      //alert(id);
      var status_id = this.value;
      ///alert(status_id);
      $.ajax({
        url: "{{url('admin/order/change-order-status')}}",
        method: "get",
        data: {
          order_id: id,
          status_id: status_id
        },
        success: function(data) {
          $('#status_msg').text('Order status updated');
          $('#status_msg').fadeIn(250).fadeOut(1500);
          ///alert('Order status updated');
          //alert(data.status_id);
        }
      });
    });


    $(document).on('change', '.changePayStatus', function() {
      ///alert('test');
      var id = $(this).attr("order-id");
      //alert(id);
      var status_id = this.value;
      ///alert(status_id);
      $.ajax({
        url: "{{url('admin/order/change-order-paystatus')}}",
        method: "get",
        data: {
          order_id: id,
          status_id: status_id
        },
        success: function(data) {
          $('#status_msg').text('Order status updated');
          $('#status_msg').fadeIn(250).fadeOut(1500);
          ///alert('Order status updated');
          //alert(data.status_id);
        }
      });
    });


  });
</script>

<script>
new DataTable('#getDataTable');
</script>



@stop