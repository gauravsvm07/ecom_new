@extends('layouts.admin_layout')
@section('content')
@section('title', 'View Booking')

<style>
    .live-preview svg {
        width: 15px;
    }
</style>


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">View Order </h4>
                            <div class="flex-shrink-0">
                                &nbsp;
                            </div>
                        </div><!-- end card header -->

                        <div class="card-body">

                            <div class="live-preview">
                                <div class="table-responsive pb-4">

                                <h4> Order Items </h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                                <th>#</th>
                                                <th>Offer</th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Vat</th>
                                                <th>Net Price</th>
                                                <th>Voucher Id</th>
                                                <th>Voucher</th>
                                                <th>View</th>
                                            </tr>
                                            @php 
                                              $orderItemCount = count($items);
                                             @endphp
                                              @foreach($items as $key=>$item)
                                                <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ $item->product->title ?? '-' }}</td>
                                                <td>{{ $item->quantity ?? '-' }}</td>
                                                <td>€{{ $item->price ?? '-' }}</td>
                                                <td>€{{ $item->vat ?? '-' }}</td>
                                                <td>€{{ $item->net_price ?? '-' }}</td>
                                                <td>{{ $item->voucher_id ?? '-' }}</td>
                                                <td> 
                                                    @if($orderItemCount > 1)
                                                <a href="{{url('public/pdf/voucher/'.$item->voucher_id.'.pdf')}}" target="_blank">View Voucher</a>
                                                @else 
                                                <a href="{{url('public/pdf/voucher/'.$item->voucher_code.'.pdf')}}" target="_blank">View Voucher</a>
                                                @endif
                                                
                                                </td>
                                                <td><a href="{{url('offer/'.$item->slug)}}" target="_blank">View</a></td>
                                                </tr>
                                               

                                                @endforeach
                                            
                                        </tbody>
                                    </table>

                                    <h4> Redemption Detail </h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                                <th>#</th>
                                                <th>Voucher Id</th>
                                                <th>Redem Amount</th>
                                                <th>Balance Amount</th>
                                                <th>Redemption Id</th>
                                                <th>Credit Note Id</th>
                                                <th>View</th>
                                            </tr>
                                              @foreach($redemptions as $key=>$redemption)
                                                <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ $redemption->voucher_id ?? '-' }}</td>
                                                <td>{{ $redemption->amount ?? '-' }}</td>
                                                <td>{{ $redemption->balance_amount ?? '-' }}</td>
                                                <td>{{ $redemption->redemption_id ?? '-' }}</td>
                                                <td>{{ $redemption->credit_note_id ?? '-' }}</td>
                                                <td> 
                                                    <a href="{{url('public/pdf/voucher/'.$redemption->voucher_id.'.pdf')}}" target="_blank" class="btn btn-primary btn-xs">View Voucher</a>
                                                    <a href="{{url('public/pdf/invoice/'.$redemption->credit_note_id.'.pdf')}}" target="_blank" class="btn btn-success btn-xs">View CN</a>
                                            </td>
                                                </tr>
                                               

                                                @endforeach
                                            
                                        </tbody>
                                    </table>


                                    <h4>Manual Order </h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                                <th>S.No</th>
                                                <th>ID</th>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Order ID</th>
                                                <th>Payment Reffeance</th>
                                                <th>Description</th>
                                            </tr>
                                              @foreach($manual_orders as $key=>$manual_order)
                                                <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td> {{ $manual_order->manual_id ?? '-' }}</td>
                                                <td> {{ $manual_order->pay_date ?? '-' }}</td>
                                                <td> {{ $manual_order->currency ?? '-' }} {{ $manual_order->amount ?? '-' }}</td>
                                                <td> {{ $manual_order->order_id ?? '-' }}</td>
                                                <td> {{ $manual_order->payment_id ?? '-' }}</td>
                                                <td> {{ $manual_order->descriptions ?? '-' }}</td>
                                                
                                                </tr>
                                                  @endforeach
                                            
                                        </tbody>
                                    </table>


                                    <h4> Order Docs </h4>
                                    <table class="table table-bordered">
                                        <tbody>
                                        <tr>
                                                <th>#</th>
                                                <th>Descriptions</th>
                                                <th>FIle</th>
                                            </tr>
                                              @foreach($docs as $key=>$doc)
                                                <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td> {{ $doc->descriptions ?? '-' }}</td>
                                                <td> <a href="{{URL::asset($doc->file_name)}}"> Preview</a></td>
                                                </tr>
                                                  @endforeach
                                            
                                        </tbody>
                                    </table>

                                    <h4> Order Detail </h4>
                                    <table class="table table-bordered">
                                        <tbody>

                                            <tr>
                                                <th>Name</th>
                                                <td>{{ $address->first_name ?? '-' }} {{ $address->last_name ?? '-' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Email Id</th>
                                                <td>{{ $address->email ?? '-' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Phone No</th>
                                                <td>{{ $address->phone ?? '-' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Address</th>
                                                <td>{{ $address->address ?? '-' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Country</th>
                                                <td>{{ $address->country ?? '-' }} </td>
                                            </tr>

                                            <tr>
                                                <th>City</th>
                                                <td> {{ $address->city ?? '-' }}</td>
                                            </tr>

                                            <tr>
                                                <th>Zip Code</th>
                                                <td> {{ $address->zip_code ?? '-' }}</td>
                                            </tr>


                                           



                                        </tbody>
                                    </table>




                                    <!-- end table -->
                                </div>
                                <!-- end table responsive -->
                            </div>

                        </div><!-- end card-body -->
                    </div><!-- end card -->
                </div><!-- end col -->
            </div>
            <!--end row-->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    @include('includes.admin.footer')
</div>



@stop