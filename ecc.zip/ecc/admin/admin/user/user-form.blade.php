@extends('layouts.admin_layout')
@section('content')
@section('title', 'Add Partner')


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1"> @if(isset($user)) View @else Add @endif Partner</h4>

                        </div><!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                @if (session('msg'))
                                <div class="alert alert-{{ session('msg_type') }}" role="alert">
                                    {{ session('msg') }}
                                </div>
                                @endif


                                <form method="post" action="{{url('admin/user/save')}}" enctype="multipart/form-data">
                                    @csrf

                                    @if(isset($user) && $user->partner_id != '')
                                    <div class="row gy-4">
                                        <div class="col-xxl-12 col-md-12">
                                            <h3>Partner ID: {{$user->partner_id}}</h3>
                                            <br>
                                        </div>
                                    </div>
                                    @endif

                                    <div class="row gy-4">

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="company" class="form-label"> Company</label>
                                                <input type="text" class="form-control" name="company" value="{{ isset($user_detail)?$user_detail->company:old('company') }}">
                                            </div>
                                            @error('company')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="name" class="form-label">Contact Person</label>
                                                <input type="text" class="form-control" name="name" value="{{ isset($user)?$user->name:old('name') }}">
                                            </div>
                                            @error('name')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="email" class="form-label">Email Id</label>
                                                <input type="email" class="form-control" name="email" value="{{ isset($user)?$user->email:old('email') }}">
                                            </div>
                                            @error('email')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="phone" class="form-label">Phone</label>
                                                <input type="text" class="form-control" name="phone" value="{{ isset($user)?$user->phone:old('phone') }}">
                                            </div>
                                            @error('phone')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>




                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="street" class="form-label"> Street & House Number</label>
                                                <input type="text" class="form-control" name="street" value="{{ isset($user_detail)?$user_detail->street:old('street') }}">
                                            </div>
                                            @error('street')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="zipcode" class="form-label"> Zip code & Town</label>
                                                <input type="text" class="form-control" name="zipcode" value="{{ isset($user_detail)?$user_detail->zipcode:old('zipcode') }}">
                                            </div>
                                            @error('country')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="country" class="form-label"> Country</label>
                                                <select class="form-control" name="country">
                                                    <option value="">Choose...</option>
                                                    @foreach($countries as $country)
                                                    <option value="{{$country->name}}" @if(isset($user_detail) && $user_detail->country == $country->name) {{"selected"}} @endif>{{$country->emoji}} {{$country->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            @error('country')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="vat_number" class="form-label"> VAT Number
                                                    <?php
                                                    if (!empty($user_detail->vat_verify)) {
                                                        $var_data = json_decode($user_detail->vat_verify);
                                                        ///print_r($var_data->valid);
                                                        if (isset($var_data->valid) && $var_data->valid == 1) { ?>
                                                            <span class="success" style="color:green">Status: Varified </span>
                                                        <?php } else { ?>

                                                            <span class="danger" style="color:red">Status: Not Varified </span>
                                                    <?php  }
                                                    }
                                                    ?>
                                                </label>
                                                <input type="text" class="form-control" name="vat_number" value="{{ isset($user_detail)?$user_detail->vat_number:old('vat_number') }}">
                                            </div>
                                            @error('vat_number')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="standard_sales_provision" class="form-label">Standard Sales Provision(%)</label>
                                                <input type="text" class="form-control" name="standard_sales_provision" value="{{ isset($user_detail)?$user_detail->standard_sales_provision:old('standard_sales_provision') }}">
                                            </div>
                                            @error('standard_sales_provision')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="bank_account" class="form-label">Bank account owner</label>
                                                <input type="text" class="form-control" name="bank_account" value="{{ isset($user_detail)?$user_detail->bank_account:old('bank_account') }}">
                                            </div>
                                            @error('bank_account')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="iban" class="form-label">IBAN</label>
                                                <input type="text" class="form-control" name="iban" value="{{ isset($user_detail)?$user_detail->iban:old('iban') }}">
                                            </div>
                                            @error('iban')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>




                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="swift" class="form-label">SWIFT</label>
                                                <input type="text" class="form-control" name="swift" value="{{ isset($user_detail)?$user_detail->swift:old('swift') }}">
                                            </div>
                                            @error('swift')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="image" class="form-label">Image</label>
                                                <input type="file" class="form-control" name="image" value="{{ isset($user_detail)?$user_detail->image:old('image') }}">
                                            </div>
                                            @error('image')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="video" class="form-label">Video</label>
                                                <input type="file" class="form-control" name="video" value="{{ isset($user_detail)?$user_detail->video:old('video') }}">
                                            </div>
                                            @error('video')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="youtube_code" class="form-label">YouTube Embed Code</label>
                                                <input type="text" class="form-control" name="youtube_code" value="{{ isset($user_detail)?$user_detail->youtube_code:old('youtube_code') }}" placeholder="eg. FkQuawiGWUw">
                                            </div>
                                            @error('youtube_code')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="about" class="form-label">Story</label>
                                                <textarea class="form-control" name="about"> {{ isset($user_detail)?$user_detail->about:old('about') }}</textarea>
                                            </div>
                                            @error('about')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="comment" class="form-label">Internal comment to the Community-Gutschein Team</label>
                                                <textarea class="form-control" name="comment">{{ isset($user_detail)?$user_detail->comment:old('comment') }} </textarea>
                                            </div>
                                            @error('comment')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="name" class="form-label">Status</label>
                                                <select name="status" class="form-control">
                                                    <option value="" @if(isset($user) && $user->status == '') {{"selected"}} @endif>--Select--</option>
                                                    <option value="1" @if(isset($user) && $user->status == 1) {{"selected"}} @endif>Active</option>
                                                    <option value="0" @if(isset($user) && $user->status == 0) {{"selected"}} @endif>Inactive</option>
                                                </select>

                                                @error('status')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror

                                            </div>
                                        </div>

                                    </div>
                                    <div class="row gy-4 mt-20">
                                        <hr style="color: #fff;">
                                        @if(isset($user) && $user->image)
                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="" class="form-label"> Image</label>
                                                <img src="{{URL::asset($user->image)}}" height="100px;" width="150px;">
                                            </div>
                                        </div>
                                        @endif


                                        @if(isset($user) && $user_detail->video)

                                        @php
                                        // Example file path
                                        $filePath = URL::asset($user_detail->video);
                                        // Get the file extension
                                        $extension = pathinfo($filePath, PATHINFO_EXTENSION);
                                        @endphp
                                        <div class="col-xxl-4 col-md-4">
                                            @if(in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg']))
                                            <img src="{{URL::asset($user_detail->video)}}" height="100px;" width="150px;">
                                            @elseif(in_array($extension, ['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv']))
                                            <div class="form-group">
                                                <label for="" class="form-label"> Video/Image</label>
                                                <video width="200" height="150" controls>
                                                    <source src="{{URL::asset($user_detail->video)}}" type="video/mp4">
                                                    <source src="{{URL::asset($user_detail->video)}}" type="video/ogg">
                                                    Your browser does not support the video tag.
                                                </video>
                                            </div>
                                            @endif


                                        </div>
                                        @endif


                                        @if(isset($user) && $user_detail->youtube_code)
                                        <div class="col-xxl-4 col-md-4">
                                            <div>
                                                <label for="" class="form-label"> Video</label>
                                                <iframe style="display:block;" width="200px" height="150px;" src="{{$user_detail->youtube_code}}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

                                            </div>
                                        </div>
                                        @endif

                                    </div>


                                    <br><br>
                                    <div class="row gy-4">

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <input type="hidden" name="old_image" value="{{ isset($user)?$user->image:old('old_image') }}">
                                                <input type="hidden" name="user_id" value="{{ isset($user)?$user->id:old('user_id') }}">
                                                <input type="submit" class="btn btn-success" value="Submit">
                                            </div>
                                        </div>
                                    </div>

                                    <!--end row-->
                                </form>



                            </div>

                        </div>
                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->




        </div> <!-- container-fluid -->
    </div><!-- End Page-content -->

    @include('includes.admin.footer')
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->



@stop