@extends('layouts.admin_layout')
@section('content')
@section('title', 'Web Setting')


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">@if(isset($setting)) Edit @else Add @endif Setting</h4>

                        </div><!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                @if (session('msg'))
                                <div class="alert alert-success" role="alert">
                                    {{ session('msg') }}
                                </div>
                                @endif


                                <form method="post" action="{{url('admin/web-setting-update')}}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row gy-4">

                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="is_partner_released" class="form-label">New Partners should be released by an admin?</label>
                                                <select name="is_partner_released" class="form-control">
                                                    <option value="" @if(isset($setting) && $setting->is_partner_released == '') {{"selected"}} @endif>--Select--</option>
                                                    <option value="yes" @if(isset($setting) && $setting->is_partner_released == 'yes') {{"selected"}} @endif>Yes</option>
                                                    <option value="no" @if(isset($setting) && $setting->is_partner_released == 'no') {{"selected"}} @endif>No</option>
                                                </select>

                                                @error('is_partner_released')
                                                <span class="text-danger">{{$message}}</span>
                                                @enderror

                                            </div>
                                        </div>

                                        
                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="vat_sales_provision" class="form-label">VAT Rate for Sales Provision?</label>
                                                <input type="text" class="form-control" name="vat_sales_provision" value="{{ isset($setting)?$setting->vat_sales_provision:old('vat_sales_provision') }}">
                                            </div>
                                            @error('vat_sales_provision')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="standard_sales_provision" class="form-label">Standard Sales Provisions?</label>
                                                <input type="text" class="form-control" name="standard_sales_provision" value="{{ isset($setting)?$setting->standard_sales_provision:old('standard_sales_provision') }}">
                                            </div>
                                            @error('standard_sales_provision')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="is_accept_manual_payment" class="form-label">Acceptance of Manual Payment by customers?</label>
                                                <input type="text" class="form-control" name="is_accept_manual_payment" value="{{ isset($setting)?$setting->is_accept_manual_payment:old('is_accept_manual_payment') }}">
                                            </div>
                                            @error('is_accept_manual_payment')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="automatic_cancellation_days" class="form-label">Automatic Order Cancellation after?</label>
                                                <input type="text" class="form-control" name="automatic_cancellation_days" value="{{ isset($setting)?$setting->automatic_cancellation_days:old('automatic_cancellation_days') }}">
                                            </div>
                                            @error('automatic_cancellation_days')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="voucher_validity_period" class="form-label">Voucher Validity Period?</label>
                                                <input type="text" class="form-control" name="voucher_validity_period" value="{{ isset($setting)?$setting->voucher_validity_period:old('voucher_validity_period') }}">
                                            </div>
                                            @error('voucher_validity_period')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Voucher Validity Type</label>
                                                    <select name="voucher_validity_type" class="form-control">
                                                        <option value="" @if(isset($setting) && $setting->voucher_validity_type == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="1" @if(isset($setting) && $setting->voucher_validity_type == 1) {{"selected"}} @endif>Purchase Date</option>
                                                        <option value="2" @if(isset($setting) && $setting->voucher_validity_type == 2) {{"selected"}} @endif>First of January</option>
                                                    </select>

                                                    @error('voucher_validity_type')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Voucher (Physical/Online)</label>
                                                    <select name="voucher_po" class="form-control">
                                                        <option value="" @if(isset($setting) && $setting->voucher_po == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="physical" @if(isset($setting) && $setting->voucher_po == 'physical') {{"selected"}} @endif> Physical </option>
                                                        <option value="online" @if(isset($setting) && $setting->voucher_po == 'online') {{"selected"}} @endif> Online </option>
                                                    </select>

                                                    @error('voucher_po')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>


                                            <div class="col-xxl-6 col-md-6">
                                            <div>
                                                <label for="universal_partner" class="form-label">Universal Partner Email</label>
                                                <input type="text" class="form-control" name="universal_partner" value="{{ isset($setting)?$setting->universal_partner:old('universal_partner') }}">
                                            </div>
                                            @error('universal_partner')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xxl-6 col-md-6">
                                                <div>
                                                    <label for="name" class="form-label">Universal Voucher Prioritation</label>
                                                    <select name="universal_prioritation" class="form-control">
                                                        <option value="" @if(isset($setting) && $setting->universal_prioritation == '') {{"selected"}} @endif>--Select--</option>
                                                        <option value="1" @if(isset($setting) && $setting->universal_prioritation == '1') {{"selected"}} @endif> Yes </option>
                                                        <option value="0" @if(isset($setting) && $setting->universal_prioritation == '0') {{"selected"}} @endif> No </option>
                                                    </select>

                                                    @error('universal_prioritation')
                                                    <span class="text-danger">{{$message}}</span>
                                                    @enderror

                                                </div>
                                            </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="voucher_general_info" class="form-label">Voucher General Information</label>
                                                <textarea class="form-control" name="voucher_general_info" id="voucher_general_info"> {{ isset($setting)?$setting->voucher_general_info:old('voucher_general_info') }}</textarea>
                                            </div>
                                            @error('voucher_general_info')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="voucher_footer_info" class="form-label">Voucher Footer Information</label>
                                                <textarea class="form-control" name="voucher_footer_info"> {{ isset($setting)?$setting->voucher_footer_info:old('voucher_footer_info') }}</textarea>
                                            </div>
                                            @error('voucher_footer_info')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="invoice_general_info" class="form-label">Invoice General Information</label>
                                                <textarea class="form-control" name="invoice_general_info" id="invoice_general_info"> {{ isset($setting)?$setting->invoice_general_info:old('invoice_general_info') }}</textarea>
                                            </div>
                                            @error('invoice_general_info')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="credit_note_general_info" class="form-label">Credit Note Information</label>
                                                <textarea class="form-control" name="credit_note_general_info" id="credit_note_general_info"> {{ isset($setting)?$setting->credit_note_general_info:old('credit_note_general_info') }}</textarea>
                                            </div>
                                            @error('credit_note_general_info')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="credit_note_general_info" class="form-label">Cancel Order Information</label>
                                                <textarea class="form-control" name="cancel_order_general_info" id="cancel_order_general_info"> {{ isset($setting)?$setting->cancel_order_general_info:old('cancel_order_general_info') }}</textarea>
                                            </div>
                                            @error('cancel_order_general_info')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="payment_invoice_message" class="form-label">Payment Invoice Information</label>
                                                <textarea class="form-control" name="payment_invoice_message" id="payment_invoice_message"> {{ isset($setting)?$setting->payment_invoice_message:old('payment_invoice_message') }}</textarea>
                                            </div>
                                            @error('payment_invoice_message')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>


                                        <div class="col-xxl-12 col-md-12">
                                            <div>
                                                <label for="cn_invoice_message" class="form-label">Credit Note Invoice Information</label>
                                                <textarea class="form-control" name="cn_invoice_message" id="cn_invoice_message"> {{ isset($setting)?$setting->cn_invoice_message:old('cn_invoice_message') }}</textarea>
                                            </div>
                                            @error('cn_invoice_message')
                                            <span class="text-danger">{{$message}}</span>
                                            @enderror
                                        </div>

                                    </div>

                                    <br><br>
                                    <div class="row gy-4">

                                        <div class="col-xxl-3 col-md-6">
                                            <div>
                                                <input type="hidden" name="setting_id" value="{{ isset($setting)?$setting->id:old('setting_id') }}">
                                                <input type="submit" class="btn btn-success" value="Update">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end row-->
                                </form>



                            </div>

                        </div>
                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->




        </div> <!-- container-fluid -->
    </div><!-- End Page-content -->

    @include('includes.admin.footer')
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->






<script>
        ClassicEditor
            .create(document.querySelector('#voucher_general_info'))
            .catch(error => {
                console.error(error);
            });
    </script>


<script>
        ClassicEditor
            .create(document.querySelector('#invoice_general_info'))
            .catch(error => {
                console.error(error);
            });
    </script>


<script>
        ClassicEditor
            .create(document.querySelector('#credit_note_general_info'))
            .catch(error => {
                console.error(error);
            });
    </script>


<script>
        ClassicEditor
            .create(document.querySelector('#cancel_order_general_info'))
            .catch(error => {
                console.error(error);
            });
    </script>



<script>
        ClassicEditor
            .create(document.querySelector('#payment_invoice_message'))
            .catch(error => {
                console.error(error);
            });
    </script>



<script>
        ClassicEditor
            .create(document.querySelector('#cn_invoice_message'))
            .catch(error => {
                console.error(error);
            });
    </script>

@stop