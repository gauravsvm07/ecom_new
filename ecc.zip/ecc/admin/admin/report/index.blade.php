@extends('layouts.admin_layout')
@section('content')
@section('title', 'Report List')

<style>
    .live-preview svg {
        width: 15px;
    }
</style>


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Manage Report</h4>
                            <div class="flex-shrink-0">
                                &nbsp;
                            </div>
                        </div><!-- end card header -->

                        <div class="card-body">

                         <div class="row">

                         <div class="col-xl-3" style="margin-bottom: 20px;">
                         <a href="{{url('admin/category/export')}}" class="btn btn-info">Download Category</a>
                         </div>


                         <div class="col-xl-3">
                         <a href="{{url('admin/product/export')}}" class="btn btn-info">Download Voucher</a>
                         </div>

                         <div class="col-xl-3">
                         <a href="{{url('admin/user/export')}}" class="btn btn-info">Download Partners</a>
                         </div>


                         <div class="col-xl-3">
                         <a href="{{url('admin/influencer/export')}}" class="btn btn-info">Download Influencers</a>
                         </div>

                         <div class="col-xl-3">
                         <a href="{{url('admin/order/invoice-export')}}" class="btn btn-info">Download Invoice</a>
                         </div>

                         <div class="col-xl-3">
                         <a href="{{url('admin/dashboard/redemption-export')}}" class="btn btn-info">Download Redemption</a>
                         </div>

                         <div class="col-xl-3">
                         <a href="{{url('admin/dashboard/cn-export')}}" class="btn btn-info">Download CreditNote</a>
                         </div>

                         </div>

                         <br><br>
                        

                            <div class="live-preview">
                                <form class="form-inline" method="GET" action="{{url('admin/report/search/date')}}">
                                    <div class="row">
                                    <div class="col-xl-3">
                                    <label for="date_from">Date From:</label>
                                    <input type="date" class="form-control" name="date_from" required>
                                    </div>
                                    <div class="col-xl-3">
                                    <label for="date_to">Date To:</label>
                                    <input type="date" class="form-control" name="date_to" required>
                                    </div>
                                    <div class="col-xl-3">
                                    <button type="submit" class="btn btn-primary" style="margin-top: 28px;">Search</button>
                                    </div>
                                    <div class="col-xl-4"></div>
                                    </div>
                                </form>
                            </div>
                            <br>
                                <div class="table-responsive pb-4">
                                    <table class="table align-middle table-nowrap mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>#</th>
                                                <th>Order Id</th>
                                                <th>Amount </th>
                                                <th>Order Status</th>
                                                <th>Payment Id</th>
                                                <th>Payment Via</th>
                                                <th>Payment Status</th>
                                                <th>Date/Time</th>
                                                <th>Order Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            @foreach($reports as $key=>$report)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ $report->order_id ?? '-' }}</td>
                                                <td>€{{ $report->amount ?? '-' }}</td>
                                                <td>@if($report->order_status == 1) Success @else Pending @endif </td>
                                                <td>{{ $report->payment_id ?? '-' }}</td>
                                                <td>{{ $report->payment_via ?? '-' }}</td>
                                                @if($report->payment_via == 'Manual_Payment')
                                                <td> <select class="form-control changePayStatus2" order-id="{{$report->id}}" disabled>
                                                        <option value="1" {{ $report->payment_status == 1 ? 'selected' : '' }}>Pending</option>
                                                        <option value="3" {{ $report->payment_status == 3 ? 'selected' : '' }}>Success</option>
                                                    </select> </td>
                                                @else
                                                <td>@if($report->payment_status == 3) Success @else Pending @endif </td>
                                                @endif

                                                <td>{{ date('d-M-Y h:i:s A', strtotime($report->created_at))}}</td>

                                                <td>
                                                    <form>
                                                        @php
                                                        $order_status = App\Helpers\Helper::getOrderStatus();
                                                        @endphp
                                                        <select class="form-control" order-id="{{$report->id}}" disabled>
                                                            @foreach($order_status as $order_row)
                                                            <option value="{{$order_row->id}}" {{ $report->order_status == $order_row->id ? 'selected' : '' }}>{{$order_row->name}}</option>
                                                            @endforeach
                                                        </select>
                                                    </form>
                                                </td>
                                                <td>
                                                    <a href="{{url('admin/order/view/'.$report->id)}}" class="btn btn-info btn-sm">View </a> &nbsp;
                                                    <a href="{{url('invoice/'.$report->uuid)}}" target="_blank" class="btn btn-success btn-sm">Invoice </a> &nbsp;
                                                </td>
                                                @endforeach
                                            </tr>

                                        </tbody>

                                    </table>

                                    {{$reports->links('pagination::bootstrap-4')}}
                                    <!-- end table -->
                                </div>
                                <!-- end table responsive -->
                            </div>

                        </div><!-- end card-body -->
                    </div><!-- end card -->
                </div><!-- end col -->
            </div>
            <!--end row-->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    @include('includes.admin.footer')
</div>
<!-- end main content-->


<!-- END layout-wrapper -->

@include('includes/admin/delete-model')
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
            }
        });

        $('.deleteBtn').on('click', function() {
            var row_id = $(this).attr('row_id');
            $('.get_row_id').val(row_id);
            $('#delete_modal').modal('show');
        });

        $('.deleteBtnYs').on('click', function() {
            var row_id = $('.get_row_id').val();
            //alert(row_id);
            var csrf_token = $('input[name="csrf_token"]').val();
            var getUrl = window.location.href + '/delete/' + row_id;
            $.ajax({
                url: getUrl,
                method: "get",
                data: {
                    id: row_id,
                    _token: csrf_token
                },
                beforeSend: function() {
                    $('.get_msg').text('deleting...');
                },
                success: function(data) {
                    $('#delete_modal').modal('hide');
                    $('.get_row_' + row_id).remove();
                }

            });

        });

        $('.deleteBtnNo').on('click', function() {
            $('#delete_modal').modal('hide');
        });

    });
</script>

@stop