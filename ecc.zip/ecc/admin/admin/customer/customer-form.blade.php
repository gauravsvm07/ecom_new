@extends('layouts.admin_layout')
@section('content')
@section('title', 'Add Customer')


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <!-- end page title -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1"> @if(isset($customer)) View @else Add @endif Customer</h4>

                        </div><!-- end card header -->
                        <div class="card-body">
                            <div class="live-preview">

                                @if (session('msg'))
                                <div class="alert alert-{{ session('msg_type') }}" role="alert">
                                    {{ session('msg') }}
                                </div>
                                @endif



                                <div class="row gy-4">

                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="first_name" class="form-label">First Name</label>
                                            <input type="text" class="form-control" name="first_name" value="{{ isset($customer)?$customer->first_name:old('first_name') }}">
                                        </div>
                                        @error('first_name')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>

                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="last_name" class="form-label">First Name</label>
                                            <input type="text" class="form-control" name="last_name" value="{{ isset($customer)?$customer->last_name:old('last_name') }}">
                                        </div>
                                        @error('last_name')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>

                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="email" class="form-label">Email Id</label>
                                            <input type="email" class="form-control" name="email" value="{{ isset($customer)?$customer->email:old('email') }}">
                                        </div>
                                        @error('email')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>


                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="phone" class="form-label">Phone</label>
                                            <input type="text" class="form-control" name="phone" value="{{ isset($customer)?$customer->phone:old('phone') }}">
                                        </div>
                                        @error('phone')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>




                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="street_address" class="form-label"> Address</label>
                                            <input type="text" class="form-control" name="address" value="{{ isset($customer)?$customer->address:old('address') }}">
                                        </div>
                                        @error('address')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>

                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="city" class="form-label"> City</label>
                                            <input type="text" class="form-control" name="city" value="{{ isset($customer)?$customer->city:old('city') }}">
                                        </div>
                                        @error('city')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>



                                    <div class="col-xxl-4 col-md-4">
                                        <div>
                                            <label for="zip_code" class="form-label"> Zip Code</label>
                                            <input type="text" class="form-control" name="zip_code" value="{{ isset($customer)?$customer->zip_code:old('zip_code') }}">
                                        </div>
                                        @error('zip_code')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>



                                </div>

                            </div>
                        </div>
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->




            </div> <!-- container-fluid -->
        </div><!-- End Page-content -->

        @include('includes.admin.footer')
    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->



@stop