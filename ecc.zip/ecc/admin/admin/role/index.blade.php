@extends('layouts.admin_layout')
@section('content')
@section('title', 'Role List')

<style>
    .live-preview svg {
        width: 15px;
    }
</style>


<!-- ========== App Menu ========== -->

<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Role List</h4>
                            <div class="flex-shrink-0">
                                <a href="{{url('admin/role/create')}}" class="btn btn-info">Add Role</a>
                            </div>
                        </div><!-- end card header -->

                        <div class="card-body">

                            <div class="live-preview">
                                <div class="table-responsive pb-4">
                                <table class="table table-nowrap mb-0" id="getDataTable">
                                        <thead class="table-light">
                                            <tr>
                                                <th scope="col">S.No</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Permission</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            @forelse($roles as $key=>$row)
                                            <tr row_id="{{$row->id}}" class="get_row_{{$row->id}}">
                                                <td>{{$key+1+($roles->currentPage()-1) * ($roles->perPage())}}</td>
                                                <td>{{$row->name ?? ''}}</td>
                                                <td>@if($row->status == 1) <button type="button" class="btn btn-sm btn-light"> Active</button> @else <button type="button" class="btn btn-sm btn-light"> Inactive</button> @endif</td>
                                                <td>
                                                <a class="btn btn-info btn-sm waves-effect waves-light permissionBtn" href="javascript:void(0)" data-toggle="modal" href="javascript:void(0)" row_id="{{$row->id}}">
                                                        <i class="fe fe-pencil"></i> Permission
                                                    </a>
                                                </td>
                                                <td>
                                                    <a class="btn btn-info btn-sm waves-effect waves-light" href="{{url('admin/role/edit/'.$row->id)}}">
                                                        <i class="fe fe-pencil"></i> Edit
                                                    </a>
                                                    <a class="btn btn-danger btn-sm waves-effect waves-light deleteBtn" data-toggle="modal" href="javascript:void(0)" row_id="{{$row->id}}">
                                                        <i class="fe fe-trash"></i> Delete
                                                    </a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="5">Data not found</td>
                                            </tr>
                                            @endif

                                        </tbody>

                                    </table>

                                    {{$roles->links()}}
                                    <!-- end table -->
                                </div>
                                <!-- end table responsive -->
                            </div>

                        </div><!-- end card-body -->
                    </div><!-- end card -->
                </div><!-- end col -->
            </div>
            <!--end row-->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    @include('includes.admin.footer')
</div>
<!-- end main content-->


<!-- Modal HTML -->
<div class="modal fade" id="permissionModal" tabindex="-1" aria-labelledby="permissionModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="permissionModalLabel">Assign Permissions</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="permissionForm">
          <!-- Hidden input to store the role ID -->
          <input type="hidden" id="role_id" value="">
          
          <div class="permissions-list">
            <!-- Permissions checkboxes will be dynamically added here -->
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="savePermissionsBtn">Save changes</button>
      </div>
    </div>
  </div>
</div>



<!-- END layout-wrapper -->

@include('includes/admin/delete-model')

<script>
$(document).ready(function() {
    $('.permissionBtn').on('click', function() {
        var rowId = $(this).closest('tr').attr('row_id');

        // Set the role_id in the hidden input
        $('#role_id').val(rowId);

        // Make an AJAX request to fetch the role's permissions
        $.ajax({
            url: '/community/admin/role/role/' + rowId + '/permissions', // Replace with the actual route
            method: 'GET',
            success: function(response) {
                // Clear existing permissions
                $('#permissionModal .permissions-list').empty();

                // Loop through permissions and append checkboxes
                response.permissions.forEach(function(permission) {
                    var checked = permission.assigned ? 'checked' : '';
                    var checkbox = `<div class="form-check">
                                      <input class="form-check-input" type="checkbox" value="${permission.id}" id="perm_${permission.id}" ${checked}>
                                      <label class="form-check-label" for="perm_${permission.id}">
                                        ${permission.name}
                                      </label>
                                    </div>`;
                    $('#permissionModal .permissions-list').append(checkbox);
                });

                // Open the modal
                $('#permissionModal').modal('show');
            }
        });
    });

    // Handle save button click
    $('#savePermissionsBtn').on('click', function() {
        // Retrieve the role ID from the hidden input field
        var roleId = $('#role_id').val();
        var selectedPermissions = [];

        // Get all selected permissions
        $('#permissionModal .permissions-list input:checked').each(function() {
            selectedPermissions.push($(this).val());
        });

        // Make AJAX request to save permissions
        $.ajax({
            url: '/community/admin/role/role/' + roleId + '/permissions', // Replace with the actual route
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}', // Add CSRF token for security
                permissions: selectedPermissions
            },
            success: function(response) {
                // Show success message and close the modal
                alert('Permissions updated successfully!');
                $('#permissionModal').modal('hide');
            }
        });
    });
});

</script>


<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')
            }
        });

        $('.deleteBtn').on('click', function() {
            var row_id = $(this).attr('row_id');
            $('.get_row_id').val(row_id);
            $('#delete_modal').modal('show');
        });

        $('.deleteBtnYs').on('click', function() {
            var row_id = $('.get_row_id').val();
            //alert(row_id);
            var csrf_token = $('input[name="csrf_token"]').val();
            var getUrl = window.location.href + '/delete/' + row_id;
            $.ajax({
                url: getUrl,
                method: "get",
                data: {
                    id: row_id,
                    _token: csrf_token
                },
                beforeSend: function() {
                    $('.get_msg').text('deleting...');
                },
                success: function(data) {
                    $('#delete_modal').modal('hide');
                    $('.get_row_' + row_id).remove();
                }

            });

        });

        $('.deleteBtnNo').on('click', function() {
            $('#delete_modal').modal('hide');
        });

    });
</script>

<script>
new DataTable('#getDataTable');
</script>

@stop