<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Redemption extends Model
{
    use HasFactory;

    // public function customer()
    // {
    //     return $this->belongsTo(\App\Models\Customer::class);
    // }

    // public function order()
    // {
    //     return $this->belongsTo(\App\Models\Order::class);
    // }

    // public function product()
    // {
    //     return $this->belongsTo(\App\Models\Product::class);
    // }

    public function product()
    {
        return $this->hasOne(\App\Models\Product::class, 'id', 'product_id');
    }

    public function partner()
    {
        return $this->hasOne(\App\Models\User::class, 'id', 'partner_id');
    }

    public function partner_detail()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'user_id', 'partner_id');
    }

    public function item()
    {
        return $this->hasOne(\App\Models\OrderItem::class, 'id', 'order_item_id');
    }

    public function customer()
    {
        return $this->hasOne(\App\Models\Customer::class, 'id', 'customer_id');
    }



}
