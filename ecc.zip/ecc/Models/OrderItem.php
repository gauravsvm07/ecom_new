<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    public function category()
    {
        return $this->hasOne(\App\Models\Category::class, 'id', 'category_id');
    }

    public function old_product()
    {
        return $this->hasOne(\App\Models\Product::class, 'id', 'product_id');
    }

    public function order()
    {
        return $this->belongsTo(\App\Models\Order::class);
    }
    public function products()
    {
        return $this->belongsTo(\App\Models\Product::class);
    }

    // public function product()
    // {
    //     return $this->belongsTo(\App\Models\Product::class);
    // }

    public function product()
    {
        return $this->hasOne(\App\Models\Product::class, 'id', 'product_id');
    }

    public function order_status()
    {
        return $this->belongsTo(\App\Models\OrderStatus::class);
    }

    public function partner()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'id', 'partner_id');
    }

    public function partner_detail()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'user_id', 'partner_id');
    }
}
