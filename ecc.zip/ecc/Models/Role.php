<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;
    protected $table = 'roles';

    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'role_permission');
    }

    // Assign permission to the role
    public function givePermissionTo($permission)
    {
        $permission = Permission::where('name', $permission)->first();
        return $this->permissions()->attach($permission);
    }

    // Remove a permission from the role
    public function revokePermissionTo($permission)
    {
        $permission = Permission::where('name', $permission)->first();
        return $this->permissions()->detach($permission);
    }

    // Check if role has a specific permission
    public function hasPermission($permission)
    {
        return $this->permissions()->where('name', $permission)->exists();
    }
}
