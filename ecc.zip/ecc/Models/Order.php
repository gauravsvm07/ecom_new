<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Order extends Model
{
    use HasFactory;
    protected $fillable = array('*');
    protected $table = 'orders';




    public function user()
    {
        return $this->hasOne(\App\Models\User::class, 'id', 'customer_id');
    }

    public function user_detail()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'user_id', 'user_id');
    }
    public function items()
    {
        return $this->hasMany(\App\Models\OrderItem::class);
    }

    public function customer()
    {
        return $this->belongsTo(\App\Models\Customer::class);
    }

    public function order_address()
    {
        return $this->hasOne(\App\Models\OrderAddress::class);
    }
    
}
