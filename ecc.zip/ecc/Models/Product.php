<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ProductImage;

class Product extends Model
{
    protected $table = 'products';
    protected $fillable = array('*');
    use HasFactory;

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
    public function gallery()
    {
        return $this->hasMany(ProductImage::class, 'product_id')->orderBy('image_ordering', 'ASC');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function userDetails()
    {
        return $this->belongsTo(UserDetail::class, 'user_id', 'user_id');
    }

    public function partner()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'id', 'user_id');
    }

    public function partner_detail()
    {
        return $this->hasOne(\App\Models\UserDetail::class, 'user_id', 'user_id');
    }

    public function get_country()
    {
        return $this->hasOne(\App\Models\Country::class, 'id', 'country');
    }

    // public function redemption()
    // {
    //     return $this->belongsTo(\App\Models\Product::class);
    // }
}
