<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
class Admin extends Authenticatable
{
    use Notifiable;
    protected $guard = 'admin';
    // protected $fillable = [
    //     'name', 'email', 'password',
    // ];

    protected $table = 'admins';

    protected $fillable = array('*');

    protected $hidden = [
      'password', 'remember_token',
    ];


    public function roles()
    {
        ///return $this->belongsToMany(Role::class);
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id');

    }

    // Check if the user has a specific role
    public function hasRole($role)
    {
        return $this->roles()->where('slug', $role)->exists();
    }

    // Assign a role to the user
    public function assignRole($role)
    {
        $role = Role::where('slug', $role)->first();
        return $this->roles()->attach($role);
    }

    // Remove a role from the user
    public function removeRole($role)
    {
        $role = Role::where('slug', $role)->first();
        return $this->roles()->detach($role);
    }

}
