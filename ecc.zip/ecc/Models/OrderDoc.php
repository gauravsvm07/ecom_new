<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderDoc extends Model
{
    use HasFactory;
    protected $table = 'order_docs';
    protected $fillable = array('*');
    
}
